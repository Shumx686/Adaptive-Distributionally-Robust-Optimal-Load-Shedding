"""Portable entry points for the current three-system SEGAN experiments."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify():
    manifest=json.loads((ROOT/'checksums.json').read_text('utf-8'))
    for row in manifest:
        p=ROOT/row['path']
        if not p.is_file() or sha(p)!=row['sha256']:
            raise RuntimeError('Distributed file missing or changed: '+row['path'])
    print(f'Verified {len(manifest)} distributed files. Original inputs are checked separately.')


def inputs(data_root,systems):
    rows=json.loads((ROOT/'input_manifest.json').read_text('utf-8'))
    return [r for r in rows if r['system'] in systems]


def check_data(data_root,systems):
    rows=inputs(data_root,systems)
    bad=[r['path'] for r in rows if not (data_root/r['path']).is_file()
         or sha(data_root/r['path'])!=r['sha256']]
    if bad:
        raise RuntimeError('Missing or different original inputs:\n'+'\n'.join(bad)
                           +'\nSee docs/DATA.md; use install-data or --data-root.')
    print(f'Input hashes verified: {len(rows)} files for {", ".join(systems)}.')


def install_data(source,systems):
    check_data(source,systems)
    rows=inputs(source,systems)
    for row in rows:
        target=ROOT/'data'/row['path']
        if target.exists() and sha(target)!=row['sha256']:
            raise FileExistsError('Refusing to overwrite a different input: '+str(target))
    for row in rows:
        target=ROOT/'data'/row['path'];target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source/row['path'],target)
    check_data(ROOT/'data',systems)


def output_name(name,prefix):
    name=name or prefix+'_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    if not re.fullmatch(r'[A-Za-z0-9_-]+',name):
        raise ValueError('Use only letters, digits, underscore and hyphen in a run name.')
    return ROOT/'outputs'/name


def workspace(name,prefix,resume=False,reference=False):
    out=output_name(name,prefix)
    marker=out/'workspace.json'
    if out.exists():
        if not resume or not marker.is_file():
            raise FileExistsError('Choose a new name or use --resume for an existing run: '+str(out))
        return out
    out.mkdir(parents=True)
    shutil.copytree(ROOT/'core',out/'core')
    for folder in ('scripts','config'):
        shutil.copytree(ROOT/'experiments'/folder,out/'experiments'/folder)
    dest=out/'experiments/results';dest.mkdir()
    if reference:
        shutil.copytree(ROOT/'experiments/results',dest,dirs_exist_ok=True)
    else:
        # Frozen validation choices and benchmark context definitions are inputs.
        # Dispatches, scenario draws, traces and hourly outputs start empty.
        for p in (ROOT/'experiments/results/weight_calibration').rglob('selected_weights.json'):
            q=dest/p.relative_to(ROOT/'experiments/results');q.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(p,q)
        for system in ('rbts','rts79','gmlc'):
            rel=Path('controlled_beta_repetitions/rep01')/system/'protocol.json'
            q=dest/rel;q.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(ROOT/'experiments/results'/rel,q)
        if prefix=='contextual':
            shutil.copytree(ROOT/'experiments/results/scenario_stress',dest/'scenario_stress')
    marker.write_text(json.dumps({'purpose':prefix,'reference_results_copied':reference,
                                 'created':datetime.datetime.now().isoformat()},indent=2)+'\n','utf-8')
    return out


def command(args,cwd,env=None):
    print('Running:',subprocess.list2cmdline([str(v) for v in args]),flush=True)
    subprocess.run([str(v) for v in args],cwd=cwd,env=env,check=True)


def figures(name):
    out=output_name(name,'figures');out.mkdir(parents=True,exist_ok=False)
    for job in ('workflow','histories','recency','operational','capacity','convergence','fixed_calendar'):
        command([sys.executable,ROOT/'paper_figures/build.py',job,out],ROOT)
    print('Current manuscript figures (1-7 and S1):',out)


def reports(name):
    out=workspace(name,'reports',reference=True)
    for script in ('report_repetitions.py','report_joint.py','report_rolling.py',
                   'report_refresh.py','report_capacity.py'):
        command([sys.executable,out/'experiments/scripts'/script],out)
    helper=out/'paper_figures/scripts/paired_evidence.py'
    helper.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(ROOT/'paper_figures/scripts/paired_evidence.py',helper)
    command([sys.executable,helper],out)
    print('Rebuilt reports in:',out/'experiments/results')


def checks(args):
    check_data(args.data_root,['rbts'])
    out=workspace(args.name,'checks')
    env=os.environ.copy();env['SEGAN_DATA_ROOT']=str(args.data_root.resolve())
    for script in ('check_beta_generator.jl','check_recourse.jl','check_tv_solver.jl'):
        command([args.julia,'--startup-file=no','--threads=1','--project='+str(out/'core'),
                 out/'experiments/scripts'/script],out,env)
    print('Numerical checks completed in:',out)


def run(args):
    systems=['rbts','rts79','gmlc'] if args.system=='all' else [args.system]
    if args.task in ('rolling','fixed','refresh','validation'):
        if systems!=['rts79']:
            raise ValueError('This task uses --system rts79.')
    if args.task=='capacity' and 'gmlc' in systems:
        raise ValueError('Capacity grid uses --system rbts or rts79.')
    if not 1<=args.first<=args.last<=10:
        raise ValueError('Replications must satisfy 1 <= first <= last <= 10.')
    if args.task=='study':
        if not args.config or Path(args.config).name!=args.config:
            raise ValueError('Provide a filename from experiments/config/ with --config.')
        if not (ROOT/'experiments/config'/args.config).is_file():
            raise FileNotFoundError(args.config)
    if args.dry_run:
        print(json.dumps({'task':args.task,'systems':systems,'config':args.config,
                          'replications':[args.first,args.last],
                          'destination':str(output_name(args.name,args.task)),
                          'fresh_results':True,'reference_records_modified':False},indent=2))
        return
    check_data(args.data_root,systems)
    out=workspace(args.name,args.task,args.resume)
    env=os.environ.copy();env['SEGAN_DATA_ROOT']=str(args.data_root.resolve())
    scriptdir=out/'experiments/scripts'
    def julia(script,*extra):
        command([args.julia,'--startup-file=no','--threads=1','--project='+str(out/'core'),
                 scriptdir/script,*extra],out,env)
    if args.task in ('rolling','fixed','refresh'):
        study={'rolling':'rolling_operational_rts79_576h','fixed':'joint_test_rts79_576h',
               'refresh':'support_refresh_rts79_96h'}[args.task]
        for part in range(1,5):
            julia('run_study.jl',out/'experiments/config'/f'{study}_part{part}.toml','rts79')
        command([sys.executable,scriptdir/'merge_joint_test.py',study],out)
    elif args.task=='validation':
        julia('joint_validate.jl')
    else:
        for system in systems:
            if args.task=='replications':julia('repeat_controlled.jl',system,args.first,args.last)
            elif args.task=='solver':julia('solver_assessment.jl',system)
            elif args.task=='capacity':julia('scan_capacity.jl',system)
            elif args.task=='weights':julia('calibrate_weights.jl',system)
            elif args.task=='stress':julia('run_scenario_stress.jl',system)
            elif args.task=='contextual':julia('evaluate_conditional.jl',system)
            elif args.task=='study':julia('run_study.jl',out/'experiments/config'/args.config,system)
    print('Run results:',out/'experiments/results')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    sub.add_parser('verify')
    for name in ('figures','reports'):
        p=sub.add_parser(name);p.add_argument('--name')
    for name in ('check-data','install-data'):
        p=sub.add_parser(name);p.add_argument('--systems',nargs='+',choices=['rbts','rts79','gmlc'],default=['rbts','rts79','gmlc'])
        p.add_argument('--source' if name=='install-data' else '--data-root',type=Path,required=name=='install-data',default=ROOT/'data')
    p=sub.add_parser('checks');p.add_argument('--name');p.add_argument('--julia',default='julia');p.add_argument('--data-root',type=Path,default=ROOT/'data')
    p=sub.add_parser('run');p.add_argument('task',choices=['study','replications','solver','capacity','rolling','fixed','refresh','stress','contextual','weights','validation'])
    p.add_argument('--system',choices=['rbts','rts79','gmlc','all'],default='rbts')
    p.add_argument('--name');p.add_argument('--resume',action='store_true');p.add_argument('--dry-run',action='store_true')
    p.add_argument('--config');p.add_argument('--first',type=int,default=1);p.add_argument('--last',type=int,default=10)
    p.add_argument('--data-root',type=Path,default=ROOT/'data');p.add_argument('--julia',default='julia')
    args=parser.parse_args()
    if args.command=='verify':verify()
    elif args.command=='check-data':check_data(args.data_root,args.systems)
    elif args.command=='install-data':install_data(args.source,args.systems)
    elif args.command=='figures':figures(args.name)
    elif args.command=='reports':reports(args.name)
    elif args.command=='checks':checks(args)
    else:run(args)


if __name__=='__main__':
    main()
