# 风电压力与敏感性复现材料

这些日期命名的研究记录仍支持当前稿件的风电—容量压力、线路裕度、TV/修改chi-square及单因素敏感性结果，因而完整保留。它们采用各自原有采样和实时校正定义；较新的三系统重复/回放实验位于上级 `experiments/`，不要混用统计口径。

本目录的模型源码保留该组实验冻结时的版本，SHA-256与 `engine_hashes.json` 完全一致；主实验后来增加的求解审计接口保留在上级 `core/`，两份源码分别对应各自的结果记录。

| 位置 | 内容 |
| --- | --- |
| `code/julia_drcc_ols/src/`、`config/`、`scripts/` | 原模型、配置及运行、合并、汇总与绘图代码 |
| `code/julia_drcc_ols/results/wind_control_final_20260911/` | 全部18个风电—容量格点的配置、逐方法小时、失败状态、原始来源和引擎哈希 |
| `code/julia_drcc_ols/results/wind_control_final_report/` | 全格点、逐时、配对比较与覆盖率汇总 |
| `code/julia_drcc_ols/results/review_supplement_20260913/` | 所有敏感性变体、逐小时记录、manifest及汇总 |
| `data_manifest.json` | 13个RBTS/RTS-79原始输入的名字和哈希 |

从整个解压包根目录执行，先按上级requirements安装Python依赖：

```sh
python supplementary_studies/reproduce.py verify
python supplementary_studies/reproduce.py rebuild
```

这两步不重新求解。`rebuild`在自己的 `outputs/` 内重建表格统计与结果图；其中自动生成的排版片段只是报告程序的本地产物，不属于本次上传的论文正文。

重新求解时先取得并安装原始输入：

```sh
julia --project=supplementary_studies/code/julia_drcc_ols -e "using Pkg; Pkg.instantiate()"
python supplementary_studies/reproduce.py install-data --source /path/to/original-input-folder
python supplementary_studies/reproduce.py main --case rts79_s100_c100 --dry-run
python supplementary_studies/reproduce.py supplement --group sensitivity --dry-run
```

确认任务后去掉 `--dry-run`。输出进入新的运行目录，冻结结果保持原样。原引擎、原结果和原参数文件的哈希保留；代码中的报告入口以实验目录为根定位，不需要论文目录。
