# Release validation (16 November 2026)

- Verified the SHA-256 hashes of all 20 required original input files.
- Loaded the 6/24/73-bus networks with 9/38/120 branches and 10/26/93 individually dispatchable units.
- Passed 62 numerical assertions: 9 Beta sampling, 44 physical-recourse, and 9 full-LP/constraint-generation checks.
- Regenerated all 8 current manuscript figures; the PNG pixels match the working manuscript references exactly in the recorded Windows/Python/font environment.
- Recomputed 6 aggregate result tables; numerical and text fields match the frozen references (numerical tolerance 1e-11).
- Verified merging of all three partitioned RTS-79 calendars against the unchanged frozen configurations.
- Confirmed the optimization model source is byte-identical to the current working source. Output workspaces are separate from the distributed records.

Full multi-history and long-calendar optimization runs were not repeated for packaging; their actual frozen records, protocols, seeds and checksums are included. Use the documented run commands to recompute them on a new machine.
