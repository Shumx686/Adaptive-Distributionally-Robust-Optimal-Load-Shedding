# Current numerical studies

Use the repository root for the commands below. Install the recorded Julia environment and check the original inputs first. `--dry-run` lists the requested task without creating a run directory or solving any model.

```sh
julia --project=core -e "using Pkg; Pkg.instantiate()"
python reproduce.py check-data
python reproduce.py checks
```

## Controlled independent histories

```sh
python reproduce.py run replications --system rbts --first 1 --last 10 --name rbts_histories
python reproduce.py run replications --system rts79 --first 1 --last 10 --name rts79_histories
python reproduce.py run replications --system gmlc --first 1 --last 10 --name gmlc_histories
```

Each history has its own training and validation sample, three contexts and 1000 shared conditional draws per context. The frozen independent RNG ledger is retained. Complete histories are the units for paired inference. Fresh results require report recomputation in that workspace; `reports` provides a separate reconstruction of the distributed reference results.

## Historical calendars and training recency

```sh
python reproduce.py run fixed --system rts79 --name fixed_calendar
python reproduce.py run rolling --system rts79 --name rolling_calendar
python reproduce.py run refresh --system rts79 --name recency_comparison
python reproduce.py run study --system rbts --config cross_season_rbts_672h.toml --name rbts_calendar
```

Fixed training and recent training use different predeclared 576-hour calendars. The four parts of each RTS-79 calendar are run with their own frozen configurations and merged only after checking disjoint coverage and matching parameters. The 96-hour training-recency comparison uses the same test hours for both protocols; its saved fixed-training comparison is also in the reference records.

## Capacity, stress and solver assessment

```sh
python reproduce.py run capacity --system rbts --name rbts_capacity
python reproduce.py run capacity --system rts79 --name rts79_capacity
python reproduce.py run stress --system gmlc --name gmlc_stress
python reproduce.py run contextual --system gmlc --name gmlc_matched_contexts
python reproduce.py run solver --system all --name solver_assessment
```

Contextual evaluation uses the frozen scenario-stress dispatches as inputs to re-evaluate them on matched contexts. The full-LP/constraint-generation study retains 120/720 samples and all three predefined contexts on each system; its 600-second limits and the time-limited pair are preserved. Wall times can vary by machine. Solver/source records describe empirical finite-support LP agreement, not exact solution of an unrestricted chance constraint.

Validation choices can be recomputed with `run weights --system rbts` and `run validation --system rts79`. The canonical frozen validation choices distributed with the manuscript remain separate from these new outputs. Add `--resume` with the same `--name` to continue a prepared workspace. Never change a frozen configuration while resuming a run.
