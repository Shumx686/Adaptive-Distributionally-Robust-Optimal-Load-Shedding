# Original inputs

The repository distributes code and derived experiment records. Re-solving requires 20 original input files, listed with exact relative paths, byte sizes and SHA-256 hashes in `input_manifest.json`:

- RBTS: MATPOWER case, system/bus load CSV files and wind site 5 workbook (4 files).
- RTS-79: MATPOWER case, system/bus load CSV files and wind site 1-6 workbooks (9 files).
- RTS-GMLC: `SourceData/{bus,gen,branch}.csv`, day-ahead/real-time regional load, and day-ahead/real-time wind (7 files).

Keep the original hierarchy `RBTS/`, `RTS_79/` and `RTS-GMLC/RTS-GMLC/RTS_Data/` under the input folder. The installer validates every requested file before copying any of them.

```sh
python reproduce.py install-data --source /path/to/inputs
python reproduce.py install-data --source /path/to/inputs --systems rbts
python reproduce.py check-data --data-root /path/to/inputs --systems rbts rts79 gmlc
```

Input sources used by the manuscript:

- Chen and Xu (2022), Solar and wind power data from the Chinese State Grid Renewable Energy Generation Forecasting Competition: https://doi.org/10.1038/s41597-022-01696-6
- Figueroa, Bubbar and Young-Morris (2024), benchmark network/load workflow: https://doi.org/10.3390/en17205023
- RTS-GMLC dataset and documentation: https://github.com/GridMod/RTS-GMLC ; Barrows et al. (2020): https://doi.org/10.1109/TPWRS.2019.2925557
- Classical RBTS/RTS network references are retained in the associated manuscript.

Upstream releases can differ. Use the recorded filenames and hashes; do not substitute separately cleaned time series. Network/load and wind records from different source years define the manuscript's aligned benchmark. Data provenance and original provider terms remain applicable; third-party inputs have not been relicensed in this bundle.
