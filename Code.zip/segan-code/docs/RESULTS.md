# 完整结果索引

| 目录 | 完整保留的结果及用途 |
| --- | --- |
| `controlled_beta_repetitions/` | 三网络、各10个独立历史、450个调度；450个逐情景CSV共450000行，附训练/验证协议、种子、汇总和配对比较 |
| `controlled_beta/` | 单历史机制基准及原始结果，与重复驱动的回归校验有关 |
| `joint_validation_rts79_v2/` | 筛选和确认的全部候选参数、逐状态结果、目标/误差索引及最终选择 |
| `weight_calibration/` | 逐参数验证评分与冻结权重选择 |
| `joint_test_rts79_576h/`及4个分区 | 固定训练日历的所有方法小时及合并索引 |
| `support_refresh_rts79_96h/`及4个分区 | 同测试小时的训练时效性完整对照 |
| `rolling_operational_rts79_576h/`及4个分区 | 最近训练日历、逐小时缺供/备用/校正、日和季节汇总 |
| `capacity_scan/` | 两系统全部方法与容量格点的完整精度记录 |
| `scenario_stress/`、`contextual_stress/` | 外部误差与匹配情境的所有方法和情景结果 |
| `cross_season_rbts_672h/`、`cross_season_rts79_96h/` | 跨季节历史参照及逐小时运行记录 |
| `solver_assessment/` | 18组完整LP/约束生成对照、输入、每轮迭代、状态和残差；保留限时结果 |
| `../../supplementary_studies/code/julia_drcc_ols/results/` | 支撑当前风电—容量压力、线路扩容与参数敏感性表的完整运行组及汇总 |

分发的冻结结果与项目中的对应文件字节一致。重新生成的报告写入新输出目录；不会改写这里的原始记录。相关实验组的零值和非最优状态均保留，没有因性能不好而筛除。
