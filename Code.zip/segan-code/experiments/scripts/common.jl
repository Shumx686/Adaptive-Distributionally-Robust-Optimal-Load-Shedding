using CSV, DataFrames, Dates, JSON, TOML, LinearAlgebra, Statistics, Random
const ROOT = normpath(joinpath(@__DIR__, "..", ".."))
const WORK = normpath(joinpath(@__DIR__, ".."))
const PROJECT = joinpath(ROOT, "core")
const DATA_ROOT = abspath(get(ENV, "SEGAN_DATA_ROOT", joinpath(ROOT, "data")))
push!(LOAD_PATH, joinpath(PROJECT, "src"))
using DRCCOLS, JuMP, HiGHS
BLAS.set_num_threads(1)
include("tv_dispatch.jl")

"Load the supplied inputs directly, without copying or changing source files."
function load_system(system; capacity_scale=1.0, error_multiplier=1.0)
    if system == "gmlc"
        root = joinpath(DATA_ROOT, "RTS-GMLC", "RTS-GMLC", "RTS_Data")
        names = DRCCOLS.gmlc_wind_columns(root)
        case = DRCCOLS.load_gmlc_case(root; wind_columns=names, aggregate_generators=false, pmin_scale=0.0)
        data = DRCCOLS.load_gmlc_experiment_data(case, root; wind_columns=names,
            wind_scale=1.0, load_scale=1.0, error_scale=1.0,
            wind_repair_isolated_spikes=false, load_repair_isolated_spikes=false)
        capacities = DRCCOLS.gmlc_wind_capacities(root, names)
    else
        config = TOML.parsefile(joinpath(PROJECT, "config", system == "rbts" ? "comparison.toml" : "rts79_comparison.toml"))
        folder = joinpath(DATA_ROOT, system == "rbts" ? "RBTS" : "RTS_79")
        cfg = config["data"]
        case = DRCCOLS.load_rbts(joinpath(folder, system == "rbts" ? "RBTS.m" : "RTS.m");
            wind_bus=cfg["wind_bus"], replace_gen_indices=cfg["replace_gen_indices"], pmin_scale=0.0)
        filenames = DRCCOLS.as_string_vector(config["paths"]["wind_xlsx"])
        paths = [joinpath(folder, basename(p)) for p in filenames]
        data = DRCCOLS.load_experiment_data(case, joinpath(folder,"SYSTEM_LOADS.csv"),
            joinpath(folder,"BUS_LOADS.csv"), paths; wind_scale=1.0, wind_lag=24, error_scale=1.0,
            wind_repair_isolated_spikes=false, load_repair_isolated_spikes=false)
        capacities = DRCCOLS.wind_capacity_from_filename.(paths)
    end
    case = DRCCOLS.active_power_case(case)
    # All systems use the same wind-only experiment. Known demand isolates the
    # proposed wind-error mechanism; the original paired load files are retained.
    case, data, diagnostics = DRCCOLS.apply_physical_stress(case, data, capacities;
        conventional_capacity_scale=capacity_scale, wind_error_multiplier=error_multiplier,
        error_scale=1.0, load_error_mode="known_forecast")
    return case, data, capacities, diagnostics
end

"Use the exact same pooled observations for global and regime formulations."
function shared_support(train, K, budget, seed; selector="shared_random")
    gmm = DRCCOLS.fit_diag_gmm(train, K; max_iter=100, seed=seed)
    rng = MersenneTwister(seed)
    if selector == "legacy_confidence"
        ids = DRCCOLS.representative_indices(gmm.gamma_train, 1.0;
            max_per_regime=budget, max_total=budget)
        global_ids = DRCCOLS.global_representative_indices(gmm.gamma_train, budget; mode="budgeted")
    else
        # Simple random sampling from the full training set preserves its empirical
        # distribution. Do not rank by posterior confidence or by test performance.
        pool = sort(randperm(rng, size(train,1))[1:min(budget,size(train,1))])
        hard = [argmax(@view gmm.gamma_train[i,:]) for i in axes(train,1)]
        # With full support, every nonempty hard-assignment regime is represented.
        # A smaller pilot budget is enlarged deterministically if a regime is absent.
        for k in 1:K
            candidates = findall(==(k),hard)
            isempty(candidates) && error("Empty GMM hard regime; use another K on validation")
            !any(i -> hard[i] == k, pool) && push!(pool, candidates[1])
        end
        sort!(pool)
        ids = [[i for i in pool if hard[i] == k] for k in 1:K]
        global_ids = pool
    end
    return (gmm=gmm, mixture=[train[i,:] for i in ids], global_reps=[train[global_ids,:]], ids=ids,
        global_ids=global_ids)
end

function solve_method(case, data, support, t, method, cfg)
    load = vec(data.load_forecast[t,:]); wind = vec(data.wind_forecast[t,:])
    if method == "deterministic_headroom"
        sol = DRCCOLS.solve_deterministic_ols(case, load, wind;
            time_limit=cfg["time_limit"], tie_breaker=1e-6, wind_spill_penalty=1e-3)
        return sol.has_values ? merge(sol, (rU=max.(case.gen[:,9].-sol.g,0.0),
            rD=max.(sol.g.-case.gen[:,10],0.0))) : sol
    end
    global_method = method in ("empirical_cvar", "single_tv")
    reps = global_method ? support.global_reps : support.mixture
    if get(cfg,"support_mapping","raw") == "bounded_headroom"
        index_sets = global_method ? [support.global_ids] : support.ids
        reps = [map_headroom_errors(case,support.support_training_features[ids,:],wind,support.capacities) for ids in index_sets]
    end
    pi = if global_method
        [1.0]
    elseif method == "mixture_static"
        support.gmm.weights
    else
        features = get(cfg,"support_mapping","raw") == "bounded_headroom" ? support.normalized_site_errors : data.omega
        history = DRCCOLS.responsibilities(support.gmm,features[max(1,t-cfg["window"]):t-1,:])
        DRCCOLS.rolling_weights_from_history(support.gmm, history, vec(features[t-1,:]);
            window=cfg["window"], kappa=cfg["kappa"], blend_rho=cfg["blend"])
    end
    radius = method == "empirical_cvar" ? 0.0 : cfg["rho"]
    delta = method == "proposed" ? cfg["delta"] : 0.0
    solver = get(cfg,"solver","full_lp") == "row_generation" ? solve_tv_cuts : DRCCOLS.solve_drcc_ols
    solver(case, load, wind, pi, reps, fill(radius,length(reps));
        epsilon=cfg["epsilon"], delta_w=delta, time_limit=cfg["time_limit"],
        )
end

"Normalize by the physical downward/upward headroom of each forecast."
function normalized_site_errors(data,capacities)
    errors=data.wind_actual.-data.wind_forecast
    z=similar(errors)
    for w in eachindex(capacities),i in axes(errors,1)
        denominator=errors[i,w]<0 ? data.wind_forecast[i,w] : capacities[w]-data.wind_forecast[i,w]
        z[i,w]=abs(denominator)<1e-9 ? 0.0 : clamp(errors[i,w]/denominator,-1.0,1.0)
    end
    return z
end

function map_headroom_errors(case,z,forecast,capacities)
    omega=zeros(size(z,1),size(case.bus,1))
    for w in eachindex(forecast),i in axes(z,1)
        e=z[i,w]*(z[i,w]<0 ? forecast[w] : capacities[w]-forecast[w])
        omega[i,case.wind_bus_idx[w]]+=e
    end
    return omega
end

"Physical replay with fixed dispatch/reserves and common real-time DC redispatch."
function physical_recourse(case, sol, load, actual_wind; policy="redispatch", omega=nothing,analytic=true)
    sol.has_values || return (status="NO_DISPATCH", emergency=NaN, residual=NaN,
        wind_spill=NaN, energy=NaN, balance_error=NaN, max_line_overload=NaN)
    nb=length(load); ng=length(sol.g); nw=length(actual_wind); nl=length(case.line_rates)
    if analytic && omega !== nothing
        # Check actual physical injections directly, including colocated farms.
        # Clipping planned absolute spill to availability changes the net error
        # by exactly max(planned spill - available wind,0). If this candidate
        # serves all scheduled load, it already attains all three LP priorities.
        used=max.(actual_wind.-sol.wind_spill,0.0)
        effective=sum(omega)+sum(max.(sol.wind_spill.-actual_wind,0.0))
        pg=sol.g.-sol.beta.*effective
        injection=zeros(nb)
        for j=1:ng;injection[case.gen_bus_idx[j]]+=pg[j];end
        for w=1:nw;injection[case.wind_bus_idx[w]]+=used[w];end
        injection.-=load.-sol.dL
        flow=case.ptdf*injection
        reserve_v=maximum(vcat(sol.beta.*effective.-sol.rD,-sol.beta.*effective.-sol.rU))
        line_v=maximum(abs.(flow).-case.line_rates;init=-Inf)
        berror=abs(sum(injection))
        if max(reserve_v,line_v)<=1e-8 && berror<=1e-8
            return (status="ANALYTIC_OPTIMAL",emergency=0.0,residual=0.0,
                wind_spill=sum(actual_wind.-used),energy=sol.load_shed,balance_error=berror,
                max_line_overload=max(line_v,0.0))
        end
    end
    # Real-time renewable generation is always between zero and available wind.
    # The scheduled absolute spill is clipped to realized availability; additional
    # spill is available as the same corrective action for every method.
    available = max.(actual_wind .- sol.wind_spill, 0.0)
    m=Model(HiGHS.Optimizer); set_silent(m)
    # Lexicographic bounds are tighter than the solver's default tolerance.
    set_optimizer_attribute(m,"primal_feasibility_tolerance",1e-9)
    set_optimizer_attribute(m,"dual_feasibility_tolerance",1e-9)
    @variable(m, max(case.gen[j,10],sol.g[j]-sol.rD[j]) <= pg[j=1:ng] <= min(case.gen[j,9],sol.g[j]+sol.rU[j]))
    @variable(m, 0 <= used[w=1:nw] <= available[w])
    @variable(m, 0 <= shed[b=1:nb] <= max(load[b]-sol.dL[b],0.0))
    @variable(m, balance_plus >= 0); @variable(m, balance_minus >= 0)
    @variable(m, line_slack[1:nl] >= 0)
    @constraint(m, sum(pg)+sum(used)+balance_plus-balance_minus == sum(load.-sol.dL)-sum(shed))
    @expression(m, flow[e=1:nl],
        sum(case.ptdf[e,case.gen_bus_idx[j]]*pg[j] for j=1:ng)+
        sum(case.ptdf[e,case.wind_bus_idx[w]]*used[w] for w=1:nw)-
        sum(case.ptdf[e,b]*(load[b]-sol.dL[b]-shed[b]) for b=1:nb))
    @constraint(m,[e=1:nl], flow[e] <= case.line_rates[e]+line_slack[e])
    @constraint(m,[e=1:nl], -flow[e] <= case.line_rates[e]+line_slack[e])
    if policy == "fixed_agc"
        omega === nothing && error("fixed_agc needs the nodal error")
        # Additional corrective spilling changes the net error just as shedding does.
        @expression(m, correction, sum(omega)+sum(shed)+sum(used)-sum(actual_wind)+sum(sol.wind_spill))
        @constraint(m,[j=1:ng],pg[j]==sol.g[j]-sol.beta[j]*correction)
    elseif policy != "redispatch"
        error("Unknown replay policy")
    end
    @expression(m, residual, balance_plus+balance_minus+sum(line_slack))
    # Exact lexicographic priorities: physical security, emergency shedding,
    # then renewable delivery. No security slack is counted as served energy.
    @objective(m,Min,residual); optimize!(m)
    termination_status(m)==MOI.OPTIMAL || error("Replay LP did not solve")
    rstar=value(residual)
    @constraint(m,residual <= rstar+1e-7)
    @objective(m,Min,sum(shed)); optimize!(m)
    termination_status(m)==MOI.OPTIMAL || error("Replay shedding LP did not solve")
    estar=value(sum(shed))
    @constraint(m,sum(shed)<=estar+1e-7)
    @objective(m,Max,sum(used)); optimize!(m)
    termination_status(m)==MOI.OPTIMAL || error("Replay renewable LP status=$(termination_status(m)); policy=$policy; residual=$rstar; emergency=$estar")
    berror=abs(sum(value.(pg))+sum(value.(used))-sum(load.-sol.dL.-value.(shed)))
    line_error=maximum(max.(abs.(value.(flow)).-case.line_rates,0.0);init=0.0)
    return (status=string(termination_status(m)), emergency=value(sum(shed)), residual=value(residual),
        wind_spill=sum(actual_wind)-sum(value.(used)), energy=sol.load_shed+value(sum(shed)),
        balance_error=berror, max_line_overload=line_error)
end
