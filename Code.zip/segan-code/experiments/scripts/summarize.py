from pathlib import Path
import argparse, json, tomllib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
METHODS=['deterministic_headroom','empirical_cvar','single_tv','mixture_static','mixture_rolling','proposed']
LABELS=['Det. + reserves','Empirical CVaR','Single-TV','Static mixture','Rolling mixture','Proposed']

def cvar(x, level=.95):
    x=np.asarray(x,float)
    if not len(x): return np.nan
    # Minimizer of the empirical Rockafellar-Uryasev expression, including
    # fractional probability mass when (1-level)*N is not an integer.
    v=np.quantile(x,level,method='higher')
    return v+np.maximum(x-v,0).mean()/(1-level)

def paired_ci(g, column, baseline='single_tv',candidate='proposed'):
    p=g.pivot(index=['time_index','day'],columns='method',values=column)
    if baseline not in p or candidate not in p: return None
    p=p[[baseline,candidate]].dropna()
    if not len(p):return None
    delta=p[candidate]-p[baseline]
    # Calendar-day paired clusters; sparse pilot states are explicitly labelled.
    days=p.index.get_level_values('day').unique()
    lo=hi=np.nan
    if len(days)>=7:
        rng=np.random.default_rng(20261021)
        daydelta=delta.groupby(level='day').agg(['sum','count'])
        ix=rng.integers(0,len(days),size=(2000,len(days)))
        means=daydelta['sum'].to_numpy()[ix].sum(axis=1)/daydelta['count'].to_numpy()[ix].sum(axis=1)
        lo,hi=np.quantile(means,[.025,.975])
    return dict(baseline=baseline,candidate=candidate,pairs=len(p),days=len(days),
        mean_difference_mwh=delta.mean(),baseline_mean_mwh=p[baseline].mean(),
        candidate_mean_mwh=p[candidate].mean(),ci95_low=lo,ci95_high=hi,
        ens_reduction_pct=100*(p[baseline].sum()-p[candidate].sum())/p[baseline].sum() if p[baseline].sum()>1e-8 else np.nan)

def main(study):
    folder=ROOT/'results'/study
    files=sorted(folder.glob('*/hourly.csv'))
    if not files:raise SystemExit('No hourly data')
    frames=[];summaries=[];pairs=[]
    for f in files:
        d=pd.read_csv(f);frames.append(d)
        event_column='clipped_policy_violated' if 'clipped_policy_violated' in d else 'raw_policy_violated'
        cfg=json.loads((f.parent/'config_used.json').read_text('utf-8'))
        expected=len(cfg['days'])*len(cfg['hours'])
        for method,g in d.groupby('method',sort=False):
            ok=g[g.status.eq('OPTIMAL')]
            x=ok.fixed_agc_ens_mwh.dropna()
            complete=len(ok)==expected and len(g)==expected
            summaries.append(dict(system=g.system.iloc[0],method=method,expected_hours=expected,
                recorded_hours=len(g),optimal_hours=len(ok),complete=complete,
                total_ens_mwh=x.sum() if complete else np.nan,
                observed_mean_ens_mwh=x.mean(),observed_preventive_mwh=ok.preventive_mwh.mean(),
                observed_emergency_mwh=ok.fixed_agc_emergency_mwh.mean(),
                observed_nens_ppm=1e6*x.sum()/ok.forecast_load_mwh.sum() if len(ok) else np.nan,
                observed_joint_violation_pct=100*ok[event_column].mean(),
                observed_residual_pct=100*(ok.fixed_agc_residual_mw>1e-5).mean() if len(ok) else np.nan,
                observed_emergency_hour_pct=100*(ok.fixed_agc_emergency_mwh>1e-5).mean() if len(ok) else np.nan,
                observed_redispatch_ens_mwh=ok.redispatch_ens_mwh.mean(),
                observed_cvar95_ens_mwh=cvar(x),observed_max_ens_mwh=x.max(),
                mean_up_reserve_mw=ok.reserve_up_mw.mean(),mean_down_reserve_mw=ok.reserve_down_mw.mean(),
                mean_solve_seconds=ok.solve_seconds.mean(),p95_solve_seconds=ok.solve_seconds.quantile(.95)))
        for column in ('fixed_agc_ens_mwh','redispatch_ens_mwh','preventive_mwh','fixed_agc_emergency_mwh'):
            p=paired_ci(d[d.status.eq('OPTIMAL')],column)
            if p:pairs.append(dict(system=d.system.iloc[0],metric=column,**p))
    s=pd.DataFrame(summaries);s.to_csv(folder/'summary.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(pairs).to_csv(folder/'paired_comparisons.csv',index=False,encoding='utf-8-sig')
    allrows=pd.concat(frames,ignore_index=True)
    audit_cols=['fixed_balance_error_mw','fixed_line_overload_mw','redispatch_balance_error_mw','redispatch_line_overload_mw']
    checks={c:float(allrows[c].max()) for c in audit_cols}
    checks['recorded_rows']=len(allrows)
    checks['optimal_rows']=int(allrows.status.eq('OPTIMAL').sum())
    (folder/'verification.json').write_text(json.dumps(checks,indent=2),'utf-8')
    fig,axes=plt.subplots(1,len(frames),figsize=(5*len(frames),4.5),squeeze=False)
    colors=plt.get_cmap('tab10').colors
    for ax,(system,g) in zip(axes[0],s.groupby('system',sort=True)):
        for i,method in enumerate(METHODS):
            a=g[g.method.eq(method)]
            if a.empty:continue
            r=a.iloc[0]
            ax.scatter(r.observed_joint_violation_pct,r.observed_mean_ens_mwh,
                marker='*' if method=='proposed' else 'o',s=180 if method=='proposed' else 60,
                c=[colors[i]],label=LABELS[i])
        ax.set_title(system.upper());ax.set_xlabel('Pre-correction joint violations (%)')
        ax.set_ylabel('Mean total ENS (MWh per evaluated hour)');ax.grid(alpha=.2)
    handles,labels=axes[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',ncol=3,frameon=False)
    fig.tight_layout(rect=(0,.15,1,1));fig.savefig(folder/'energy_security.png',dpi=180);plt.close(fig)
    lines=[f'# {study}: recorded experiment results','',
        'Metrics are evaluated on the fixed calendar. ENS includes preventive and emergency shedding. '
        'Pre-correction affine-policy violations and post-correction physical security are separate metrics. '
        'Raw and bounded-support studies use different uncertainty inputs and should be interpreted as distinct experiments.','',
        '|System|Method|Optimal / planned|Mean ENS (MWh)|Emergency (MWh)|Joint violation (%)|Residual (%)|',
        '|---|---|---:|---:|---:|---:|---:|']
    for r in s.itertuples():
        lines.append(f'|{r.system}|{r.method}|{r.optimal_hours}/{r.expected_hours}|{r.observed_mean_ens_mwh:.3f}|{r.observed_emergency_mwh:.3f}|{r.observed_joint_violation_pct:.2f}|{r.observed_residual_pct:.2f}|')
    lines += ['','All means use the stated solved-hour denominator. A full-calendar total is emitted only for complete runs. '
        'Paired estimates and day-cluster intervals are in paired_comparisons.csv; intervals require at least seven evaluated days. '
        'These are study-period operational metrics, with no annualization.','',
        '![Energy and security](energy_security.png)']
    (folder/'RESULTS.md').write_text('\n'.join(lines)+'\n','utf-8')
    print(s[['system','method','optimal_hours','expected_hours','observed_mean_ens_mwh','observed_joint_violation_pct']].to_string(index=False))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('study');a=p.parse_args();main(a.study)
