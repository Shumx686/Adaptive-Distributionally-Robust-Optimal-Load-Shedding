"""Verify and combine four separately recorded seasonal partitions."""
from pathlib import Path
import hashlib
import json
import tomllib
import sys
import pandas as pd

root = Path(__file__).resolve().parents[1]
name = sys.argv[1] if len(sys.argv)>1 else 'joint_test_rts79_576h'
config_path = root/'config'/f'{name}.toml'
cfg = tomllib.loads(config_path.read_text('utf-8'))
config_hash = hashlib.sha256(config_path.read_bytes()).hexdigest()
frames = []
sources = []
for part in range(1,5):
    folder = root/'results'/f'{name}_part{part}'/'rts79'
    assert (folder/'completed.json').exists(), f'Partition {part} is still running'
    source_cfg = json.loads((folder/'config_used.json').read_text('utf-8'))
    for key in ('methods','hours','train_hours','budget','K','seed','capacity_scale',
                'support_mapping','epsilon','method_parameters','selection_sha256'):
        assert source_cfg[key] == cfg[key], f'Partition mismatch: {key}'
    if 'training_end_hours_by_day' in cfg:
        day=source_cfg['days'][0]
        assert source_cfg['days']==list(range(day,day+len(source_cfg['days'])))
        assert source_cfg['training_end_hour']==cfg['training_end_hours_by_day'][str(day)]==24*(day-1)
        support=json.loads((folder/'support.json').read_text('utf-8'))
        assert support['training_source_indices']==list(range(24*(day-1)-719,24*(day-1)+1))
    d = pd.read_csv(folder/'hourly.csv')
    expected = len(source_cfg['days'])*len(source_cfg['hours'])*len(cfg['methods'])
    assert len(d) == expected and not d.duplicated(['method','time_index']).any()
    assert d.config_hash.eq(source_cfg['sha256']).all()
    d['source_config_hash'] = d.config_hash
    d['config_hash'] = config_hash
    d['source_partition'] = part
    frames.append(d)
    sources.append({'partition':part,'rows':len(d),'sha256':source_cfg['sha256']})
d = pd.concat(frames,ignore_index=True).sort_values(['time_index','method'])
expected_indices = {24*(day-1)+hour for day in cfg['days'] for hour in cfg['hours']}
for method,g in d.groupby('method'):
    assert set(g.time_index)==expected_indices and len(g)==len(expected_indices)
assert not d.duplicated(['method','time_index']).any()
out = root/'results'/name/'rts79'
out.mkdir(parents=True,exist_ok=True)
d.to_csv(out/'hourly.csv',index=False)
(out/'config_used.json').write_text(json.dumps(dict(cfg,sha256=config_hash,system='rts79'),indent=2),'utf-8')
(out/'completed.json').write_text(json.dumps({'rows':len(d),'expected_rows':len(expected_indices)*len(cfg['methods']),
    'config_hash':config_hash,'source_partitions':sources,'merge_rule':'No averaging or filtering; four disjoint seasonal calendars concatenated; source hashes retained per row.'},indent=2),'utf-8')
print(d.groupby('method').agg(hours=('time_index','size'),optimal=('status',lambda x:x.eq('OPTIMAL').sum()),
    total_ens_mwh=('fixed_agc_ens_mwh','sum')).to_string())
