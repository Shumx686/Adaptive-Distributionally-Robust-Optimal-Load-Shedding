from pathlib import Path
import json
import numpy as np
import pandas as pd

folder=Path(__file__).resolve().parents[1]/'results/joint_validation_rts79_v2'
shortlist=json.loads((folder/'shortlist.json').read_text('utf-8'))
master=folder/'confirm_hourly.csv'
frames=[pd.read_csv(master)] if master.exists() else []
for c in shortlist:
    fragment=folder/f'confirm_part_{c["candidate"]}_hourly.csv'
    if fragment.exists():frames.append(pd.read_csv(fragment))
d=pd.concat(frames,ignore_index=True)
indices=set(pd.read_csv(folder/'confirm_target_indices.csv').time_index)
for (candidate,t),g in d.groupby(['candidate','time_index']):
    assert g.status.nunique()==1
    for column in ['ens_mwh','scenario_eens_mwh','scenario_risk']:
        assert np.ptp(g[column])<1e-6,(candidate,t,column)
d=d.drop_duplicates(['candidate','time_index'],keep='last')
for c in shortlist:
    g=d[d.candidate.eq(c['candidate'])]
    assert len(g)==len(indices) and set(g.time_index)==indices,c['candidate']
d=d.sort_values(['candidate','time_index'])
temporary=master.with_suffix('.merged.csv')
d.to_csv(temporary,index=False);temporary.replace(master)
print(d.groupby('candidate').agg(hours=('time_index','size'),mean_ens=('ens_mwh','mean')).to_string())
