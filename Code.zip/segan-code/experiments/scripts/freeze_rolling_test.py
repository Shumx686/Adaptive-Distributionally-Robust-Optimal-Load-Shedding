from pathlib import Path
import json
import tomllib

work=Path(__file__).resolve().parents[1]
protocol=json.loads((work/'config/rolling_operational_protocol.json').read_text('utf-8'))
basepath=work/'config/joint_test_rts79_576h.toml'
base=tomllib.loads(basepath.read_text('utf-8'))
name=protocol['name']
days=[d+j for d in protocol['block_start_days'] for j in range(protocol['days_per_block'])]
content=basepath.read_text('utf-8')
content=content.replace('name = "joint_test_rts79_576h"',f'name = "{name}"',1)
content=content.replace(f'days = {json.dumps(base["days"])}',f'days = {json.dumps(days)}',1)
content=content.replace(f'methods = {json.dumps(base["methods"])}',f'methods = {json.dumps(protocol["methods"])}',1)
content=content.replace('stage = "test"','stage = "test"\ntraining_scheme = "preceding_720_each_six_day_block"',1)
parent=content+'\n[training_end_hours_by_day]\n'+''.join(
    f'"{d}" = {24*(d-1)}\n' for d in protocol['block_start_days'])

def freeze(path,text):
    if path.exists():assert path.read_text('utf-8')==text,'Frozen configuration changed'
    else:path.write_text(text,'utf-8')
    print(path.name)

freeze(work/'config'/f'{name}.toml',parent)
for part,start in enumerate(protocol['block_start_days'],1):
    chunk=list(range(start,start+protocol['days_per_block']))
    text=content.replace(f'name = "{name}"',f'name = "{name}_part{part}"',1)
    text=text.replace(f'days = {json.dumps(days)}',f'days = {json.dumps(chunk)}',1)
    text=text.replace('stage = "test"',f'stage = "test"\ntraining_end_hour = {24*(start-1)}',1)
    freeze(work/'config'/f'{name}_part{part}.toml',text)
