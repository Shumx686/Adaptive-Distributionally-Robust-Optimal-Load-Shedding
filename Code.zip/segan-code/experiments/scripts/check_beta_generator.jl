using Random,Statistics,Test,TOML
include("beta_generator.jl")
N=100000;rng=MersenneTwister(20261021);stats=Dict{String,Any}()
@testset "Beta sampling agrees with configured analytic moments" begin
    for (k,mu,sigma) in ((1,.25,.05),(2,.5,.07),(3,.75,.05))
        samples=[beta_draw(rng,mu,sigma) for _=1:N]
        @test all((0 .< samples).&(samples.<1))
        @test abs(mean(samples)-mu)<5sigma/sqrt(N)
        @test abs(std(samples)-sigma)<.02sigma
        stats["regime_$k"]=Dict("draws"=>N,"target_mean"=>mu,"sample_mean"=>mean(samples),
            "target_sd"=>sigma,"sample_sd"=>std(samples))
    end
end
out=joinpath(@__DIR__,"..","results","controlled_beta");mkpath(out)
open(joinpath(out,"sampler_validation.toml"),"w") do io;TOML.print(io,stats);end
