#= Paired full-TV-LP / row-generation validation on predeclared benchmark inputs.

Design basis: Velloso, Van Hentenryck and Johnson (EPSR 195, 2021, 106677),
Section 4, Tables 1-2 and Fig. 1: compare the extensive formulation with row
generation using model size, time, iterations and convergence bounds. Here both
solvers solve our *same continuous finite-support TV-LP*, not their SCOPF MILP.
No operating context is selected using the solver comparison results.
=#
include("common.jl")
include("beta_generator.jl")
using SHA

const OUT=joinpath(WORK,"results","solver_assessment")
mkpath(OUT)
const SOURCE=Dict("doi"=>"10.1016/j.epsr.2020.106677",
    "published_full_text"=>"https://par.nsf.gov/servlets/purl/10300728",
    "locator"=>"Section 4; Tables 1-2; Figure 1",
    "transfer"=>"extensive-form comparison, size, time, iterations and objective convergence",
    "distinction"=>"our continuous TV-LP; no contingency disjunctions or borrowed MIP gap")
const PROTOCOL=Dict("systems"=>["rbts","rts79","gmlc"],"replication"=>1,
    "seed"=>20261122,"contexts"=>[1,2,3],"retained_support_budgets"=>[120,720],
    "training_observations"=>720,"rho"=>0.01,"delta_w"=>0.10,"epsilon"=>0.05,
    "time_limit_seconds_per_method"=>600.0,"separation_tolerance_mw"=>1e-6,
    "solver_threads"=>1,"blas_threads"=>1,"warmup_support_budget"=>40,
    "timing"=>"one paired run per instance after per-network warmup; wall time includes construction and separation, excludes audit; alternating method order",
    "case_selection"=>"all three predefined contexts of first frozen controlled replication, at both support sizes",
    "reference"=>SOURCE)
protocol_file=joinpath(OUT,"protocol.json")
if isfile(protocol_file)
    JSON.parsefile(protocol_file)==PROTOCOL || error("Assessment protocol changed")
else
    open(io->JSON.print(io,PROTOCOL,2),protocol_file,"w")
end

function inputs(system)
    case,source,capacities,_=load_system(system;capacity_scale=.85)
    seed=PROTOCOL["seed"]; n=2160; nw=length(capacities); nb=size(case.bus,1)
    means=[.25,.5,.75];sds=[.05,.07,.05];prior=[.3,.4,.3];persistence=.95
    sr=MersenneTwister(seed);wr=MersenneTwister(seed+1)
    states=zeros(Int,n);states[1]=category(sr,prior)
    for t=2:n;states[t]=rand(sr)<persistence ? states[t-1] : category(sr,prior);end
    forecast=0.5 .* capacities
    load_total=sum(case.gen[:,9])+0.25*sum(capacities)
    profile=vec(source.load_forecast[24*(181-1)+13,:]);load=profile./sum(profile).*load_total
    omega=zeros(n,nb)
    for t=1:n,w=1:nw
        actual=capacities[w]*beta_draw(wr,means[states[t]],sds[states[t]])
        omega[t,case.wind_bus_idx[w]]+=actual-forecast[w]
    end
    frozen=JSON.parsefile(joinpath(WORK,"results","controlled_beta_repetitions","rep01",system,"protocol.json"))
    @assert frozen["seed"]==seed && frozen["load_total_mw"]≈load_total
    contexts=[first([t for t=1441:n if all(==(k),states[t-12:t-1])]) for k=1:3]
    @assert contexts==frozen["contexts"]
    return case,load,forecast,omega,contexts,frozen["weight_parameters"]
end

function audit(m,case,load,wind,sol,reps)
    violations=primal_feasibility_report(m;atol=0.0)
    primal_max=isempty(violations) ? 0.0 : maximum(values(violations))
    obj=objective_value(m);dobj=dual_objective_value(m)
    injection=-(load.-sol.dL)
    for j in eachindex(sol.g);injection[case.gen_bus_idx[j]]+=sol.g[j];end
    for w in eachindex(wind);injection[case.wind_bus_idx[w]]+=wind[w]-sol.wind_spill[w];end
    base=case.ptdf*injection
    agc=case.ptdf[:,case.gen_bus_idx]*sol.beta
    z=value.(m[:zeta]);ta=sol.tau;separation=0.0
    for k in eachindex(reps),i in axes(reps[k],1)
        om=vec(reps[k][i,:]);os=sum(om);flows=base+case.ptdf*om-agc.*os
        loss=maximum(vcat(sol.beta.*os.-sol.rD,-sol.beta.*os.-sol.rU,
            flows-case.line_rates,-flows-case.line_rates))
        s=value(variable_by_name(m,"s_$(k)[$i]"))
        separation=max(separation,loss-s-z[k]-ta)
    end
    return (max_scalar_constraint_violation=primal_max,
        primal_dual_objective_gap=abs(obj-dobj),
        relative_primal_dual_gap=abs(obj-dobj)/max(1.0,abs(obj)),
        all_support_separation_mw=separation,balance_residual_mw=abs(sum(injection)),
        participation_residual=abs(sum(sol.beta)-1),risk_lhs=sol.risk_lhs,
        primal_status=string(primal_status(m)),dual_status=string(dual_status(m)),
        primal_tolerance=get_optimizer_attribute(m,"primal_feasibility_tolerance"),
        dual_tolerance=get_optimizer_attribute(m,"dual_feasibility_tolerance"))
end

function pair(case,load,wind,reps,pi;id,warmup=false,reverse_order=false)
    records=Dict{String,Any}();trace=NamedTuple[]
    methods=reverse_order ? ["cuts","full"] : ["full","cuts"]
    for method in methods
        holder=Ref{Any}(nothing)
        callback=m->(holder[]=m)
        started=time_ns()
        sol=if method=="full"
            DRCCOLS.solve_drcc_ols(case,load,wind,pi,reps,fill(.01,length(reps));
                epsilon=.05,delta_w=.10,time_limit=600.0,audit_callback=callback,
                solver_options=Dict("threads"=>1))
        else
            solve_tv_cuts(case,load,wind,pi,reps,fill(.01,length(reps));
                epsilon=.05,delta_w=.10,time_limit=600.0,tolerance=1e-6,
                audit_callback=callback,solver_options=Dict("threads"=>1),
                iteration_callback=r->push!(trace,r))
        end
        elapsed=(time_ns()-started)/1e9
        a=sol.has_values ? audit(holder[],case,load,wind,sol,reps) : nothing
        records[method]=Dict("status"=>sol.status,"objective"=>sol.objective,
            "solver_seconds"=>sol.solve_time,"wall_seconds"=>elapsed,
            "variables"=>sol.lp_variables,"constraints"=>sol.lp_constraints,
            "audit"=>a===nothing ? nothing : Dict(string(k)=>v for (k,v) in pairs(a)))
        holder[]=nothing;GC.gc()
    end
    if !warmup
        CSV.write(joinpath(OUT,id*"_trace.csv"),DataFrame(trace))
        open(io->JSON.print(io,records,2),joinpath(OUT,id*".json"),"w")
    end
    return records
end

function main()
    systems=isempty(ARGS) ? PROTOCOL["systems"] : ARGS
    for system in systems
        case,load,wind,omega,contexts,profile=inputs(system)
        warm=shared_support(omega[1:720,:],3,40,PROTOCOL["seed"])
        pair(case,load,wind,warm.mixture,warm.gmm.weights;id="warmup",warmup=true)
        println("WARMUP_COMPLETE ",system);flush(stdout)
        for budget in PROTOCOL["retained_support_budgets"]
            support=shared_support(omega[1:720,:],3,budget,PROTOCOL["seed"])
            for context in PROTOCOL["contexts"]
                id="$(system)_q$(budget)_c$(context)"
                isfile(joinpath(OUT,id*".json")) && continue
                t=contexts[context];window=Int(profile["window"])
                history=DRCCOLS.responsibilities(support.gmm,omega[t-window:t-1,:])
                pi=DRCCOLS.rolling_weights_from_history(support.gmm,history,vec(omega[t-1,:]);
                    window=window,kappa=profile["kappa"],blend_rho=profile["blend"])
                payload=Dict("load"=>load,"wind"=>wind,"weights"=>pi,
                    "support_indices"=>support.ids,"support"=>support.mixture)
                open(io->JSON.print(io,Dict("time_index"=>t,"budget"=>budget,
                    "input_sha256"=>bytes2hex(sha256(JSON.json(payload))))),joinpath(OUT,id*"_input.json"),"w")
                result=pair(case,load,wind,support.mixture,pi;id=id,reverse_order=isodd(context+budget÷120))
                println("CASE_COMPLETE ",id," full=",result["full"]["status"],
                    " cuts=",result["cuts"]["status"]," wall_full=",result["full"]["wall_seconds"],
                    " wall_cuts=",result["cuts"]["wall_seconds"]);flush(stdout)
            end
        end
    end
    sources=[@__FILE__,joinpath(@__DIR__,"tv_dispatch.jl"),joinpath(PROJECT,"src","DRCCOLS.jl")]
    open(io->JSON.print(io,Dict("julia"=>string(VERSION),"highs_jl"=>string(pkgversion(HiGHS)),
        "sources"=>Dict(relpath(p,ROOT)=>bytes2hex(sha256(read(p))) for p in sources)),2),
        joinpath(OUT,"implementation.json"),"w")
end
main()
