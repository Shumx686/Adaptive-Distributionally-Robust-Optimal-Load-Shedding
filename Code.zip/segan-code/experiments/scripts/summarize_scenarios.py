from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

STUDY=sys.argv[1] if len(sys.argv)>1 else 'scenario_stress'
ROOT=Path(__file__).resolve().parents[1]/'results'/STUDY
tables=[];pairs=[]
for f in sorted(ROOT.glob('*/security_summary.csv')):
    d=pd.read_csv(f);system=f.parent.name
    for method,g in d.groupby('method',sort=False):
        valid=g[g.status.eq('OPTIMAL')]
        tables.append(dict(system=system,method=method,optimal_states=len(valid),planned_states=4,
            tests=int(valid.n_scenarios.sum()),mean_joint_violation_pct=valid.joint_violation_pct.mean(),
            mean_preventive_mwh=valid.preventive_mwh.mean(),mean_positive_violation_mw=valid.mean_positive_violation_mw.mean(),
            max_violation_mw=valid.max_violation_mw.max(),mean_solve_seconds=valid.solve_seconds.mean()))
    for baseline in ('single_tv','mixture_static','mixture_rolling'):
        matching=[]
        for t in sorted(d.time_index.unique()):
            a=f.parent/f'scenarios_{t}_{baseline}.csv';b=f.parent/f'scenarios_{t}_proposed.csv'
            if not a.exists() or not b.exists():continue
            x=pd.read_csv(a);y=pd.read_csv(b)
            p=x.merge(y,on=['source_index','source_day'],suffixes=('_base','_prop'),validate='one_to_one')
            p['difference']=p.violated_prop.astype(int)-p.violated_base.astype(int)
            matching.append(p[['source_day','difference']])
        if matching:
            p=pd.concat(matching);byday=p.groupby('source_day').difference.agg(['sum','count'])
            rng=np.random.default_rng(20261021)
            idx=rng.integers(0,len(byday),size=(2000,len(byday)))
            rates=100*byday['sum'].to_numpy()[idx].sum(axis=1)/byday['count'].to_numpy()[idx].sum(axis=1)
            lo,hi=np.quantile(rates,[.025,.975])
            pairs.append(dict(system=system,baseline=baseline,candidate='proposed',paired_states=len(matching),
                paired_checks=len(p),difference_percentage_points=100*p.difference.mean(),ci95_low=lo,ci95_high=hi))
s=pd.DataFrame(tables);s.to_csv(ROOT/'summary.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(pairs).to_csv(ROOT/'paired_security.csv',index=False,encoding='utf-8-sig')
lines=['# Fixed operating contexts: 1,000 held-out error records per context','',
       'Each system uses four predefined seasonal operating contexts. Test errors are sampled without replacement '
       'from records outside the training interval, then mapped through the current forecast headroom. '
       'All methods share the source row IDs. These are operational stress checks; repeated contexts do not multiply '
       'the number of distinct historical error observations.','',
       '|System|Method|Solved states|Scenario checks|Preventive (MWh/state)|Joint violations (%)|',
       '|---|---|---:|---:|---:|---:|']
if STUDY=='contextual_stress':
    lines[2]=('Each context uses the 1,000 nearest held-out records based only on forecast wind, '
              'lagged normalized wind error and its trailing 48-hour mean. Feature scales are fitted '
              'on the training interval. The target realized error is not used in matching. All methods '
              'share the matched source rows, and fixed dispatches are reused from scenario_stress. '
              'This is an empirical approximation to conditional evaluation, preserving cross-farm error vectors.')
for r in s.itertuples():
    lines.append(f'|{r.system}|{r.method}|{r.optimal_states}/{r.planned_states}|{r.tests}|{r.mean_preventive_mwh:.3f}|{r.mean_joint_violation_pct:.2f}|')
lines += ['','The security metric limits scheduled wind spilling to realized wind availability before testing '
          'the fixed affine policy. No emergency correction is included in this probability. '
          'Source-day paired bootstrap intervals are supplied in paired_security.csv. A parameter point is a trade-off '
          'observation; method comparison at a target risk requires validation-calibrated frontiers.']
(ROOT/'RESULTS.md').write_text('\n'.join(lines)+'\n','utf-8')
systems=sorted(s.system.unique());fig,axes=plt.subplots(1,len(systems),figsize=(5*len(systems),4.5),squeeze=False)
methods=['empirical_cvar','single_tv','mixture_static','mixture_rolling','proposed']
labels=['Empirical','Single-TV','Static','Rolling','Proposed'];colors=plt.get_cmap('tab10').colors
for ax,system in zip(axes[0],systems):
    g=s[s.system.eq(system)]
    for i,method in enumerate(methods):
        z=g[g.method.eq(method)]
        if z.empty:continue
        r=z.iloc[0]
        ax.scatter(r.mean_joint_violation_pct,r.mean_preventive_mwh,
            marker='*' if method=='proposed' else 'o',s=180 if method=='proposed' else 65,
            c=[colors[i]],label=labels[i],clip_on=False)
    ax.axvline(5,c='.6',ls='--',lw=1);ax.set_title(system.upper());ax.grid(alpha=.2)
    ax.set_xlabel('Joint violations across test contexts (%)');ax.set_ylabel('Mean preventive shedding (MWh/state)')
    ax.set_ylim(bottom=0)
h,l=axes[0,0].get_legend_handles_labels();fig.legend(h,l,loc='lower center',ncol=5,frameon=False)
fig.tight_layout(rect=(0,.1,1,1));fig.savefig(ROOT/'service_security.png',dpi=180);plt.close(fig)
print(s.to_string(index=False))
