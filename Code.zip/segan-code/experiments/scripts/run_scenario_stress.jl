include("common.jl")
using SHA
length(ARGS)==1 || error("Usage: run_scenario_stress.jl <rbts|rts79|gmlc>")
cfgpath=joinpath(WORK,"config","scenario_stress.toml")
cfg=TOML.parsefile(cfgpath);system=ARGS[1]
out=joinpath(WORK,"results",cfg["name"],system);mkpath(out)
case,data,capacities,_=load_system(system;capacity_scale=cfg["capacity_scale"])
features=normalized_site_errors(data,capacities)
train=features[1:cfg["train_hours"],:]
support=shared_support(train,cfg["K"],cfg["budget"],cfg["seed"])
support=merge(support,(normalized_site_errors=features,support_training_features=train,capacities=capacities))
states=[24*(d-1)+h for d in cfg["days"] for h in cfg["hours"]]
# Common held-out observations, selected without replacement, not 1,000
# bootstrap copies of a short 96-hour block. The same IDs serve every method.
pool=setdiff(collect(1441:size(features,1)),states)
ids=sort(shuffle(MersenneTwister(cfg["seed"]),pool)[1:cfg["test_scenarios"]])
CSV.write(joinpath(out,"test_sample_indices.csv"),DataFrame(source_index=ids,source_time=data.times[ids]))
open(joinpath(out,"config_used.json"),"w") do io
    JSON.print(io,merge(cfg,Dict("config_sha256"=>bytes2hex(sha256(read(cfgpath))),"system"=>system)),2)
end
file=joinpath(out,"security_summary.csv")
rows=isfile(file) ? CSV.read(file,DataFrame;stringtype=String,pool=false) : DataFrame()
seen=Set(isempty(rows) ? Tuple{Int,String}[] : [(Int(r.time_index),String(r.method)) for r in eachrow(rows)])
for t in states
    load=vec(data.load_forecast[t,:]);forecast=vec(data.wind_forecast[t,:])
    omega=map_headroom_errors(case,features[ids,:],forecast,capacities)
    site_actual=zeros(length(ids),length(capacities))
    for w in eachindex(capacities),i in eachindex(ids)
        z=features[ids[i],w]
        site_actual[i,w]=forecast[w]+z*(z<0 ? forecast[w] : capacities[w]-forecast[w])
    end
    for method in cfg["methods"]
        (t,method) in seen && continue
        sol=solve_method(case,data,support,t,method,cfg)
        path=joinpath(out,"dispatch_$(t)_$(method).json")
        open(path,"w") do io; JSON.print(io,Dict(string(k)=>getproperty(sol,k) for k in keys(sol)),2);end
        if sol.has_values
            adjusted=copy(omega)
            for w in eachindex(capacities)
                adjusted[:,case.wind_bus_idx[w]].+=max.(sol.wind_spill[w].-site_actual[:,w],0.0)
            end
            # Evaluate the same affine policy after scheduled curtailment has
            # been limited by available wind. No emergency correction here.
            vals=[DRCCOLS.max_violation(case,sol,load,forecast,vec(adjusted[i,:])) for i in eachindex(ids)]
            raw=[DRCCOLS.max_violation(case,sol,load,forecast,vec(omega[i,:])) for i in eachindex(ids)]
            violations=vals.>1e-6
            push!(rows,(system=system,time_index=t,time=data.times[t],method=method,status=sol.status,
                n_scenarios=length(ids),distinct_error_rows=length(unique(ids)),
                preventive_mwh=sol.load_shed,mean_up_reserve_mw=sum(sol.rU),mean_down_reserve_mw=sum(sol.rD),
                joint_violation_pct=100mean(violations),model_affine_violation_pct=100mean(raw.>1e-6),
                mean_positive_violation_mw=mean(max.(vals,0.0)),max_violation_mw=maximum(max.(vals,0.0)),
                scheduled_spill_adjustment_pct=100mean(vec(any(site_actual.<sol.wind_spill',dims=2))),
                solve_seconds=sol.solve_time))
            per=DataFrame(source_index=ids,source_day=cld.(ids,24),max_violation_mw=vals,
                model_max_violation_mw=raw,violated=violations)
            CSV.write(joinpath(out,"scenarios_$(t)_$(method).csv"),per)
        else
            push!(rows,(system=system,time_index=t,time=data.times[t],method=method,status=sol.status,
                n_scenarios=length(ids),distinct_error_rows=length(unique(ids)),preventive_mwh=NaN,
                mean_up_reserve_mw=NaN,mean_down_reserve_mw=NaN,joint_violation_pct=NaN,
                model_affine_violation_pct=NaN,mean_positive_violation_mw=NaN,max_violation_mw=NaN,
                scheduled_spill_adjustment_pct=NaN,solve_seconds=sol.solve_time))
        end
        CSV.write(file,rows)
        println(system," state=",t," ",method," ",sol.status," OOS joint % = ",rows.joint_violation_pct[end]);flush(stdout)
    end
end
open(joinpath(out,"completed.json"),"w") do io
    JSON.print(io,Dict("states"=>length(states),"methods"=>length(cfg["methods"]),
        "rows"=>nrow(rows),"checks"=>length(states)*length(cfg["methods"])*length(ids)),2)
end
