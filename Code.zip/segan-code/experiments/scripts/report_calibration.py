from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
folder=ROOT/'results/weight_calibration'
systems=['rbts','rts79','gmlc']
fig,axes=plt.subplots(1,3,figsize=(15,4.6))
summary=[]
for ax,system in zip(axes,systems):
    f=folder/system/'selected_weights.json'
    if not f.exists():continue
    w=json.loads(f.read_text('utf-8'));d=pd.read_csv(f.parent/'validation_scores.csv')
    for blend in (0.,.25,.5,.75,1.):
        g=d[(d.method=='adaptive')&(d.blend==blend)&(d.kappa==w['kappa'])].sort_values('window')
        ax.plot(g.window,g.cross_entropy,'o-',lw=1.3,ms=4,label=f'Blend {blend:g}')
    ax.axhline(w['static_cross_entropy'],ls='--',c='.5',label='Static weights')
    ax.scatter([w['window']],[w['cross_entropy']],marker='*',s=170,c='black',zorder=5,label='Selected')
    ax.set_xscale('log',base=2);ax.set_xticks([6,12,24,48,96],labels=['6','12','24','48','96'])
    ax.set_title(f'{system.upper()} (kappa={w["kappa"]:g})');ax.set_xlabel('Rolling window (hours)')
    ax.set_ylabel('Validation cross-entropy');ax.grid(alpha=.2)
    summary.append(dict(system=system,window=w['window'],blend=w['blend'],kappa=w['kappa'],
        static_cross_entropy=w['static_cross_entropy'],selected_cross_entropy=w['cross_entropy'],
        cross_entropy_reduction_pct=100*(1-w['cross_entropy']/w['static_cross_entropy']),
        static_brier=w['static_brier'],selected_brier=w['brier']))
h,l=axes[0].get_legend_handles_labels();fig.legend(h,l,loc='lower center',ncol=4,frameon=False)
fig.tight_layout(rect=(0,.16,1,1));fig.savefig(folder/'weight_validation.png',dpi=180);plt.close(fig)
pd.DataFrame(summary).to_csv(folder/'summary.csv',index=False,encoding='utf-8-sig')
for f in (ROOT/'results/calibration').glob('*/candidate_summary.csv'):
    d=pd.read_csv(f);fig,ax=plt.subplots(figsize=(6.5,4.6))
    for method,label,marker in [('single_tv','Single-TV','o'),('proposed','Adaptive mixture','*')]:
        g=d[d.method.eq(method)&d.complete]
        ax.scatter(100*g.mean_joint_violation_rate,g.mean_ens_mwh,s=100 if marker=='*' else 55,marker=marker,label=label)
    ax.axvline(5,c='.5',ls='--',lw=1)
    ax.set_xlabel('Validation joint violations (%)');ax.set_ylabel('Mean realized total ENS (MWh/state)')
    ax.set_title(f'{f.parent.name.upper()}: radius grid, reference weights');ax.legend(frameon=False);ax.grid(alpha=.2)
    ax.set_ylim(bottom=0)
    fig.tight_layout();fig.savefig(f.parent/'validation_frontier.png',dpi=180);plt.close(fig)
print(pd.DataFrame(summary).to_string(index=False))
