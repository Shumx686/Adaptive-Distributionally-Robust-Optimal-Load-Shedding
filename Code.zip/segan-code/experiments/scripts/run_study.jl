include("common.jl")
using SHA
length(ARGS)>=2 || error("Usage: run_study.jl <config.toml> <rbts|rts79|gmlc>")
cfg=TOML.parsefile(ARGS[1]); system=ARGS[2]
haskey(cfg,"training_end_hours_by_day") && error("Run the four support-refresh partition configurations separately")
system in cfg["systems"] || error("System not in the frozen configuration")
config_hash=bytes2hex(sha256(read(ARGS[1])))
out=joinpath(WORK,"results",cfg["name"],system); mkpath(out)
saved_config=joinpath(out,"config_used.json")
if isfile(saved_config)
    get(JSON.parsefile(saved_config),"sha256","")==config_hash ||
        error("Existing study has a different frozen configuration; use a new run name")
else
    open(saved_config,"w") do io
        JSON.print(io,merge(cfg,Dict("sha256"=>config_hash,"system"=>system)),2)
    end
end
case,data,capacities,diag=load_system(system;capacity_scale=cfg["capacity_scale"],error_multiplier=cfg["error_multiplier"])
CSV.write(joinpath(out,"stress_transform.csv"),diag)
offsets=[24*(d-1)+h for d in cfg["days"] for h in cfg["hours"]]
maximum(offsets)<=length(data.times) || error("Evaluation calendar exceeds aligned data")
minimum(offsets)>cfg["train_hours"] || error("Training and test overlap")
features=get(cfg,"support_mapping","raw")=="bounded_headroom" ? normalized_site_errors(data,capacities) : data.omega
train_end=get(cfg,"training_end_hour",cfg["train_hours"])
minimum(offsets)>train_end || error("Training window overlaps test hours")
train_ids=collect(train_end-cfg["train_hours"]+1:train_end)
if haskey(cfg,"training_bootstrap_seed")
    rng=MersenneTwister(cfg["training_bootstrap_seed"])
    block=get(cfg,"training_bootstrap_block",24)
    starts=rand(rng,1:cfg["train_hours"],cld(cfg["train_hours"],block))
    train_ids=[train_end-cfg["train_hours"]+mod(s+j-2,cfg["train_hours"])+1 for s in starts for j=1:block][1:cfg["train_hours"]]
end
train=features[train_ids,:]
support=shared_support(train,cfg["K"],cfg["budget"],cfg["seed"];selector=cfg["selector"])
support=merge(support,(normalized_site_errors=features,support_training_features=train,capacities=capacities))
open(joinpath(out,"support.json"),"w") do io
    JSON.print(io,Dict("regime_weights"=>support.gmm.weights,"regime_indices"=>support.ids,
        "global_indices"=>support.global_ids,"train_hours"=>cfg["train_hours"],"training_source_indices"=>train_ids),2)
end
file=joinpath(out,"hourly.csv")
rows=isfile(file) ? CSV.read(file,DataFrame;stringtype=String,pool=false) : DataFrame()
if !isempty(rows)
    all(==(config_hash),rows.config_hash) || error("Configuration changed: choose a new run name")
end
seen=Set(isempty(rows) ? Tuple{Int,String}[] : [(Int(r.time_index),String(r.method)) for r in eachrow(rows)])
for (hidx,t) in enumerate(offsets)
    load=vec(data.load_forecast[t,:]); wind=vec(data.wind_forecast[t,:]); actual=vec(data.wind_actual[t,:])
    omega=vec(data.omega[t,:])
    oracle=nothing
    if get(cfg,"record_perfect_information",false)
        oracle=DRCCOLS.solve_deterministic_ols(case,load,actual;
            time_limit=cfg["time_limit"],tie_breaker=0.0,wind_spill_penalty=0.0)
        oracle.status=="OPTIMAL" || error("Perfect-information energy benchmark not optimal")
    end
    for method in cfg["methods"]
        (t,method) in seen && continue
        started=time()
        overrides=get(get(cfg,"method_parameters",Dict()),method,Dict())
        all(k in ("rho","delta","window","kappa","blend") for k in keys(overrides)) ||
            error("Method overrides may only change ambiguity and weight-update parameters")
        sol=solve_method(case,data,support,t,method,merge(cfg,overrides))
        v=DRCCOLS.max_violation(case,sol,load,wind,omega)
        fixed=physical_recourse(case,sol,load,actual;policy="fixed_agc",omega=omega)
        redispatch=physical_recourse(case,sol,load,actual;policy="redispatch",omega=omega)
        row=(system=system,method=method,time_index=t,time=data.times[t],
            day=cld(t,24),hour=mod(t-1,24)+1,status=sol.status,config_hash=config_hash,
            preventive_mwh=sol.load_shed,forecast_load_mwh=sum(load),
            reserve_up_mw=sol.has_values ? sum(sol.rU) : NaN,
            reserve_down_mw=sol.has_values ? sum(sol.rD) : NaN,
            planned_spill_mwh=sol.wind_curtailment,raw_policy_violation_mw=v,
            raw_policy_violated=isfinite(v) ? Int(v>1e-6) : -1,
            fixed_agc_ens_mwh=fixed.energy,fixed_agc_emergency_mwh=fixed.emergency,
            fixed_agc_residual_mw=fixed.residual,fixed_agc_spill_mwh=fixed.wind_spill,
            redispatch_ens_mwh=redispatch.energy,redispatch_emergency_mwh=redispatch.emergency,
            redispatch_residual_mw=redispatch.residual,redispatch_spill_mwh=redispatch.wind_spill,
            fixed_balance_error_mw=fixed.balance_error,fixed_line_overload_mw=fixed.max_line_overload,
            redispatch_balance_error_mw=redispatch.balance_error,
            redispatch_line_overload_mw=redispatch.max_line_overload,
            scheduled_spill_adjustment_mwh=sol.has_values ? sum(max.(sol.wind_spill.-actual,0.0)) : NaN,
            solve_seconds=sol.solve_time,wall_seconds=time()-started,
            support_count=length(support.global_ids),regime_counts=join(length.(support.ids),";"))
        if get(cfg,"record_clipped_affine",false)
            adjusted=copy(omega)
            if sol.has_values
                for w in eachindex(actual)
                    adjusted[case.wind_bus_idx[w]]+=max(sol.wind_spill[w]-actual[w],0.)
                end
            end
            clipped=DRCCOLS.max_violation(case,sol,load,wind,adjusted)
            row=merge(row,(clipped_policy_violation_mw=clipped,
                clipped_policy_violated=isfinite(clipped) ? Int(clipped>1e-6) : -1))
        end
        if oracle!==nothing
            row=merge(row,(perfect_information_ens_mwh=oracle.load_shed,
                excess_over_perfect_information_mwh=fixed.energy-oracle.load_shed))
        end
        push!(rows,row)
        CSV.write(file,rows[end:end,:];append=nrow(rows)>1,writeheader=nrow(rows)==1)
        println(system," day=",cld(t,24)," hour=",mod(t-1,24)+1," ",method," ",sol.status,
            " ENS=",round(fixed.energy,digits=3)," solve_s=",round(sol.solve_time,digits=2));flush(stdout)
    end
    hidx%24==0 && GC.gc()
end
open(joinpath(out,"completed.json"),"w") do io
    JSON.print(io,Dict("rows"=>nrow(rows),"expected_rows"=>length(offsets)*length(cfg["methods"]),
        "config_hash"=>config_hash,"completed"=>string(now())),2)
end
