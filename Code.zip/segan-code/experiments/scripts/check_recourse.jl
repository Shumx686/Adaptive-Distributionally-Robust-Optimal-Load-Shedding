include("common.jl")
using Test
# One-bus systems give exact energy balances independently of network code.
bus=zeros(1,13);bus[1,1]=1
gen=zeros(1,21);gen[1,1]=1;gen[1,9]=100
case=DRCCOLS.RBTSCase(100.0,bus,gen,zeros(0,13),[1],[1],[1],Float64[],zeros(0,1))
sol=(has_values=true,g=[50.0],rD=[20.0],rU=[20.0],dL=[0.0],load_shed=0.0,
    wind_spill=[0.0],beta=[1.0])
@testset "Physical replay: balance, reserve limits, wind availability" begin
    for policy in ("fixed_agc","redispatch")
        r=physical_recourse(case,sol,[100.0],[50.0];policy=policy,omega=[0.0])
        @test r.emergency==0.0
        @test r.status=="ANALYTIC_OPTIMAL"
        # Forecast load=100, wind=50. A 40 MW wind shortfall uses 20 MW reserve
        # and exactly 20 MW emergency shedding.
        r=physical_recourse(case,sol,[100.0],[10.0];policy=policy,omega=[-40.0])
        @test r.emergency ≈ 20.0 atol=1e-5
        @test r.balance_error < 1e-5
        @test r.residual < 1e-5
        # Wind surplus can be curtailed; it must not be called unserved demand.
        r=physical_recourse(case,sol,[100.0],[150.0];policy=policy,omega=[100.0])
        @test r.emergency < 1e-5
        @test r.wind_spill ≈ 80.0 atol=1e-5
        # Scheduled spilling above actual wind is clipped before the balance.
        # Its 25 MW forecast delivered wind becomes 0 MW in real time.
        s=merge(sol,(g=[75.0],wind_spill=[25.0]))
        r=physical_recourse(case,s,[100.0],[10.0];policy=policy,omega=[-40.0])
        @test r.emergency ≈ 5.0 atol=1e-5
        @test r.balance_error < 1e-5
    end
end

@testset "Availability clipping: analytic and full LP agreement" begin
    clipped=merge(sol,(g=[75.0],rD=[75.0],rU=[25.0],wind_spill=[25.0]))
    for policy in ("fixed_agc","redispatch")
        fast=physical_recourse(case,clipped,[100.0],[10.0];policy=policy,omega=[-40.0])
        full=physical_recourse(case,clipped,[100.0],[10.0];policy=policy,omega=[-40.0],analytic=false)
        @test fast.status=="ANALYTIC_OPTIMAL"
        @test fast.emergency==0.0
        @test fast.wind_spill≈10.0 atol=1e-8
        @test fast.balance_error<1e-8
        @test fast.energy≈full.energy atol=1e-6
        @test fast.wind_spill≈full.wind_spill atol=1e-6
        b=zeros(2,13);b[:,1]=[1,2]
        c=DRCCOLS.RBTSCase(100.0,b,gen,zeros(1,13),[1,2],[1],[2],[20.0],[0.0 -1.0])
        s=merge(clipped,(dL=[0.0,0.0],))
        r=physical_recourse(c,s,[50.0,50.0],[10.0];policy=policy,omega=[0.0,-40.0])
        @test r.emergency≈30.0 atol=1e-5
        @test r.max_line_overload<1e-5
        @test r.residual<1e-5
        @test r.status!="ANALYTIC_OPTIMAL"
    end
end

@testset "Network congestion creates locational emergency shedding" begin
    bus=zeros(2,13);bus[:,1]=[1,2]
    g=zeros(1,21);g[1,1]=1;g[1,9]=100
    c=DRCCOLS.RBTSCase(100.0,bus,g,zeros(1,13),[1,2],[1],[2],[20.0],[0.0 -1.0])
    s=(has_values=true,g=[20.0],rD=[20.0],rU=[80.0],dL=[0.0,0.0],load_shed=0.0,
        wind_spill=[0.0],beta=[1.0])
    for policy in ("fixed_agc","redispatch")
        r=physical_recourse(c,s,[0.0,40.0],[0.0];policy=policy,omega=[0.0,-20.0])
        @test r.emergency ≈ 20.0 atol=1e-5
        @test r.max_line_overload<1e-5
        @test r.balance_error<1e-5
    end
end
