include("controlled_beta.jl")
system=ARGS[1]
out=joinpath(WORK,"results","controlled_beta_repetitions");mkpath(out)
seeds=[20261022+100r for r=1:10]
protocol=Dict("replications"=>10,"seeds"=>seeds,"train_hours_per_replication"=>720,
    "validation_hours_per_replication"=>720,"test_contexts_per_replication"=>3,
    "independent_draws_per_context"=>1000,"source"=>"fresh simulated regime histories and wind draws, not GMM initialization seeds",
    "parameter_rule"=>"same fixed rho=0.01, delta=0.1, epsilon=0.05; weight settings chosen on each separate validation block")
protocol_file=joinpath(out,"protocol_$(system).json")
if isfile(protocol_file)
    JSON.parsefile(protocol_file)==protocol || error("Replication protocol changed")
else
    open(protocol_file,"w") do io;JSON.print(io,protocol,2);end
end
loaded=load_system(system;capacity_scale=.85)
first_rep=length(ARGS)>=2 ? parse(Int,ARGS[2]) : 1
last_rep=length(ARGS)>=3 ? parse(Int,ARGS[3]) : length(seeds)
1<=first_rep<=last_rep<=length(seeds) || error("Invalid replication partition")
for rep in first_rep:last_rep
    seed=seeds[rep]
    study=joinpath("controlled_beta_repetitions","rep"*lpad(rep,2,'0'))
    run_controlled_beta(system,seed,study;loaded=loaded)
    GC.gc();println("REPLICATION_COMPLETE ",system," ",rep," seed=",seed);flush(stdout)
end
