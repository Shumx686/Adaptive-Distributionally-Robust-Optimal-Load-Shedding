"""Freeze calendars and parameter grids before inspecting final test outcomes."""
from pathlib import Path
import copy, csv, hashlib, json, tomllib

ROOT = Path(__file__).resolve().parents[1]
base = tomllib.loads((ROOT/'config/pilot_bounded.toml').read_text('utf-8'))

def write_config(name, changes):
    cfg = copy.deepcopy(base)
    cfg.update(changes, name=name)
    lines = [f'{k} = {json.dumps(v, ensure_ascii=False)}' for k,v in cfg.items()]
    path = ROOT/'config'/f'{name}.toml'
    content = '\n'.join(lines)+'\n'
    if path.exists() and path.read_text('utf-8') != content:
        raise RuntimeError(f'Refusing to replace an existing frozen config: {path}')
    path.write_text(content, 'utf-8')
    return dict(name=name, config=str(path.relative_to(ROOT)),
                systems=';'.join(cfg['systems']), hours_per_method=len(cfg['days'])*len(cfg['hours']),
                methods=';'.join(cfg['methods']), stage=changes.get('stage',''),
                sha256=hashlib.sha256(content.encode()).hexdigest())

rows=[]
# Four seasons, complete days, predeclared consecutive weeks. These timestamps
# are disjoint from January training and February validation.
season_days = [d for start in (91,181,271,331) for d in range(start,start+7)]
rows.append(write_config('main_seasonal',dict(days=season_days,hours=list(range(1,25)),stage='test')))
rows.append(write_config('validation_continuous',dict(days=list(range(31,61)),hours=list(range(1,25)),stage='validation')))
rows.append(write_config('annual_chronology',dict(days=list(range(61,365)),hours=list(range(1,25)),stage='extended_test')))
# All candidates use exactly the same validation operating states.
# Parameter grid dimensions and candidate counts are reported explicitly.
for rho in (0.,.005,.01,.02,.05):
    rows.append(write_config(f'validation_baselines_rho{rho:g}',dict(
        days=[31,38,45,52,59],hours=[1,7,13,19],rho=rho,
        methods=['deterministic_headroom','empirical_cvar','single_tv','mixture_static','mixture_rolling'],stage='tuning')))
for rho in (0.,.005,.01,.02,.05):
    for delta in (0.,.01,.025,.05,.1):
        name=f'validation_rho{rho:g}_delta{delta:g}'
        rows.append(write_config(name,dict(days=[31,38,45,52,59],hours=[1,7,13,19],
            methods=['proposed'],rho=rho,delta=delta,stage='tuning')))
for K in (1,2,3,4,5):
    rows.append(write_config(f'regimes_K{K}',dict(K=K,days=[91,181,271,331],
        hours=[1,7,13,19],stage='ablation')))
for budget in (120,240,480,720):
    rows.append(write_config(f'support_Q{budget}',dict(budget=budget,days=[91,181,271,331],
        hours=[1,7,13,19],stage='support_scaling')))
for scale in (1.,.9,.85,.8,.75,.7):
    rows.append(write_config(f'capacity_c{scale:g}',dict(capacity_scale=scale,
        days=[91,181,271,331],hours=[1,7,13,19],stage='operating_grid')))
for multiplier in (1.,1.25,1.5):
    rows.append(write_config(f'wind_s{multiplier:g}',dict(error_multiplier=multiplier,
        days=[91,181,271,331],hours=[1,7,13,19],stage='operating_grid')))
for blend in (0.,.25,.5,.75,1.):
    rows.append(write_config(f'context_blend{blend:g}',dict(blend=blend,
        days=[91,181,271,331],hours=[1,7,13,19],stage='context_ablation')))
for window in (6,12,24,48,96):
    rows.append(write_config(f'window_{window}',dict(window=window,
        days=[91,181,271,331],hours=[1,7,13,19],stage='adaptation')))
for seed in (20261021,20261022,20261023,20261024,20261025,20261026,20261027,20261028,20261029,20261030):
    rows.append(write_config(f'training_bootstrap_{seed}',dict(training_bootstrap_seed=seed,
        training_bootstrap_block=24,days=[91,181,271,331],hours=[1,7,13,19],stage='training_block_bootstrap')))
with (ROOT/'config/manifest.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(f'Prepared {len(rows)} fixed configurations. Main: 672 hours/method/system, 12,096 dispatch solves.')
