include("common.jl")
length(ARGS)==1 || error("Usage: evaluate_conditional.jl <rbts|rts79|gmlc>")
system=ARGS[1];cfg=TOML.parsefile(joinpath(WORK,"config","scenario_stress.toml"))
case,data,capacities,_=load_system(system;capacity_scale=cfg["capacity_scale"])
z=normalized_site_errors(data,capacities);n,nw=size(z)
context=zeros(n,3nw)
for t=1:n
    context[t,1:nw]=vec(data.wind_forecast[t,:])./capacities
    context[t,nw+1:2nw]=t>1 ? vec(z[t-1,:]) : zeros(nw)
    context[t,2nw+1:3nw]=t>1 ? vec(mean(z[max(1,t-48):t-1,:],dims=1)) : zeros(nw)
end
center=vec(mean(context[1:720,:],dims=1))
scale=max.(vec(std(context[1:720,:],dims=1)),.05)
x=(context.-center')./scale'
states=[24*(d-1)+h for d in cfg["days"] for h in cfg["hours"]]
pool=setdiff(collect(1441:n),states)
src=joinpath(WORK,"results","scenario_stress",system)
out=joinpath(WORK,"results","contextual_stress",system);mkpath(out)
file=joinpath(out,"security_summary.csv")
rows=isfile(file) ? CSV.read(file,DataFrame;stringtype=String,pool=false) : DataFrame()
seen=Set(isempty(rows) ? Tuple{Int,String}[] : [(Int(r.time_index),String(r.method)) for r in eachrow(rows)])
for t in states
    distances=vec(sum((x[pool,:].-x[t,:]').^2,dims=2))
    order=sortperm(distances)
    ids=pool[order[1:cfg["test_scenarios"]]]
    CSV.write(joinpath(out,"context_$(t)_indices.csv"),DataFrame(source_index=ids,
        source_time=data.times[ids],distance=sqrt.(distances[order[1:length(ids)]])))
    forecast=vec(data.wind_forecast[t,:]);load=vec(data.load_forecast[t,:])
    omega=map_headroom_errors(case,z[ids,:],forecast,capacities)
    actual=zeros(length(ids),nw)
    for w=1:nw,i in eachindex(ids)
        actual[i,w]=forecast[w]+z[ids[i],w]*(z[ids[i],w]<0 ? forecast[w] : capacities[w]-forecast[w])
    end
    for method in cfg["methods"]
        (t,method) in seen && continue
        path=joinpath(src,"dispatch_$(t)_$(method).json")
        isfile(path) || continue
        d=JSON.parsefile(path)
        if d["has_values"]
            sol=(has_values=true,g=Float64.(d["g"]),beta=Float64.(d["beta"]),rD=Float64.(d["rD"]),
                rU=Float64.(d["rU"]),dL=Float64.(d["dL"]),wind_spill=Float64.(d["wind_spill"]),
                load_shed=Float64(d["load_shed"]))
            adjusted=copy(omega)
            for w=1:nw
                adjusted[:,case.wind_bus_idx[w]].+=max.(sol.wind_spill[w].-actual[:,w],0.0)
            end
            vals=[DRCCOLS.max_violation(case,sol,load,forecast,vec(adjusted[i,:])) for i in eachindex(ids)]
            raw=[DRCCOLS.max_violation(case,sol,load,forecast,vec(omega[i,:])) for i in eachindex(ids)]
            push!(rows,(system=system,time_index=t,time=data.times[t],method=method,status=String(d["status"]),
                n_scenarios=length(ids),distinct_error_rows=length(unique(ids)),
                preventive_mwh=sol.load_shed,mean_up_reserve_mw=sum(sol.rU),mean_down_reserve_mw=sum(sol.rD),
                joint_violation_pct=100mean(vals.>1e-6),model_affine_violation_pct=100mean(raw.>1e-6),
                mean_positive_violation_mw=mean(max.(vals,0.0)),max_violation_mw=maximum(max.(vals,0.0)),
                scheduled_spill_adjustment_pct=100mean(vec(any(actual.<sol.wind_spill',dims=2))),
                solve_seconds=Float64(d["solve_time"])))
            CSV.write(joinpath(out,"scenarios_$(t)_$(method).csv"),DataFrame(source_index=ids,
                source_day=cld.(ids,24),max_violation_mw=vals,model_max_violation_mw=raw,violated=vals.>1e-6))
        else
            push!(rows,(system=system,time_index=t,time=data.times[t],method=method,status=String(d["status"]),
                n_scenarios=length(ids),distinct_error_rows=length(unique(ids)),preventive_mwh=NaN,
                mean_up_reserve_mw=NaN,mean_down_reserve_mw=NaN,joint_violation_pct=NaN,
                model_affine_violation_pct=NaN,mean_positive_violation_mw=NaN,max_violation_mw=NaN,
                scheduled_spill_adjustment_pct=NaN,solve_seconds=Float64(d["solve_time"])))
        end
        CSV.write(file,rows)
        println(system," context ",t," ",method," % = ",rows.joint_violation_pct[end]);flush(stdout)
    end
end
open(joinpath(out,"context_protocol.json"),"w") do io
    JSON.print(io,Dict("selection"=>"1000 nearest held-out rows using forecast, lagged error, 48-hour mean error",
        "scaling"=>"training-only standard deviations with 0.05 floor", "features_per_farm"=>3,
        "target_realized_error_used_in_selection"=>false,"rows"=>nrow(rows),"expected_rows"=>length(states)*length(cfg["methods"])),2)
end
if nrow(rows)==length(states)*length(cfg["methods"])
    open(joinpath(out,"completed.json"),"w") do io;JSON.print(io,Dict("rows"=>nrow(rows),"complete"=>true),2);end
end
