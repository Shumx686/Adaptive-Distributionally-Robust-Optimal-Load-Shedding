from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from summarize import cvar

work=Path(__file__).resolve().parents[1]
folder=work/'results/rolling_operational_rts79_576h'
d=pd.read_csv(folder/'rts79/hourly.csv')
assert len(d)==576*3 and d.status.eq('OPTIMAL').all()
assert not d.duplicated(['method','time_index']).any()
assert d.excess_over_perfect_information_mwh.min()>=-1e-5
columns=['fixed_agc_residual_mw','redispatch_residual_mw','fixed_balance_error_mw','fixed_line_overload_mw',
    'redispatch_balance_error_mw','redispatch_line_overload_mw']
assert d[columns].max().max()<=1e-5
methods=['single_tv','mixture_rolling','proposed']
labels=['Single-TV','Rolling mixture','Proposed']
colors=['#3575b0','#dda642','#137f75']
records=[]
for method in methods:
    g=d[d.method.eq(method)]
    records.append(dict(method=method,hours=len(g),total_ens_mwh=g.fixed_agc_ens_mwh.sum(),
        total_preventive_mwh=g.preventive_mwh.sum(),total_emergency_mwh=g.fixed_agc_emergency_mwh.sum(),
        joint_events=int(g.clipped_policy_violated.sum()),joint_rate_pct=100*g.clipped_policy_violated.mean(),
        mean_positive_joint_violation_mw=g.clipped_policy_violation_mw.clip(lower=0).mean(),
        max_joint_violation_mw=g.clipped_policy_violation_mw.max(),
        nens_ppm=1e6*g.fixed_agc_ens_mwh.sum()/g.forecast_load_mwh.sum(),
        cvar95_ens_mwh=cvar(g.fixed_agc_ens_mwh),load_shedding_hours=int(g.fixed_agc_ens_mwh.gt(1e-5).sum()),
        emergency_hours=int(g.fixed_agc_emergency_mwh.gt(1e-5).sum()),
        perfect_information_ens_mwh=g.perfect_information_ens_mwh.sum(),
        excess_over_perfect_information_mwh=g.excess_over_perfect_information_mwh.sum(),
        mean_solve_seconds=g.solve_seconds.mean(),max_physical_error_mw=g[columns].max().max()))
s=pd.DataFrame(records);s.to_csv(folder/'operational_summary.csv',index=False)
starts=[98,188,278,338]
d['season']=[next(i+1 for i,t in enumerate(starts) if t<=day<t+6) for day in d.day]
seasons=d.groupby(['season','method'],as_index=False).agg(ens_mwh=('fixed_agc_ens_mwh','sum'),
    emergency_mwh=('fixed_agc_emergency_mwh','sum'),joint_events=('clipped_policy_violated','sum'),hours=('time_index','size'))
seasons.to_csv(folder/'seasonal_summary.csv',index=False)
plt.rcParams.update({'font.size':9,'axes.labelsize':9,'axes.titlesize':10})
fig,axes=plt.subplots(2,1,figsize=(7,6.2))
tail_probability=0.0
for i,(method,label,color) in enumerate(zip(methods,labels,colors)):
    g=seasons[seasons.method.eq(method)].sort_values('season')
    axes[0].bar(np.arange(4)+(i-1)*.24,g.ens_mwh,width=.23,label=label,color=color)
    values=d.loc[d.method.eq(method),'fixed_agc_ens_mwh'].to_numpy()
    x,counts=np.unique(np.where(values>1e-5,values,0.0),return_counts=True)
    survival=1-counts.cumsum()/len(values)
    if x[0]>0:x=np.r_[0.,x];survival=np.r_[1.,survival]
    tail_probability=max(tail_probability,float(survival[0]))
    axes[1].step(x,survival,where='post',label=label,color=color,linewidth=1.7)
axes[0].set_xticks(np.arange(4),[f'Days {t}-{t+5}' for t in starts])
axes[0].set_ylabel('Total ENS per six-day block (MWh)');axes[0].legend(ncol=3,frameon=False,fontsize=8)
axes[1].set_ylabel('Empirical exceedance probability');axes[1].set_xlabel('Hourly total ENS (MWh)')
axes[1].set_xlim(left=0);axes[1].set_ylim(0,max(.01,1.1*tail_probability))
for ax in axes:ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
fig.suptitle('RTS-79: recent training, fixed parameters, 576-hour calendar',fontsize=10)
fig.tight_layout(rect=(0,0,1,.96));fig.savefig(folder/'rolling_seasonal.png',dpi=300)
fig.savefig(folder/'rolling_seasonal.svg');plt.close(fig)
a=s.set_index('method').loc['single_tv'];b=s.set_index('method').loc['proposed']
gain=100*(1-b.total_ens_mwh/a.total_ens_mwh)
lines=['# RTS-79 近期训练下的 576 小时运行测试','',
    '采用固定规则：每个六天测试块开始前，全部方法使用此前 720 条观测重新拟合；块内固定训练支撑，仅在线更新混合权重。'
    '参数沿用前面的联合验证选择。日历为 98–103、188–193、278–283、338–343 天，按“紧接此前参考周之后的六天”定义。'
    '这组日历在本轮逐时求解前固定，训练规则来自已完成的 96 小时流程对照。','',
    '|方法|小时|总 ENS / MWh|应急 ENS / MWh|联合事件|NENS / ppm|ENS CVaR95 / MWh|',
    '|---|---:|---:|---:|---:|---:|---:|']
for r,label in zip(s.itertuples(),labels):
    lines.append(f'|{label}|{r.hours}|{r.total_ens_mwh:.3f}|{r.total_emergency_mwh:.3f}|{r.joint_events}/{r.hours}|'
        f'{r.nens_ppm:.2f}|{r.cvar95_ens_mwh:.3f}|')
lines += ['',f'在同一 576 小时日历上，相对 Single-TV 的总 ENS 下降为 {gain:.3f}%。',
    '','![近期训练运行](rolling_seasonal.png)','',
    '之前固定初始训练的 576 小时日历、同日的 96 小时训练对照与本次 576 小时日历分别汇总。'
    '训练流程的直接比较使用相同的 96 小时；两个不同 576 小时日历各自比较同日方法，不把跨日历差异全部归于训练。'
    '所有测试块的训练源索引严格早于相应测试首日。']
(folder/'RESULTS.md').write_text('\n'.join(lines)+'\n','utf-8')
print(s.to_string(index=False));print('ENS reduction %:',gain)
