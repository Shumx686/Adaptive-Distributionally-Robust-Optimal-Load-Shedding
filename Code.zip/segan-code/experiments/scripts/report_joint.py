from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from summarize import cvar

work=Path(__file__).resolve().parents[1]
validation=work/'results/joint_validation_rts79_v2'
test=work/'results/joint_test_rts79_576h'
selected=json.loads((validation/'selected_parameters.json').read_text('utf-8'))
cfg=json.loads((test/'rts79/config_used.json').read_text('utf-8'))
d=pd.read_csv(test/'rts79/hourly.csv')
assert len(d)==len(cfg['days'])*len(cfg['hours'])*len(cfg['methods'])
assert d.status.eq('OPTIMAL').all()
assert not d.duplicated(['method','time_index']).any()
assert d.clipped_policy_violated.ge(0).all()
assert d.excess_over_perfect_information_mwh.min()>=-1e-5
assert d.groupby('time_index').perfect_information_ens_mwh.nunique().eq(1).all()
physical_cols=['fixed_agc_residual_mw','redispatch_residual_mw','fixed_balance_error_mw',
    'redispatch_balance_error_mw','fixed_line_overload_mw','redispatch_line_overload_mw']
assert d[physical_cols].max().max()<=1e-5
labels={'deterministic_headroom':'Det. + reserves','empirical_cvar':'Empirical CVaR',
    'single_tv':'Single-TV','mixture_static':'Static mixture','mixture_rolling':'Rolling mixture','proposed':'Proposed'}
methods=list(labels)
season_starts=[92,182,272,332]
d['season']=[next(i+1 for i,start in enumerate(season_starts) if start<=day<=start+5) for day in d.day]
seasonal=d.groupby(['season','method'],as_index=False).agg(total_ens_mwh=('fixed_agc_ens_mwh','sum'),
    preventive_mwh=('preventive_mwh','sum'),emergency_mwh=('fixed_agc_emergency_mwh','sum'),
    hours=('time_index','size'),joint_events=('clipped_policy_violated','sum'),
    demand_energy_mwh=('forecast_load_mwh','sum'),redispatch_ens_mwh=('redispatch_ens_mwh','sum'))
seasonal['nens_ppm']=1e6*seasonal.total_ens_mwh/seasonal.demand_energy_mwh
seasonal.to_csv(test/'seasonal_summary.csv',index=False)
extra=[]
for method in methods:
    g=d[d.method.eq(method)]
    extra.append(dict(method=method,hours=len(g),total_ens_mwh=g.fixed_agc_ens_mwh.sum(),
        total_preventive_mwh=g.preventive_mwh.sum(),total_emergency_mwh=g.fixed_agc_emergency_mwh.sum(),
        total_redispatch_ens_mwh=g.redispatch_ens_mwh.sum(),joint_events=int(g.clipped_policy_violated.sum()),
        perfect_information_ens_mwh=g.perfect_information_ens_mwh.sum(),
        excess_over_perfect_information_mwh=g.excess_over_perfect_information_mwh.sum(),
        joint_rate_pct=100*g.clipped_policy_violated.mean(),raw_unclipped_events=int(g.raw_policy_violated.sum()),
        mean_positive_joint_violation_mw=g.clipped_policy_violation_mw.clip(lower=0).mean(),
        max_joint_violation_mw=g.clipped_policy_violation_mw.max(),
        nens_ppm=1e6*g.fixed_agc_ens_mwh.sum()/g.forecast_load_mwh.sum(),
        cvar95_ens_mwh=cvar(g.fixed_agc_ens_mwh),max_ens_mwh=g.fixed_agc_ens_mwh.max(),
        load_shedding_hours=int(g.fixed_agc_ens_mwh.gt(1e-5).sum()),
        emergency_hours=int(g.fixed_agc_emergency_mwh.gt(1e-5).sum()),
        mean_up_reserve_mw=g.reserve_up_mw.mean(),mean_down_reserve_mw=g.reserve_down_mw.mean(),
        mean_solve_seconds=g.solve_seconds.mean(),p95_solve_seconds=g.solve_seconds.quantile(.95),
        max_physical_error_mw=g[physical_cols].max().max()))
s=pd.DataFrame(extra);s.to_csv(test/'operational_summary.csv',index=False)
colors={'single_tv':'#3575b0','mixture_static':'#7d67a4','mixture_rolling':'#dda642','proposed':'#137f75'}
plt.rcParams.update({'font.size':9,'axes.titlesize':10,'axes.labelsize':9})
fig,axes=plt.subplots(2,1,figsize=(7,6.2))
tail_probability=0.0
for j,method in enumerate(colors):
    g=seasonal[seasonal.method.eq(method)].sort_values('season')
    axes[0].bar(np.arange(4)+(j-1.5)*.19,g.total_ens_mwh,width=.18,color=colors[method],label=labels[method])
    values=d.loc[d.method.eq(method),'fixed_agc_ens_mwh'].to_numpy()
    x,counts=np.unique(np.where(values>1e-5,values,0.0),return_counts=True)
    survival=1-counts.cumsum()/len(values)
    if x[0]>0:x=np.r_[0.,x];survival=np.r_[1.,survival]
    tail_probability=max(tail_probability,float(survival[0]))
    axes[1].step(x,survival,where='post',color=colors[method],label=labels[method],linewidth=1.7)
axes[0].set_xticks(np.arange(4),['Days 92-97','Days 182-187','Days 272-277','Days 332-337'])
axes[0].set_ylabel('Total ENS per six-day block (MWh)');axes[0].legend(ncol=2,frameon=False,fontsize=9)
axes[1].set_xlabel('Hourly total ENS (MWh)');axes[1].set_ylabel('Empirical exceedance probability')
axes[1].set_ylim(0,max(.01,1.1*tail_probability));axes[1].set_xlim(left=0)
for ax in axes:ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
fig.suptitle('RTS-79: fixed settings, 576 held-out hours',fontsize=10)
fig.tight_layout(rect=(0,0,1,.96));fig.savefig(test/'validated_seasonal.png',dpi=300)
fig.savefig(test/'validated_seasonal.svg');plt.close(fig)

fig,axes=plt.subplots(1,2,figsize=(10,4.2))
for ax,stage in zip(axes,['screen','confirm']):
    v=pd.read_csv(validation/f'{stage}_summary.csv')
    for profile,g in v.groupby('profile',sort=False):
        ax.scatter(100*g.scenario_risk,g.mean_ens_mwh,label=profile,s=42,alpha=.8,
            marker='s' if profile=='global' else 'o')
    for method in ['single_tv','proposed']:
        winner=v[v.candidate.eq(selected[method]['candidate'])]
        if len(winner):ax.scatter(100*winner.scenario_risk,winner.mean_ens_mwh,marker='*',
            s=190,facecolors='none',edgecolors='black',linewidths=1.1)
    ax.axvline(5,color='#888888',linestyle='--',linewidth=1)
    ax.set_title(f'{stage.capitalize()}: {int(v.hours.max())} validation hours')
    ax.set_xlabel('Common-error joint events (%)');ax.set_ylabel('Mean historical total ENS (MWh)')
    ax.grid(alpha=.2)
handles,legend_labels=axes[0].get_legend_handles_labels()
fig.legend(handles,legend_labels,loc='lower center',ncol=4,fontsize=8,frameon=False)
fig.tight_layout(rect=(0,.17,1,1));fig.savefig(validation/'operational_calibration.png',dpi=200)
fig.savefig(validation/'operational_calibration.svg');plt.close(fig)

base=s.set_index('method').loc['single_tv'];prop=s.set_index('method').loc['proposed']
gain=100*(1-prop.total_ens_mwh/base.total_ens_mwh)
confirm=pd.read_csv(validation/'confirm_summary.csv')
lines=['# RTS-79 联合运行校准与跨季节测试','',
    '训练使用前 720 小时。参数候选只在第 31–60 天验证，测试固定为四个季节各六个完整日，共 576 小时。'
    '此前查看过的第 91、181、271、331 天不在本次测试日历中。','',
    '## 参数选择','',
    '比较六组权重更新配置与两个局部半径、两个正外层半径；Single-TV 也比较相同两个局部半径。'
    '粗筛补入按预测裕度选择的紧张时点，确认使用五个完整验证日及预测定义的紧张时点。'
    f'确认阶段每候选 {int(confirm.hours.max())} 小时。安全标准同时约束历史事件频率与共同误差检验频率不超过 5%。'
    '在满足安全要求的候选中，先比较历史总 ENS，再以共同误差下的 EENS 处理相同总 ENS 的情形。','',
    '|方法|窗口|预测混合|平滑参数|局部半径|权重半径|验证平均 ENS / MWh|验证共同误差事件率|',
    '|---|---:|---:|---:|---:|---:|---:|---:|']
for method in ['single_tv','proposed']:
    r=selected[method]
    lines.append(f'|{labels[method]}|{r["window"] if method=="proposed" else "—"}|'
        f'{r["blend"] if method=="proposed" else "—"}|{r["kappa"] if method=="proposed" else "—"}|'
        f'{r["rho"]}|{r["delta"]}|{r["validation_mean_ens_mwh"]:.6f}|{100*r["validation_scenario_risk"]:.3f}%|')
lines += ['','![运行校准](../joint_validation_rts79_v2/operational_calibration.png)','',
    '## 完整跨季节结果','',
    '|方法|小时|总 ENS / MWh|预防 / MWh|应急 / MWh|联合事件|NENS / ppm|',
    '|---|---:|---:|---:|---:|---:|---:|']
for r in s.itertuples():
    lines.append(f'|{labels[r.method]}|{r.hours}|{r.total_ens_mwh:.3f}|{r.total_preventive_mwh:.3f}|'
        f'{r.total_emergency_mwh:.3f}|{r.joint_events}/{r.hours}|{r.nens_ppm:.2f}|')
lines += ['',f'相对 Single-TV 的总 ENS 下降为 {gain:.3f}%。正值表示供电改善，所有方法使用同一固定日历。',
    '','![跨季节运行](validated_seasonal.png)','',
    '统计量包括完整时间窗 ENS、预防/应急分解、NENS、ENS 的 95% CVaR、最大 ENS、切负荷时数、备用和求解时间。'
    '对应逐时数据、季节分解、两种实时控制评估、物理平衡检查和配对区间均保留。'
    '新测试同时保存原始仿射事件和按实际风电可用性截断后的仿射事件，主表采用后者；应急校正后的物理状态另行检查。',
    '',f'全部 {len(d)} 次调度均最优，最大物理残差/平衡/线路检查值为 {d[physical_cols].max().max():.3g} MW。',
    '', '初始均匀粗筛记录单独保存为诊断，正式选择采用带预测裕度分层的 v2 协议；最终测试日期未改动。']
(test/'RESULTS.md').write_text('\n'.join(lines)+'\n','utf-8')
print(s[['method','total_ens_mwh','joint_events','nens_ppm']].to_string(index=False))
print('ENS reduction:',gain)
