from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parents[1]/'results/controlled_beta_repetitions'
systems=['rbts','rts79','gmlc']
methods=['empirical_cvar','single_tv','mixture_static','mixture_rolling','proposed']
labels=['Empirical CVaR','Single-TV','Static mixture','Rolling mixture','Proposed']
frames=[];max_residual=0.0
for system in systems:
    test_seed_identifiers=[]
    protocol=json.loads((root/f'protocol_{system}.json').read_text('utf-8'))
    for rep,seed in enumerate(protocol['seeds'],1):
        folder=root/f'rep{rep:02d}'/system
        assert (folder/'completed.json').exists(),f'{system}, replication {rep} still running'
        d=pd.read_csv(folder/'summary.csv')
        assert len(d)==15 and not d.duplicated(['context','method']).any()
        assert d.status.eq('OPTIMAL').all() and d.n_scenarios.eq(1000).all()
        per_protocol=json.loads((folder/'protocol.json').read_text('utf-8'))
        assert per_protocol['seed']==seed
        for stream in per_protocol['test_rng_seeds']:
            test_seed_identifiers.extend([stream['class_seed'],stream['wind_seed']])
        for r in d.itertuples():
            s=pd.read_csv(folder/f'scenarios_{r.context}_{r.method}.csv')
            assert len(s)==1000 and np.isfinite(s.ens_mwh).all()
            assert (s.ens_mwh>=-1e-7).all() and s.residual_mw.max()<=1e-5
            max_residual=max(max_residual,float(s.residual_mw.max()))
        d['replication']=rep;d['seed']=seed;frames.append(d)
    assert len(test_seed_identifiers)==len(set(test_seed_identifiers))==60
d=pd.concat(frames,ignore_index=True)
d.to_csv(root/'all_dispatches.csv',index=False)
rep=d.groupby(['system','replication','method'],as_index=False).agg(
    eens_mwh=('expected_ens_mwh','mean'),preventive_mwh=('preventive_mwh','mean'),
    emergency_mwh=('mean_emergency_mwh','mean'),joint_violation_pct=('joint_violation_pct','mean'),
    residual_pct=('residual_pct','mean'),mean_solve_seconds=('solve_seconds','mean'))
rep.to_csv(root/'replication_means.csv',index=False)
summary=[];paired=[];rng=np.random.default_rng(20261022)
for system in systems:
    for method in methods:
        g=rep[rep.system.eq(system)&rep.method.eq(method)]
        ix=rng.integers(0,len(g),size=(10000,len(g)))
        e=g.eens_mwh.to_numpy();risk=g.joint_violation_pct.to_numpy()
        elo,ehi=np.quantile(e[ix].mean(axis=1),[.025,.975])
        rlo,rhi=np.quantile(risk[ix].mean(axis=1),[.025,.975])
        summary.append(dict(system=system,method=method,independent_replications=len(g),contexts=3*len(g),
            scenario_checks=3000*len(g),mean_eens_mwh=e.mean(),eens_ci95_low=elo,eens_ci95_high=ehi,
            mean_joint_violation_pct=risk.mean(),risk_ci95_low=rlo,risk_ci95_high=rhi,
            mean_emergency_mwh=g.emergency_mwh.mean(),mean_preventive_mwh=g.preventive_mwh.mean(),
            mean_solve_seconds=g.mean_solve_seconds.mean()))
    for baseline,candidate in [('single_tv','proposed'),('mixture_static','mixture_rolling'),('mixture_rolling','proposed')]:
        g=rep[rep.system.eq(system)]
        p=g.pivot(index='replication',columns='method',values='eens_mwh')
        q=g.pivot(index='replication',columns='method',values='joint_violation_pct')
        a=p[baseline].to_numpy();b=p[candidate].to_numpy();delta=b-a
        ix=rng.integers(0,len(a),size=(10000,len(a)))
        lo,hi=np.quantile(delta[ix].mean(axis=1),[.025,.975])
        reductions=100*(1-b[ix].mean(axis=1)/a[ix].mean(axis=1))
        gl,gh=np.quantile(reductions,[.025,.975])
        rd=(q[candidate]-q[baseline]).to_numpy();rl,rh=np.quantile(rd[ix].mean(axis=1),[.025,.975])
        paired.append(dict(system=system,baseline=baseline,candidate=candidate,replications=len(a),
            baseline_eens_mwh=a.mean(),candidate_eens_mwh=b.mean(),eens_reduction_pct=100*(1-b.mean()/a.mean()),
            reduction_ci95_low=gl,reduction_ci95_high=gh,mean_paired_difference_mwh=delta.mean(),
            difference_ci95_low=lo,difference_ci95_high=hi,mean_risk_difference_pp=rd.mean(),
            risk_difference_ci95_low=rl,risk_difference_ci95_high=rh,
            lower_eens_replications=int((delta<-1e-6).sum())))
s=pd.DataFrame(summary);p=pd.DataFrame(paired)
s.to_csv(root/'method_summary.csv',index=False);p.to_csv(root/'paired_comparisons.csv',index=False)
plt.rcParams.update({'font.size':8.5,'axes.titlesize':10,'axes.labelsize':8.5})
fig,axes=plt.subplots(2,3,figsize=(7,5.2))
colors=['#9aa6b2','#3575b0','#7d67a4','#dda642','#137f75']
for col,system in enumerate(systems):
    g=s[s.system.eq(system)].set_index('method').loc[methods]
    for row,value,lower,upper,ylabel in [(0,'mean_eens_mwh','eens_ci95_low','eens_ci95_high','Mean total EENS (MWh)'),
            (1,'mean_joint_violation_pct','risk_ci95_low','risk_ci95_high','Pre-correction joint violations (%)')]:
        ax=axes[row,col];x=np.arange(len(g));y=g[value].to_numpy()
        ax.bar(x,y,color=colors,width=.68,yerr=np.vstack([y-g[lower],g[upper]-y]),capsize=3,
            error_kw={'linewidth':1})
        ax.set_xticks(x,['Emp.','Single','Static','Rolling','Prop.'],rotation=55,ha='right',fontsize=8)
        ax.set_ylabel(ylabel);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
        if row==0:ax.set_title({'rbts':'RBTS','rts79':'RTS-79','gmlc':'RTS-GMLC'}[system])
fig.suptitle('Repeated conditional tests: ten histories per system',fontsize=10)
fig.tight_layout(rect=(0,0,1,.95));fig.savefig(root/'repeated_performance.png',dpi=300)
fig.savefig(root/'repeated_performance.svg');plt.close(fig)
lines=['# 三系统独立重复试验','',
    '每个系统 10 组独立生成的工况历史；每组训练 720 小时、验证 720 小时，并在三个模式情境各独立抽样 1,000 次。'
    '这是一组明确标注的模拟 Beta 工况切换试验。置信区间以完整重复试验为配对重抽样单元，包含训练样本变化。','',
    '|系统|Single-TV 平均 EENS / MWh|所提模型 / MWh|下降|下降的 95% 区间|联合越限率 Single-TV → 所提模型|',
    '|---|---:|---:|---:|---:|---:|']
for system in systems:
    r=p[p.system.eq(system)&p.baseline.eq('single_tv')].iloc[0]
    g=s[s.system.eq(system)].set_index('method')
    lines.append(f'|{system}|{r.baseline_eens_mwh:.3f}|{r.candidate_eens_mwh:.3f}|{r.eens_reduction_pct:.2f}%|'
        f'[{r.reduction_ci95_low:.2f}%, {r.reduction_ci95_high:.2f}%]|'
        f'{g.loc["single_tv","mean_joint_violation_pct"]:.3f}% → {g.loc["proposed","mean_joint_violation_pct"]:.3f}%|')
lines += ['','![Repeated performance](repeated_performance.png)','',
    '每个系统每方法 30 个调度情境、30,000 次情景检查；三系统合计 450 次调度优化和 450,000 次方法–情景检查。'
    '同一情境的五种方法使用相同的 1,000 条测试风电；这些共享样本按配对方式比较。'
    '区间反映本试验生成机制与十组重复的变化。参数规则、随机数种子和逐情景结果全部保存。','',
    '`paired_comparisons.csv` 同时给出静态→滚动、滚动→保护两步的 ENS 与安全频率变化。']
(root/'RESULTS.md').write_text('\n'.join(lines)+'\n','utf-8')
(root/'verification.json').write_text(json.dumps({'dispatches':len(d),'all_optimal':bool(d.status.eq('OPTIMAL').all()),
    'scenario_checks':int(d.n_scenarios.sum()),'replications_per_system':10,
    'conditional_draws_per_system':30000,'max_physical_residual_mw':max_residual,
    'distinct_test_streams_per_system':60,'rng_ledger_checked':True,
    'systems':systems,'max_reported_residual_pct':float(d.residual_pct.max())},indent=2),'utf-8')
print(s[['system','method','mean_eens_mwh','mean_joint_violation_pct']].to_string(index=False))
