from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

work=Path(__file__).resolve().parents[1]
folder=work/'results/support_refresh_rts79_96h'
fresh=pd.read_csv(folder/'rts79/hourly.csv')
fixed_path=work/'results/joint_test_rts79_576h/rts79/hourly.csv'
if fixed_path.exists():
    fixed=pd.read_csv(fixed_path)
else:
    fixed=pd.concat([pd.read_csv(work/f'results/joint_test_rts79_576h_part{i}/rts79/hourly.csv',nrows=144)
        for i in range(1,5)],ignore_index=True)
fixed=fixed[fixed.time_index.isin(fresh.time_index)]
assert len(fixed)==len(fresh)==96*6
assert fresh.status.eq('OPTIMAL').all()
assert set(zip(fixed.method,fixed.time_index))==set(zip(fresh.method,fresh.time_index))
labels={'deterministic_headroom':'Det. + reserves','empirical_cvar':'Empirical CVaR','single_tv':'Single-TV',
    'mixture_static':'Static mixture','mixture_rolling':'Rolling mixture','proposed':'Proposed'}
records=[]
for protocol,d in [('Fixed first-month training',fixed),('Preceding-month refresh',fresh)]:
    for method,g in d.groupby('method',sort=False):
        records.append(dict(training_protocol=protocol,method=method,hours=len(g),
            total_ens_mwh=g.fixed_agc_ens_mwh.sum(),emergency_mwh=g.fixed_agc_emergency_mwh.sum(),
            joint_events=int(g.clipped_policy_violated.sum()),joint_rate_pct=100*g.clipped_policy_violated.mean(),
            perfect_information_ens_mwh=g.perfect_information_ens_mwh.sum(),
            excess_over_perfect_information_mwh=g.excess_over_perfect_information_mwh.sum()))
s=pd.DataFrame(records);s.to_csv(folder/'training_comparison.csv',index=False)
p=fixed.merge(fresh,on=['method','time_index'],suffixes=('_fixed','_refresh'),validate='one_to_one')
assert np.max(np.abs(p.perfect_information_ens_mwh_fixed-p.perfect_information_ens_mwh_refresh))<=1e-6
p['ens_difference_mwh']=p.fixed_agc_ens_mwh_refresh-p.fixed_agc_ens_mwh_fixed
p[['method','time_index','ens_difference_mwh']].to_csv(folder/'paired_training_effect.csv',index=False)
fig,axes=plt.subplots(1,2,figsize=(8,3.8))
methods=['single_tv','mixture_static','mixture_rolling','proposed']
for i,(protocol,color) in enumerate([('Fixed first-month training','#7289a4'),('Preceding-month refresh','#137f75')]):
    g=s[s.training_protocol.eq(protocol)].set_index('method').loc[methods]
    axes[0].bar(np.arange(4)+(i-.5)*.35,g.total_ens_mwh,width=.33,color=color,label=protocol)
    axes[1].bar(np.arange(4)+(i-.5)*.35,g.joint_rate_pct,width=.33,color=color,label=protocol)
for ax in axes:
    ax.set_xticks(np.arange(4),['Single','Static','Rolling','Proposed'],rotation=20)
    ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
axes[0].set_ylabel('Total ENS on matched 96 hours (MWh)')
axes[1].set_ylabel('Pre-correction joint events (%)')
fig.legend(*axes[0].get_legend_handles_labels(),loc='lower center',ncol=2,fontsize=8,frameon=False)
fig.tight_layout(rect=(0,.14,1,1));fig.savefig(folder/'training_refresh.png',dpi=220)
fig.savefig(folder/'training_refresh.svg');plt.close(fig)
lines=['# RTS-79 训练样本时效性对照','',
    '两种训练流程使用相同的四个季节首日（92、182、272、332），共 96 小时。所有运行参数来自同一次联合验证。'
    '固定流程使用最初 720 条训练样本；刷新流程在每个测试日前使用刚刚过去的 720 条样本。'
    '六种方法在各流程中共享训练池与系统设置。测试日期与刷新规则在主测试开始前已固定。','',
    '|方法|固定训练 ENS / MWh|近期训练 ENS / MWh|固定事件数|近期事件数|',
    '|---|---:|---:|---:|---:|']
for method in labels:
    g=s[s.method.eq(method)].set_index('training_protocol')
    a=g.loc['Fixed first-month training'];b=g.loc['Preceding-month refresh']
    lines.append(f'|{labels[method]}|{a.total_ens_mwh:.3f}|{b.total_ens_mwh:.3f}|{int(a.joint_events)}/96|{int(b.joint_events)}/96|')
lines += ['','![训练时效性](training_refresh.png)','',
    '这 96 个小时已经包含在主测试的 576 小时中，是同一批运行点的训练流程对照；不增加独立测试小时数。'
    '各季节的训练源索引和配置哈希保存在四个分区的 support.json 与 config_used.json 中。']
(folder/'RESULTS.md').write_text('\n'.join(lines)+'\n','utf-8')
print(s.to_string(index=False))
