"""Exact finite-support TV LP, solved by adding violated affine loss rows.

The epigraph has the same variables, TV dual and objective as solve_drcc_ols.
Every omitted row is checked at termination; this is constraint generation,
not support reduction or a different approximation.
"""
function solve_tv_cuts(case, load, wind, pi, reps, rho; epsilon=.05, delta_w=.01,
        time_limit=120.0, tolerance=1e-6, iteration_callback=nothing,
        audit_callback=nothing, solver_options=Dict{String,Any}())
    nb=length(load);ng=size(case.gen,1);nl=length(case.line_rates);nw=length(wind);K=length(reps)
    m=Model(HiGHS.Optimizer);set_silent(m)
    for (key,val) in solver_options; set_optimizer_attribute(m,key,val); end
    @variable(m,g[1:ng]);@variable(m,beta[1:ng]>=0)
    @variable(m,rD[1:ng]>=0);@variable(m,rU[1:ng]>=0)
    @variable(m,0<=dL[b=1:nb]<=load[b]);@variable(m,0<=spill[w=1:nw]<=wind[w])
    @variable(m,tau);@variable(m,eta);@variable(m,nu>=0)
    @variable(m,tv[1:K]>=0);@variable(m,alpha[1:K])
    @variable(m,lambda[1:K]>=0);@variable(m,zeta[1:K])
    @constraint(m,[j=1:ng],g[j]-rD[j]>=case.gen[j,10])
    @constraint(m,[j=1:ng],g[j]+rU[j]<=case.gen[j,9])
    @constraint(m,sum(g)+sum(wind.-spill)==sum(load.-dL))
    @constraint(m,sum(beta)==1)
    @constraint(m,[k=1:K],tv[k]+eta-nu>=alpha[k])
    @constraint(m,[k=1:K],tv[k]<=2nu)
    @expression(m,risk,tau+(eta+nu*(delta_w-1)+sum(pi[k]*tv[k] for k=1:K))/epsilon)
    @constraint(m,risk<=0)
    @expression(m,base[e=1:nl],sum(case.ptdf[e,case.gen_bus_idx[j]]*g[j] for j=1:ng)+
        sum(case.ptdf[e,case.wind_bus_idx[w]]*(wind[w]-spill[w]) for w=1:nw)-
        sum(case.ptdf[e,b]*(load[b]-dL[b]) for b=1:nb))
    @expression(m,agc[e=1:nl],sum(case.ptdf[e,case.gen_bus_idx[j]]*beta[j] for j=1:ng))
    sv=Vector{Vector{VariableRef}}(undef,K)
    for k=1:K
        q=size(reps[k],1)
        sv[k]=@variable(m,[1:q],base_name="s_$k")
        @constraint(m,[i=1:q],sv[k][i]>=-zeta[k])
        @constraint(m,alpha[k]>=lambda[k]*rho[k]+zeta[k]+sum(sv[k])/q)
        @constraint(m,[i=1:q],sv[k][i]<=lambda[k])
        @constraint(m,[i=1:q],sv[k][i]>=-lambda[k])
    end
    @objective(m,Min,sum(dL)+1e-3sum(spill)+1e-6(sum(rD)+sum(rU)+sum(g)))
    sums=[vec(sum(x,dims=2)) for x in reps]
    flows=[x*case.ptdf' for x in reps]
    started=time();solver_seconds=0.0;cuts=0;iterations=0;certified=false;status="ITERATION_LIMIT"
    for iteration=1:250
        iterations=iteration
        remaining=time_limit-(time()-started)
        remaining<=0 && (status="TIME_LIMIT";break)
        set_optimizer_attribute(m,"time_limit",remaining)
        optimize!(m);solver_seconds+=solve_time(m)
        status=string(termination_status(m))
        status=="OPTIMAL" || break
        bv=value.(beta);dv=value.(rD);uv=value.(rU)
        bf=value.(base);af=value.(agc);ta=value(tau);zv=value.(zeta)
        sval=[value.(v) for v in sv]
        round_objective=objective_value(m)
        added=0; max_separation=0.0
        for k=1:K
            thresholds=sval[k].+zv[k].+ta
            for i=1:size(reps[k],1)
                os=sums[k][i]
                fv=bf.+vec(flows[k][i,:]).-af.*os
                losses=vcat(bv.*os.-dv,-bv.*os.-uv,fv.-case.line_rates,-fv.-case.line_rates)
                worst=argmax(losses)
                max_separation=max(max_separation,losses[worst]-thresholds[i])
                losses[worst] <= thresholds[i]+tolerance && continue
                if worst<=ng
                    j=worst
                    @constraint(m,sv[k][i]>=beta[j]*os-rD[j]-tau-zeta[k])
                elseif worst<=2ng
                    j=worst-ng
                    @constraint(m,sv[k][i]>=-beta[j]*os-rU[j]-tau-zeta[k])
                elseif worst<=2ng+nl
                    e=worst-2ng
                    @constraint(m,sv[k][i]>=base[e]+flows[k][i,e]-agc[e]*os-case.line_rates[e]-tau-zeta[k])
                else
                    e=worst-2ng-nl
                    @constraint(m,sv[k][i]>=-base[e]-flows[k][i,e]+agc[e]*os-case.line_rates[e]-tau-zeta[k])
                end
                added+=1
            end
        end
        cuts+=added
        iteration_callback===nothing || iteration_callback((iteration=iteration,
            objective=round_objective,max_separation_mw=max_separation,
            added_cuts=added,generated_cuts=cuts,solver_seconds=solver_seconds,
            elapsed_seconds=time()-started))
        if added==0
            certified=true;break
        end
    end
    status=="OPTIMAL" && !certified && (status="ROW_GENERATION_LIMIT")
    sz=DRCCOLS.model_size(m)
    certified && audit_callback!==nothing && audit_callback(m)
    if !certified
        return (status=status,has_values=false,objective=NaN,load_shed=NaN,solve_time=solver_seconds,
            lp_variables=sz.variables,lp_constraints=sz.constraints,g=Float64[],beta=Float64[],rD=Float64[],rU=Float64[],
            dL=Float64[],wind_spill=Float64[],wind_curtailment=NaN,tau=NaN,risk_lhs=NaN,risk_slack=NaN,
            cut_iterations=iterations,generated_cuts=cuts)
    end
    return (status="OPTIMAL",has_values=true,objective=objective_value(m),load_shed=sum(value.(dL)),
        solve_time=solver_seconds,lp_variables=sz.variables,lp_constraints=sz.constraints,
        g=value.(g),beta=value.(beta),rD=value.(rD),rU=value.(rU),dL=value.(dL),wind_spill=value.(spill),
        wind_curtailment=sum(value.(spill)),tau=value(tau),risk_lhs=value(risk),risk_slack=0.0,
        cut_iterations=iterations,generated_cuts=cuts)
end
