from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]/'results/controlled_beta'
rows=[];paired=[]
for f in sorted(ROOT.glob('*/summary.csv')):
    d=pd.read_csv(f);system=f.parent.name
    for method,g in d.groupby('method',sort=False):
        ok=g[g.status.eq('OPTIMAL')]
        rows.append(dict(system=system,method=method,optimal_contexts=len(ok),expected_contexts=3,
            scenario_checks=int(ok.n_scenarios.sum()),mean_eens_mwh=ok.expected_ens_mwh.mean(),
            mean_preventive_mwh=ok.preventive_mwh.mean(),mean_emergency_mwh=ok.mean_emergency_mwh.mean(),
            mean_joint_violation_pct=ok.joint_violation_pct.mean(),mean_residual_pct=ok.residual_pct.mean(),
            mean_solve_seconds=ok.solve_seconds.mean()))
    for baseline in ('single_tv','mixture_static','mixture_rolling','empirical_cvar'):
        diffs=[]
        for k in (1,2,3):
            a=f.parent/f'scenarios_{k}_{baseline}.csv';b=f.parent/f'scenarios_{k}_proposed.csv'
            if a.exists() and b.exists():
                p=pd.read_csv(a).merge(pd.read_csv(b),on=['sample','true_regime'],suffixes=('_base','_prop'),validate='one_to_one')
                diffs.append(p)
        if len(diffs)!=3:continue
        mean_base=np.mean([p.ens_mwh_base.mean() for p in diffs]);mean_prop=np.mean([p.ens_mwh_prop.mean() for p in diffs])
        delta=np.mean([np.mean(p.ens_mwh_prop-p.ens_mwh_base) for p in diffs])
        # Monte Carlo sampling uncertainty conditional on this fixed training set
        # and the three equally weighted, pre-specified operating contexts.
        se=np.sqrt(sum(np.var(p.ens_mwh_prop-p.ens_mwh_base,ddof=1)/len(p) for p in diffs))/3
        paired.append(dict(system=system,baseline=baseline,candidate='proposed',contexts=3,paired_checks=3000,
            baseline_eens_mwh=mean_base,candidate_eens_mwh=mean_prop,mean_difference_mwh=delta,
            mc_standard_error=se,conditional_mc_ci95_low=delta-1.96*se,conditional_mc_ci95_high=delta+1.96*se,
            eens_reduction_pct=100*(1-mean_prop/mean_base) if mean_base>1e-9 else np.nan,
            baseline_joint_violation_pct=np.mean([100*p.violated_base.mean() for p in diffs]),
            candidate_joint_violation_pct=np.mean([100*p.violated_prop.mean() for p in diffs])))
s=pd.DataFrame(rows);s.to_csv(ROOT/'method_summary.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(paired).to_csv(ROOT/'paired_comparisons.csv',index=False,encoding='utf-8-sig')
systems=sorted(s.system.unique());fig,axs=plt.subplots(2,len(systems),figsize=(5*len(systems),7.4),squeeze=False)
methods=['empirical_cvar','single_tv','mixture_static','mixture_rolling','proposed'];labels=['Emp.','Single','Static','Rolling','Proposed']
for j,system in enumerate(systems):
    g=s[s.system.eq(system)].set_index('method').reindex(methods)
    x=np.arange(len(methods))
    axs[0,j].bar(x,g.mean_preventive_mwh,color='#4c78a8',label='Preventive')
    axs[0,j].bar(x,g.mean_emergency_mwh,bottom=g.mean_preventive_mwh,color='#f58518',label='Emergency')
    axs[0,j].set_title(system.upper());axs[0,j].set_ylabel('Expected total ENS (MWh/context)')
    axs[1,j].bar(x,g.mean_joint_violation_pct,color=['#999999','#59a14f','#76b7b2','#edc948','#b279a2'])
    axs[1,j].set_ylabel('Pre-correction joint violations (%)')
    for ax in axs[:,j]:ax.set_xticks(x,labels=labels,rotation=25);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
h,l=axs[0,0].get_legend_handles_labels();fig.legend(h,l,loc='lower center',ncol=2,frameon=False)
fig.tight_layout(rect=(0,.06,1,.94))
fig.suptitle('Controlled Beta regime-switching benchmark: 1,000 draws per context',fontsize=12)
fig.savefig(ROOT/'controlled_performance.png',dpi=180)
fig.savefig(ROOT/'controlled_performance.svg')
plt.close(fig)
lines=['# Controlled mechanism experiment: bounded Beta errors and regime switching','',
       'This is a simulated mechanism benchmark, separate from the historical-data replays. '
       'Three persistent error regimes have Beta means of 0.25, 0.50, 0.75 p.u. and standard deviations '
       'of 0.05, 0.07, 0.05 p.u. The latent state persists with probability 0.95; otherwise it is redrawn '
       'from (0.3, 0.4, 0.3). The dispatch uses only observed error history. Each of three balanced '
       'test contexts uses 1,000 independent draws from the true conditional mixture. '
       'All methods share the same training observations and test draws.','',
       'Training and validation contain 720 hours each. The validation block selects the online weight parameters. '
       'The common nominal wind is half of installed capacity; common demand is 0.85 of original conventional '
       'capacity plus 0.25 of installed wind. Local TV radius is 0.01, outer protection is 0.10, and epsilon is 0.05. '
       'Neither load level nor test contexts are chosen from method outcomes.','',
       '|System|Method|Contexts|Checks|Expected ENS (MWh)|Emergency (MWh)|Joint violation (%)|',
       '|---|---|---:|---:|---:|---:|---:|']
for r in s.itertuples():
    lines.append(f'|{r.system}|{r.method}|{r.optimal_contexts}/3|{r.scenario_checks}|{r.mean_eens_mwh:.3f}|{r.mean_emergency_mwh:.3f}|{r.mean_joint_violation_pct:.3f}|')
lines+=['','The expected ENS includes both preventive and corrective energy. Joint violations are evaluated '
        'before corrective action; all post-correction residuals are retained. The paired interval in '
        'paired_comparisons.csv measures Monte Carlo sampling uncertainty for the fixed training set '
        'and three balanced contexts. It does not include variation across independently trained models.','',
        '![Controlled mechanism results](controlled_performance.png)']
(ROOT/'RESULTS.md').write_text('\n'.join(lines)+'\n','utf-8')
print(pd.DataFrame(paired)[['system','baseline','eens_reduction_pct','baseline_joint_violation_pct','candidate_joint_violation_pct']].to_string(index=False))
