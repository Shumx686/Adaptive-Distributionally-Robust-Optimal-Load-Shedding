include("common.jl")
using SHA
cfgpath=isempty(ARGS) ? joinpath(WORK,"config","joint_validation_rts79_v2.toml") : ARGS[1]
cfg=TOML.parsefile(cfgpath); system=cfg["system"]
out=joinpath(WORK,"results",cfg["name"]);mkpath(out)
protocol_hash=bytes2hex(sha256(read(cfgpath)))
frozen=joinpath(out,"protocol.json")
if isfile(frozen)
    JSON.parsefile(frozen)["sha256"]==protocol_hash || error("Protocol changed; choose a new run name")
else
    open(frozen,"w") do io
        JSON.print(io,merge(cfg,Dict("sha256"=>protocol_hash,"frozen_at"=>string(now()),
            "selection"=>"minimum mean historical physical ENS, then common-scenario EENS, subject to both validation risk rates <= target and physical residual <= 1e-5 MW",
            "historical_context"=>"Previously inspected days 91,181,271,331 are excluded from this test; CE profile was identified in earlier validation.")),2)
    end
end
case,data,capacities,_=load_system(system;capacity_scale=cfg["capacity_scale"])
features=normalized_site_errors(data,capacities);train=features[1:cfg["train_hours"],:]
support=shared_support(train,cfg["K"],cfg["budget"],cfg["seed"])
support=merge(support,(normalized_site_errors=features,support_training_features=train,capacities=capacities))

candidates=Dict{String,Any}[]
for rho in cfg["rho_grid"]
    push!(candidates,Dict("candidate"=>"single_r$(rho)","method"=>"single_tv","profile"=>"global",
        "rho"=>rho,"delta"=>0.,"window"=>48,"kappa"=>10.,"blend"=>.5))
end
for p in cfg["profiles"],rho in cfg["rho_grid"],delta in cfg["delta_grid"]
    push!(candidates,merge(p,Dict("candidate"=>"$(p["name"])_r$(rho)_d$(delta)",
        "method"=>"proposed","profile"=>p["name"],"rho"=>rho,"delta"=>delta)))
end
grid_file=joinpath(out,"candidate_grid.json")
if isfile(grid_file)
    JSON.parsefile(grid_file)==candidates || error("Candidate grid changed")
else
    open(grid_file,"w") do io;JSON.print(io,candidates,2);end
end

function evaluate_stage(stage,chosen;tag=stage)
    states=[24*(d-1)+h for d in cfg[stage*"_days"] for h in cfg[stage*"_hours"]]
    block=collect(cfg[stage*"_error_start"]:cfg[stage*"_error_end"])
    # Add one forecast-defined tight hour on each of the eight tightest days.
    # This uses load/wind forecasts, not future actual errors or method results.
    margin=Dict(t=>sum(case.gen[:,9])+sum(data.wind_forecast[t,:])-sum(data.load_forecast[t,:]) for t in block)
    ranked_states=sort(block;by=t->(margin[t],t));tight_days=Set{Int}();tight=Int[]
    for t in ranked_states
        d=cld(t,24);d in tight_days && continue
        push!(tight_days,d);push!(tight,t)
        length(tight_days)==get(cfg,stage*"_tight_days",0) && break
    end
    if get(cfg,stage*"_tight_days",0)>0;states=sort(unique(vcat(states,tight)));end
    CSV.write(joinpath(out,tag*"_target_indices.csv"),DataFrame(time_index=states,time=data.times[states],forecast_margin_mw=[margin[t] for t in states]))
    pool=setdiff(block,states)
    CSV.write(joinpath(out,tag*"_error_indices.csv"),DataFrame(time_index=pool,time=data.times[pool]))
    file=joinpath(out,tag*"_hourly.csv")
    rows=isfile(file) ? CSV.read(file,DataFrame;stringtype=String,pool=false) : DataFrame()
    seen=Set(isempty(rows) ? Tuple{String,Int}[] : [(String(r.candidate),Int(r.time_index)) for r in eachrow(rows)])
    for c in chosen
        localcfg=merge(cfg,c)
        for t in states
            (c["candidate"],t) in seen && continue
            started=time();sol=solve_method(case,data,support,t,c["method"],localcfg)
            load=vec(data.load_forecast[t,:]);forecast=vec(data.wind_forecast[t,:])
            actual=vec(data.wind_actual[t,:]);omega=vec(data.omega[t,:])
            fixed=physical_recourse(case,sol,load,actual;policy="fixed_agc",omega=omega)
            redispatch=physical_recourse(case,sol,load,actual;policy="redispatch",omega=omega)
            actual_v=DRCCOLS.max_violation(case,sol,load,forecast,omega)
            risk=NaN;severity=NaN;scenario_eens=NaN;scenario_emergency=NaN;scenario_residual=NaN
            if sol.has_values
                scenarios=map_headroom_errors(case,features[pool,:],forecast,capacities)
                v=Float64[];energies=Float64[];emergencies=Float64[];residuals=Float64[]
                for i in eachindex(pool)
                    aw=[forecast[w]+features[pool[i],w]*(features[pool[i],w]<0 ? forecast[w] : capacities[w]-forecast[w]) for w in eachindex(capacities)]
                    error=vec(scenarios[i,:]);adjusted=copy(error)
                    for w in eachindex(capacities)
                        adjusted[case.wind_bus_idx[w]]+=max(sol.wind_spill[w]-aw[w],0.)
                    end
                    push!(v,DRCCOLS.max_violation(case,sol,load,forecast,adjusted))
                    rec=physical_recourse(case,sol,load,aw;policy="fixed_agc",omega=error)
                    push!(energies,rec.energy);push!(emergencies,rec.emergency);push!(residuals,rec.residual)
                end
                risk=mean(v.>1e-6);severity=mean(max.(v,0.))
                scenario_eens=mean(energies);scenario_emergency=mean(emergencies);scenario_residual=maximum(residuals)
            end
            row=(candidate=c["candidate"],method=c["method"],profile=c["profile"],
                rho=c["rho"],delta=c["delta"],window=c["window"],kappa=c["kappa"],blend=c["blend"],
                time_index=t,day=cld(t,24),hour=mod(t-1,24)+1,status=sol.status,
                ens_mwh=fixed.energy,redispatch_ens_mwh=redispatch.energy,preventive_mwh=sol.load_shed,
                emergency_mwh=fixed.emergency,residual_mw=fixed.residual,
                balance_error_mw=fixed.balance_error,line_overload_mw=fixed.max_line_overload,
                historical_violation_mw=actual_v,historical_violated=isfinite(actual_v) ? Int(actual_v>1e-6) : -1,
                validation_scenarios=length(pool),scenario_risk=risk,scenario_severity_mw=severity,
                scenario_eens_mwh=scenario_eens,scenario_emergency_mwh=scenario_emergency,scenario_residual_mw=scenario_residual,
                solve_seconds=sol.solve_time,wall_seconds=time()-started)
            push!(rows,row)
            CSV.write(file,DataFrame([row]);append=nrow(rows)>1,writeheader=nrow(rows)==1)
        end
        println(stage," ",c["candidate"]," complete");flush(stdout);GC.gc()
    end
    summary=DataFrame()
    for g in groupby(rows,[:candidate,:method,:profile,:rho,:delta,:window,:kappa,:blend])
        complete=nrow(g)==length(states)&&all(==("OPTIMAL"),g.status)
        hist=complete ? mean(g.historical_violated) : NaN
        risk=complete ? mean(g.scenario_risk) : NaN
        residual=complete ? max(maximum(g.residual_mw),maximum(g.scenario_residual_mw)) : NaN
        push!(summary,(candidate=g.candidate[1],method=g.method[1],profile=g.profile[1],
            rho=g.rho[1],delta=g.delta[1],window=g.window[1],kappa=g.kappa[1],blend=g.blend[1],
            hours=nrow(g),complete=complete,mean_ens_mwh=complete ? round(mean(g.ens_mwh),digits=6) : NaN,
            mean_redispatch_ens_mwh=complete ? mean(g.redispatch_ens_mwh) : NaN,
            historical_risk=hist,scenario_risk=risk,scenario_severity_mw=complete ? mean(g.scenario_severity_mw) : NaN,
            mean_scenario_eens_mwh=complete ? round(mean(g.scenario_eens_mwh),digits=6) : NaN,
            max_residual_mw=residual,eligible=complete&&hist<=cfg["risk_target"]&&risk<=cfg["risk_target"]&&residual<=1e-5))
    end
    CSV.write(joinpath(out,tag*"_summary.csv"),summary)
    return summary
end

if length(ARGS)>=2
    candidate=ARGS[2]
    partition=[c for c in candidates if c["candidate"]==candidate]
    length(partition)==1 || error("Unknown candidate partition")
    evaluate_stage("confirm",partition;tag="confirm_part_"*candidate)
    exit()
end

screen=evaluate_stage("screen",candidates)
ranked=filter(r->r.method=="proposed"&&r.eligible,screen)
sort!(ranked,[:mean_ens_mwh,:mean_scenario_eens_mwh,:scenario_risk,:rho,:delta,:candidate])
profile_names=String[];shortlist=String[]
for r in eachrow(ranked)
    r.profile in profile_names && continue
    push!(profile_names,r.profile);push!(shortlist,r.candidate)
    length(profile_names)==cfg["shortlist_profiles"] && break
end
# Retain the earlier reference and CE settings as transparent comparators in the
# larger validation stage, even when they are not among the screening leaders.
for profile in ("reference","predictive_ce")
    group=filter(r->r.profile==profile&&r.eligible,ranked)
    if nrow(group)>0
        c=group.candidate[1];c in shortlist || push!(shortlist,c)
    end
end
append!(shortlist,[c["candidate"] for c in candidates if c["method"]=="single_tv"])
chosen=[c for c in candidates if c["candidate"] in shortlist]
open(joinpath(out,"shortlist.json"),"w") do io;JSON.print(io,chosen,2);end
confirm=evaluate_stage("confirm",chosen)
selected=Dict{String,Any}("protocol_sha256"=>protocol_hash,"selection_data"=>"five full validation days plus forecast-defined tight hours; exact indices saved",
    "test_days"=>cfg["test_days"],"test_hours"=>cfg["test_hours"],"risk_target"=>cfg["risk_target"])
for method in ("single_tv","proposed")
    eligible=filter(r->r.method==method&&r.eligible,confirm)
    nrow(eligible)>0 || error("No eligible candidate for $method; review validation results before testing")
    sort!(eligible,[:mean_ens_mwh,:mean_scenario_eens_mwh,:scenario_risk,:rho,:delta,:candidate])
    winner=first(eachrow(eligible))
    selected[method]=merge(first(c for c in chosen if c["candidate"]==winner.candidate),
        Dict("validation_mean_ens_mwh"=>winner.mean_ens_mwh,"validation_historical_risk"=>winner.historical_risk,
            "validation_scenario_risk"=>winner.scenario_risk,"validation_scenario_eens_mwh"=>winner.mean_scenario_eens_mwh))
end
open(joinpath(out,"selected_parameters.json"),"w") do io;JSON.print(io,selected,2);end
println("FROZEN_SELECTION ",JSON.json(selected));flush(stdout)
