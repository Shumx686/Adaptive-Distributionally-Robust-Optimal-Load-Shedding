include("common.jl")
using Test
case,data,capacities,_=load_system("rbts";capacity_scale=.85)
s=shared_support(data.omega[1:720,:],3,40,20261021)
t=733
@testset "Constraint generation matches the complete finite-support LP" begin
    for (reps,pi,rho,delta) in ((s.global_reps,[1.0],0.0,0.0),
            (s.global_reps,[1.0],.01,0.0),(s.mixture,s.gmm.weights,.01,.01))
        a=DRCCOLS.solve_drcc_ols(case,vec(data.load_forecast[t,:]),vec(data.wind_forecast[t,:]),
            pi,reps,fill(rho,length(reps));epsilon=.05,delta_w=delta)
        b=solve_tv_cuts(case,vec(data.load_forecast[t,:]),vec(data.wind_forecast[t,:]),
            pi,reps,fill(rho,length(reps));epsilon=.05,delta_w=delta)
        @test a.status==b.status=="OPTIMAL"
        @test a.objective ≈ b.objective atol=1e-5 rtol=1e-5
        @test b.risk_lhs<=1e-5
    end
end
