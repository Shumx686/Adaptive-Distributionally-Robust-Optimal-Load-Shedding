include("common.jl")
length(ARGS)==1 || error("Usage: calibrate_security.jl <rbts|rts79|gmlc>")
system=ARGS[1];cfg=TOML.parsefile(joinpath(WORK,"config","pilot_bounded.toml"))
case,data,capacities,_=load_system(system;capacity_scale=cfg["capacity_scale"])
features=normalized_site_errors(data,capacities);train=features[1:720,:]
support=shared_support(train,3,720,cfg["seed"])
support=merge(support,(normalized_site_errors=features,support_training_features=train,capacities=capacities))
states=[24*(d-1)+19 for d in (31,38,45,52,59)]
pool=setdiff(collect(721:1440),states)
ids=sort(shuffle(MersenneTwister(cfg["seed"]),pool)[1:500])
out=joinpath(WORK,"results","calibration",system);mkpath(out)
CSV.write(joinpath(out,"validation_indices.csv"),DataFrame(source_index=ids,time=data.times[ids]))
file=joinpath(out,"candidate_hourly.csv")
rows=isfile(file) ? CSV.read(file,DataFrame;stringtype=String,pool=false) : DataFrame()
seen=Set(isempty(rows) ? Tuple{String,Int}[] : [(String(r.candidate),Int(r.time_index)) for r in eachrow(rows)])
candidates=Tuple{String,Float64,Float64}[]
for rho in (0.,.005,.01,.02,.05)
    push!(candidates,("single_tv",rho,0.))
    for delta in (0.,.01,.05,.1)
        push!(candidates,("proposed",rho,delta))
    end
end
for (method,rho,delta) in candidates
    candidate="$(method)_rho$(rho)_delta$(delta)"
    localcfg=merge(cfg,Dict("rho"=>rho,"delta"=>delta))
    for t in states
        (candidate,t) in seen && continue
        sol=solve_method(case,data,support,t,method,localcfg)
        load=vec(data.load_forecast[t,:]);forecast=vec(data.wind_forecast[t,:])
        recourse=physical_recourse(case,sol,load,vec(data.wind_actual[t,:]);policy="fixed_agc",omega=vec(data.omega[t,:]))
        rate=NaN;meanpos=NaN
        if sol.has_values
            omega=map_headroom_errors(case,features[ids,:],forecast,capacities)
            for w in eachindex(capacities),i in eachindex(ids)
                z=features[ids[i],w]
                actual=forecast[w]+z*(z<0 ? forecast[w] : capacities[w]-forecast[w])
                omega[i,case.wind_bus_idx[w]]+=max(sol.wind_spill[w]-actual,0.0)
            end
            values=[DRCCOLS.max_violation(case,sol,load,forecast,vec(omega[i,:])) for i in eachindex(ids)]
            rate=mean(values.>1e-6);meanpos=mean(max.(values,0.0))
        end
        push!(rows,(candidate=candidate,method=method,rho=rho,delta=delta,time_index=t,
            status=sol.status,ens_mwh=recourse.energy,preventive_mwh=sol.load_shed,
            emergency_mwh=recourse.emergency,residual_mw=recourse.residual,
            validation_scenarios=length(ids),joint_violation_rate=rate,mean_positive_violation_mw=meanpos))
        CSV.write(file,rows)
    end
    println(system," ",candidate," complete");flush(stdout)
end
summary=DataFrame()
for g in groupby(rows,[:candidate,:method,:rho,:delta])
    complete=nrow(g)==length(states)&&all(==("OPTIMAL"),g.status)
    push!(summary,(candidate=g.candidate[1],method=g.method[1],rho=g.rho[1],delta=g.delta[1],
        complete=complete,mean_ens_mwh=complete ? round(mean(g.ens_mwh),digits=6) : NaN,
        mean_joint_violation_rate=complete ? mean(g.joint_violation_rate) : NaN,
        mean_emergency_mwh=complete ? mean(g.emergency_mwh) : NaN,
        residual_hours=count(>(1e-5),g.residual_mw)))
end
CSV.write(joinpath(out,"candidate_summary.csv"),summary)
selection=Dict{String,Any}("stage"=>"coarse validation; confirm on continuous validation before final test",
    "validation_states"=>states,"distinct_validation_errors"=>length(ids),"risk_target"=>.05)
for method in ("single_tv","proposed")
    eligible=filter(r->r.method==method&&r.complete&&r.mean_joint_violation_rate<=.05&&r.residual_hours==0,summary)
    if nrow(eligible)>0
        sort!(eligible,[:mean_ens_mwh,:mean_joint_violation_rate,:rho,:delta])
        r=first(eachrow(eligible))
        selection[method]=Dict("rho"=>r.rho,"delta"=>r.delta,"mean_ens_mwh"=>r.mean_ens_mwh,
            "joint_violation_rate"=>r.mean_joint_violation_rate)
    end
end
open(joinpath(out,"coarse_selection.json"),"w") do io;JSON.print(io,selection,2);end
println(JSON.json(selection))
