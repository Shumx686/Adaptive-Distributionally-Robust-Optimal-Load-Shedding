include("common.jl")
out=joinpath(WORK,"results","audit"); mkpath(out)
rows=DataFrame(); regrows=DataFrame()
for system in ("rbts","rts79","gmlc")
    case,data,capacities,diag=load_system(system)
    train=data.omega[1:720,:]
    support=shared_support(train,3,240,20261021;selector="legacy_confidence")
    weights=support.gmm.weights
    for k in 1:3
        push!(regrows,(system=system,regime=k,nominal_weight=weights[k],
            train_hard_count=count(i->argmax(@view(support.gmm.gamma_train[i,:]))==k,1:720),
            legacy_support_count=length(support.ids[k])))
    end
    load=vec(sum(data.load_forecast,dims=2)); wind=vec(sum(data.wind_forecast,dims=2))
    errors=vec(sum(data.omega,dims=2))
    for c in (1.0,0.9,0.85,0.8,0.75,0.7)
        # The pre-test validation interval only. No method outcomes used here.
        ids=721:1392
        head=c*sum(case.gen[:,9]).+wind[ids].-load[ids]
        push!(rows,(system=system,buses=size(case.bus,1),branches=size(case.branch,1),
            dispatchable_units=size(case.gen,1),wind_farms=length(capacities),
            conventional_mw=sum(case.gen[:,9]),wind_capacity_mw=sum(capacities),
            aligned_hours=length(load),peak_load_mw=maximum(load),capacity_scale=c,
            validation_negative_headroom_hours=count(<(0.0),head),
            validation_min_headroom_mw=minimum(head),error_sd_mw=std(errors[1:720]),
            legacy_pool_overlap=length(intersect(vcat(support.ids...),support.global_ids)),
            legacy_local_support=sum(length.(support.ids)),legacy_global_support=length(support.global_ids)))
    end
    CSV.write(joinpath(out,system*"_stress_transform.csv"),diag)
    println(system," buses=",size(case.bus,1)," branches=",size(case.branch,1)," units=",size(case.gen,1),
        " wind=",sum(capacities)," MW; legacy regime counts=",length.(support.ids)); flush(stdout)
end
CSV.write(joinpath(out,"system_profile.csv"),rows)
CSV.write(joinpath(out,"legacy_support_profile.csv"),regrows)
