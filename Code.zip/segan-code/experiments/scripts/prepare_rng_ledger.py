"""Give each test stream a unique seed within a system; archive replaced draws."""
from pathlib import Path
import collections
import json
import shutil
import pandas as pd

root=Path(__file__).resolve().parents[1]/'results/controlled_beta_repetitions'
done=root/'rng_ledger_prepared.json'
if done.exists():
    print('Seed ledger already prepared; retained rows are unchanged.')
    raise SystemExit(0)
records=[]
for p in sorted(root.glob('rep*/rbts/protocol.json')):
    j=json.loads(p.read_text('utf-8'))
    for context,t in enumerate(j['contexts'],1):
        records.extend([dict(replication=p.parent.parent.name,seed=j['seed'],context=context,
            stream=stream,test_seed=j['seed']+offset+t) for stream,offset in [('class',2),('wind',3)]])
assert len(records)==60
counts=collections.Counter(r['test_seed'] for r in records)
overrides={}
for r in records:
    if r['stream']=='wind' and counts[r['test_seed']]>1:
        overrides[f'{r["seed"]}_{r["context"]}']=10000*r['seed']+100*r['context']+3
        r['original_seed']=r['test_seed'];r['test_seed']=overrides[f'{r["seed"]}_{r["context"]}']
assert len({r['test_seed'] for r in records})==60
train_seeds={20261022+100*k+offset for k in range(1,11) for offset in [0,1]}
assert not train_seeds.intersection(r['test_seed'] for r in records)
ledger={'wind_seed_overrides':overrides,'streams':records,
    'rule':'Class stream uses seed+2+t. Wind stream uses seed+3+t except deterministic namespace overrides for colliding stream identifiers.',
    'independence_scope':'All sixty test streams within each system have distinct seed identifiers and are separate from training generators. Systems retain paired regime histories.',
    'selection_basis':'Seed identifiers only; performance outcomes do not enter stream assignment.'}
(root/'test_rng_ledger.json').write_text(json.dumps(ledger,indent=2),'utf-8')
archive=root.parent/'controlled_beta_rng_archive';archive.mkdir(exist_ok=True)
for name in ['all_dispatches.csv','replication_means.csv','method_summary.csv','paired_comparisons.csv','RESULTS.md','repeated_performance.png','verification.json']:
    if (root/name).exists():shutil.copy2(root/name,archive/name)
for system in ['rbts','rts79','gmlc']:
    for folder in sorted(root.glob('rep*')):
        p=folder/system/'protocol.json'
        if not p.exists():continue
        j=json.loads(p.read_text('utf-8'));rep=folder.name
        seeds=[];redo=[]
        for context,t in enumerate(j['contexts'],1):
            key=f'{j["seed"]}_{context}';wind=overrides.get(key,j['seed']+3+t)
            seeds.append(dict(context=context,class_seed=j['seed']+2+t,wind_seed=wind))
            if key in overrides:redo.append(context)
        if redo:
            backup=archive/rep/system;backup.mkdir(parents=True,exist_ok=True)
            for name in ['protocol.json','summary.csv','completed.json']:
                shutil.copy2(folder/system/name,backup/name)
            for context in redo:
                for f in (folder/system).glob(f'scenarios_{context}_*.csv'):shutil.copy2(f,backup/f.name)
            d=pd.read_csv(folder/system/'summary.csv')
            d[~d.context.isin(redo)].to_csv(folder/system/'summary.csv',index=False)
            # A completed marker refers to a fully retained 15-dispatch table.
            # Keep the old marker in the archive and replace it with repair status.
            (folder/system/'completed.json').rename(folder/system/'completed_before_rng_ledger.json')
        j['test_rng_seeds']=seeds
        p.write_text(json.dumps(j,indent=2),'utf-8')
done.write_text(json.dumps({'overrides':overrides,'prepared':True,'archive':str(archive)},indent=2),'utf-8')
print('Distinct test streams per system:',len(records),'Reassigned wind streams:',len(overrides))
