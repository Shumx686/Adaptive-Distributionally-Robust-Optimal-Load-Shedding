"""Export a frozen paired test only after the operational validation is complete."""
from pathlib import Path
import hashlib
import json
import tomllib

root = Path(__file__).resolve().parents[1]
protocol_path = root / 'config/joint_validation_rts79_v2.toml'
protocol = tomllib.loads(protocol_path.read_text('utf-8'))
folder = root / 'results' / protocol['name']
selection_path = folder / 'selected_parameters.json'
selection = json.loads(selection_path.read_text('utf-8'))
digest = hashlib.sha256(protocol_path.read_bytes()).hexdigest()
assert selection['protocol_sha256'] == digest
name = 'joint_test_rts79_576h'
lines = [
    f'name = "{name}"', 'systems = ["rts79"]',
    'methods = ["deterministic_headroom", "empirical_cvar", "single_tv", "mixture_static", "mixture_rolling", "proposed"]',
    f'days = {json.dumps(protocol["test_days"])}',
    f'hours = {json.dumps(protocol["test_hours"])}',
]
for key in ('train_hours', 'budget', 'K', 'seed', 'capacity_scale', 'epsilon', 'time_limit'):
    lines.append(f'{key} = {protocol[key]}')
for key in ('selector', 'support_mapping', 'solver'):
    lines.append(f'{key} = "{protocol[key]}"')
lines += [
    'error_multiplier = 1.0', 'stage = "test"', 'record_clipped_affine = true',
    'record_perfect_information = true',
    'parameter_source = "joint operational validation; uniform states plus forecast-margin strata; exact indices retained"',
    f'validation_protocol_sha256 = "{digest}"',
    f'selection_sha256 = "{hashlib.sha256(selection_path.read_bytes()).hexdigest()}"',
]
for key in ('rho', 'delta', 'window', 'kappa', 'blend'):
    lines.append(f'{key} = {selection["proposed"][key]}')
for method in ('single_tv', 'proposed'):
    lines += ['', f'[method_parameters.{method}]']
    for key in ('rho', 'delta', 'window', 'kappa', 'blend'):
        lines.append(f'{key} = {selection[method][key]}')
target = root / 'config' / f'{name}.toml'
content = '\n'.join(lines) + '\n'
if target.exists():
    assert target.read_text('utf-8') == content, 'Existing frozen test config differs'
else:
    target.write_text(content, 'utf-8')
print(target)
print(json.dumps(selection, ensure_ascii=False, indent=2))
for part in range(4):
    part_name = f'{name}_part{part+1}'
    part_content = content.replace(f'name = "{name}"', f'name = "{part_name}"', 1)
    part_content = part_content.replace(
        f'days = {json.dumps(protocol["test_days"])}',
        f'days = {json.dumps(protocol["test_days"][6*part:6*(part+1)])}', 1)
    part_path = target.with_name(f'{part_name}.toml')
    if part_path.exists():
        assert part_path.read_text('utf-8') == part_content
    else:
        part_path.write_text(part_content, 'utf-8')
    print(part_path)

refresh_protocol=json.loads((root/'config/support_refresh_protocol.json').read_text('utf-8'))
refresh_name='support_refresh_rts79_96h'
refresh_content=content.replace(f'name = "{name}"',f'name = "{refresh_name}"',1)
refresh_content=refresh_content.replace(f'days = {json.dumps(protocol["test_days"])}',
    f'days = {json.dumps(refresh_protocol["test_days"])}',1)
refresh_content=refresh_content.replace('stage = "test"','stage = "test"\ntraining_scheme = "preceding_720_each_selected_day"',1)
parent_content=refresh_content+'\n[training_end_hours_by_day]\n'+''.join(
    f'"{day}" = {24*(day-1)}\n' for day in refresh_protocol['test_days'])
(target.parent/f'{refresh_name}.toml').write_text(parent_content,'utf-8')
for part,day in enumerate(refresh_protocol['test_days'],1):
    part_content=refresh_content.replace(f'name = "{refresh_name}"',f'name = "{refresh_name}_part{part}"',1)
    part_content=part_content.replace(f'days = {json.dumps(refresh_protocol["test_days"])}',f'days = [{day}]',1)
    part_content=part_content.replace('stage = "test"',f'stage = "test"\ntraining_end_hour = {24*(day-1)}',1)
    part_path=target.parent/f'{refresh_name}_part{part}.toml'
    if part_path.exists():assert part_path.read_text('utf-8')==part_content
    else:part_path.write_text(part_content,'utf-8')
    print(part_path)
