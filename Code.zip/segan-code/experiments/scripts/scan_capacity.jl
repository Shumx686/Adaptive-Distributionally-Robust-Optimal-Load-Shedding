include("common.jl")
system=ARGS[1]
cfg=TOML.parsefile(joinpath(WORK,"config","pilot_bounded.toml"))
weights=JSON.parsefile(joinpath(WORK,"results","weight_calibration",system,"selected_weights.json"))
for key in ("window","blend","kappa");cfg[key]=weights[key];end
base,data,capacities,_=load_system(system;capacity_scale=1.0)
features=normalized_site_errors(data,capacities);train=features[1:720,:]
support=shared_support(train,3,720,cfg["seed"])
support=merge(support,(normalized_site_errors=features,support_training_features=train,capacities=capacities))
out=joinpath(WORK,"results","capacity_scan",system);mkpath(out)
file=joinpath(out,"hourly.csv")
rows=isfile(file) ? CSV.read(file,DataFrame;stringtype=String,pool=false) : DataFrame()
seen=Set(isempty(rows) ? Tuple{Float64,Int,String}[] : [(Float64(r.capacity_scale),Int(r.time_index),String(r.method)) for r in eachrow(rows)])
states=[24*(d-1)+h for d in (91,181,271,331) for h in (1,7,13,19)]
for c in (1.,.9,.85,.8,.75,.7)
    gen=copy(base.gen);gen[:,9:10].*=c
    case=DRCCOLS.RBTSCase(base.base_mva,base.bus,gen,base.branch,base.bus_ids,
        base.gen_bus_idx,base.wind_bus_idx,base.line_rates,base.ptdf)
    for t in states,method in cfg["methods"]
        (c,t,method) in seen && continue
        sol=solve_method(case,data,support,t,method,cfg)
        load=vec(data.load_forecast[t,:]);wind=vec(data.wind_forecast[t,:]);omega=vec(data.omega[t,:])
        rec=physical_recourse(case,sol,load,vec(data.wind_actual[t,:]);policy="fixed_agc",omega=omega)
        v=DRCCOLS.max_violation(case,sol,load,wind,omega)
        push!(rows,(system=system,capacity_scale=c,time_index=t,time=data.times[t],method=method,status=sol.status,
            total_ens_mwh=rec.energy,preventive_mwh=sol.load_shed,emergency_mwh=rec.emergency,
            residual_mw=rec.residual,joint_violated=isfinite(v) ? Int(v>1e-6) : -1,
            solve_seconds=sol.solve_time))
        CSV.write(file,rows[end:end,:];append=nrow(rows)>1,writeheader=nrow(rows)==1)
    end
    println(system," capacity=",c," complete");flush(stdout)
    GC.gc()
end
open(joinpath(out,"completed.json"),"w") do io
    JSON.print(io,Dict("rows"=>nrow(rows),"expected_rows"=>576,"states_per_capacity"=>16,
        "capacity_scales"=>[1.,.9,.85,.8,.75,.7],"weight_parameters"=>weights),2)
end
