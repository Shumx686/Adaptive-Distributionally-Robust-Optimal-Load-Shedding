from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]/'results/capacity_scan'
files=sorted(ROOT.glob('*/hourly.csv'));rows=[]
for f in files:
    d=pd.read_csv(f)
    for (c,method),g in d.groupby(['capacity_scale','method']):
        ok=g[g.status.eq('OPTIMAL')]
        rows.append(dict(system=f.parent.name,capacity_scale=c,method=method,optimal_hours=len(ok),expected_hours=16,
            mean_ens_mwh=ok.total_ens_mwh.mean(),mean_preventive_mwh=ok.preventive_mwh.mean(),
            mean_emergency_mwh=ok.emergency_mwh.mean(),joint_violation_pct=100*ok.joint_violated.mean(),
            residual_pct=100*(ok.residual_mw>1e-5).mean() if len(ok) else np.nan))
s=pd.DataFrame(rows);s.to_csv(ROOT/'summary.csv',index=False,encoding='utf-8-sig')
systems=sorted(s.system.unique());fig,axs=plt.subplots(2,len(systems),figsize=(6*len(systems),7.5),squeeze=False)
for j,system in enumerate(systems):
    for method,label,marker in [('single_tv','Single-TV','o'),('mixture_static','Static','s'),('mixture_rolling','Rolling','^'),('proposed','Proposed','*')]:
        g=s[s.system.eq(system)&s.method.eq(method)].sort_values('capacity_scale')
        for k,col in enumerate(['mean_ens_mwh','joint_violation_pct']):
            axs[k,j].plot(g.capacity_scale,g[col],marker=marker,label=label,lw=1.4,ms=8 if marker=='*' else 4)
    axs[0,j].set_title(system.upper());axs[0,j].set_ylabel('Mean total ENS (MWh/state)')
    axs[1,j].set_ylabel('Pre-correction joint violations (%)')
    for ax in axs[:,j]:ax.set_xlabel('Conventional capacity multiplier');ax.grid(alpha=.2)
h,l=axs[0,0].get_legend_handles_labels();fig.legend(h,l,loc='lower center',ncol=4,frameon=False)
fig.tight_layout(rect=(0,.06,1,1));fig.savefig(ROOT/'capacity_performance.png',dpi=180);plt.close(fig)
p=s[s.method.isin(['single_tv','proposed'])].pivot(index=['system','capacity_scale'],columns='method',values='mean_ens_mwh')
p['reduction_pct']=100*(p.single_tv-p.proposed)/p.single_tv.replace(0,np.nan)
p.to_csv(ROOT/'paired_energy.csv',encoding='utf-8-sig')
print(p.to_string())
