function category(rng,p)
    u=rand(rng);return min(searchsortedfirst(cumsum(p),u),length(p))
end

# Marsaglia-Tsang Gamma sampler; the configured Beta shapes are all above one.
function gamma_draw(rng,a)
    a>1 || error("This sampler requires Gamma shape > 1")
    d=a-1/3;c=1/sqrt(9d)
    while true
        x=randn(rng);v=1+c*x;v<=0 && continue;v=v^3;u=rand(rng)
        (u<1-.0331*x^4 || log(u)<.5*x*x+d*(1-v+log(v))) && return d*v
    end
end

function beta_draw(rng,mu,sigma)
    h=mu*(1-mu)/sigma^2-1;a=mu*h;b=(1-mu)*h
    x=gamma_draw(rng,a);y=gamma_draw(rng,b);return x/(x+y)
end
