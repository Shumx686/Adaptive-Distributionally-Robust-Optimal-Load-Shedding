include("common.jl")
include("beta_generator.jl")
function run_controlled_beta(system,seed,study="controlled_beta";loaded=nothing)
case,source,capacities,_=loaded===nothing ? load_system(system;capacity_scale=.85) : loaded
nb=size(case.bus,1);nw=length(capacities);n=2160;N=1000

means=[.25,.5,.75];sds=[.05,.07,.05];prior=[.3,.4,.3];persistence=.95
state_rng=MersenneTwister(seed);wind_rng=MersenneTwister(seed+1)
states=zeros(Int,n);states[1]=category(state_rng,prior)
for t=2:n
    states[t]=rand(state_rng)<persistence ? states[t-1] : category(state_rng,prior)
end
forecast=0.5 .* capacities
# A common high-utilization operating condition, defined without method outcomes.
# Baseline demand = conventional availability + one quarter of installed wind;
# the mean forecast supplies half of installed wind, leaving a quarter for reserve.
load_total=sum(case.gen[:,9])+0.25*sum(capacities)
profile=vec(source.load_forecast[24*(181-1)+13,:]);load=profile./sum(profile).*load_total
actual=zeros(n,nw)
for t=1:n,w=1:nw
    actual[t,w]=capacities[w]*beta_draw(wind_rng,means[states[t]],sds[states[t]])
end
omega=zeros(n,nb)
for w=1:nw;omega[:,case.wind_bus_idx[w]].+=actual[:,w].-forecast[w];end
times=[string(DateTime(2020,1,1)+Hour(t-1)) for t=1:n]
data=DRCCOLS.ExperimentData(times,repeat(load',n,1),repeat(load',n,1),actual,
    repeat(forecast',n,1),omega,DataFrame(),DataFrame())
support=shared_support(omega[1:720,:],3,720,seed)
gamma=DRCCOLS.responsibilities(support.gmm,omega)
cfg=TOML.parsefile(joinpath(WORK,"config","pilot_bounded.toml"))
cfg["support_mapping"]="raw";cfg["delta"]=.1
# Select online-weight settings using only the distinct validation block.
best_score=Inf;selected=nothing
for window in (6,12,24,48,96),blend in (0.,.25,.5,.75,1.),kappa in (0.,5.,10.,25.,50.)
    score=0.
    for t=721:1440
        counts=vec(sum(gamma[max(1,t-window):t-1,:],dims=1))
        roll=(counts.+kappa.*support.gmm.weights)./(window+kappa)
        pi=blend.*vec(gamma[t-1,:]).+(1-blend).*roll
        score-=dot(vec(gamma[t,:]),log.(max.(pi,1e-12)))/720
    end
    if score<best_score-1e-10
        best_score=score
        selected=(window=window,blend=blend,kappa=kappa)
    end
end
for key in (:window,:blend,:kappa);cfg[string(key)]=getproperty(selected,key);end
# Balance three recurring operating regimes using the known generator labels.
# This case definition uses the previous regime history, never the target draw.
contexts=Int[]
for k=1:3
    ids=[t for t=1441:n if all(==(k),states[t-12:t-1])]
    isempty(ids) && error("Synthetic benchmark has no stable context for regime $k")
    push!(contexts,first(ids))
end
overrides=Dict()
ledger=joinpath(WORK,"config","controlled_beta_test_rng_ledger.json")
!isfile(ledger) && (ledger=joinpath(WORK,"results","controlled_beta_repetitions","test_rng_ledger.json"))
if startswith(study,"controlled_beta_repetitions")&&isfile(ledger)
    overrides=JSON.parsefile(ledger)["wind_seed_overrides"]
end
test_seeds=[Dict("context"=>k,"class_seed"=>seed+2+t,
    "wind_seed"=>get(overrides,"$(seed)_$(k)",seed+3+t)) for (k,t) in enumerate(contexts)]
out=joinpath(WORK,"results",study,system);mkpath(out)
open(joinpath(out,"protocol.json"),"w") do io
    JSON.print(io,Dict("source"=>"simulated bounded Beta regime-switching benchmark","seed"=>seed,
        "train_hours"=>720,"validation_hours"=>720,"test_scenarios_per_context"=>N,
        "conditional_means_pu"=>means,"conditional_sd_pu"=>sds,"stationary_prior"=>prior,
        "state_persistence"=>persistence,"contexts"=>contexts,"test_rng_seeds"=>test_seeds,
        "weight_parameters"=>Dict(string(k)=>getproperty(selected,k) for k in keys(selected)),
        "load_total_mw"=>load_total,"load_rule"=>"0.85 conventional capacity + 0.25 installed wind",
        "forecast_rule"=>"0.50 installed wind at every wind farm", "rho"=>cfg["rho"],
        "delta"=>cfg["delta"],"epsilon"=>cfg["epsilon"]),2)
end
file=joinpath(out,"summary.csv")
rows=isfile(file) ? CSV.read(file,DataFrame;stringtype=String,pool=false) : DataFrame()
seen=Set(isempty(rows) ? Tuple{Int,String}[] : [(Int(r.context),String(r.method)) for r in eachrow(rows)])
methods=["empirical_cvar","single_tv","mixture_static","mixture_rolling","proposed"]
for (context,t) in enumerate(contexts)
    true_weights=(1-persistence).*prior;true_weights[states[t-1]]+=persistence
    class_rng=MersenneTwister(test_seeds[context]["class_seed"])
    sample_rng=MersenneTwister(test_seeds[context]["wind_seed"])
    classes=[category(class_rng,true_weights) for _=1:N]
    sample_actual=zeros(N,nw);sample_omega=zeros(N,nb)
    for i=1:N,w=1:nw
        sample_actual[i,w]=capacities[w]*beta_draw(sample_rng,means[classes[i]],sds[classes[i]])
        sample_omega[i,case.wind_bus_idx[w]]+=sample_actual[i,w]-forecast[w]
    end
    for method in methods
        (context,method) in seen && continue
        sol=solve_method(case,data,support,t,method,cfg)
        ens=Float64[];emerg=Float64[];viol=Float64[];residual=Float64[]
        if sol.has_values
            for i=1:N
                original=vec(sample_omega[i,:]);adjusted=copy(original)
                for w=1:nw
                    adjusted[case.wind_bus_idx[w]]+=max(sol.wind_spill[w]-sample_actual[i,w],0.)
                end
                v=DRCCOLS.max_violation(case,sol,load,forecast,adjusted)
                rec=physical_recourse(case,sol,load,vec(sample_actual[i,:]);policy="fixed_agc",omega=original)
                push!(ens,rec.energy);push!(emerg,rec.emergency);push!(viol,Float64(v>1e-6));push!(residual,rec.residual)
            end
            CSV.write(joinpath(out,"scenarios_$(context)_$(method).csv"),DataFrame(
                sample=1:N,true_regime=classes,ens_mwh=ens,emergency_mwh=emerg,violated=viol,residual_mw=residual))
        end
        push!(rows,(system=system,context=context,previous_true_regime=states[t-1],time_index=t,
            method=method,status=sol.status,n_scenarios=length(ens),preventive_mwh=sol.load_shed,
            expected_ens_mwh=isempty(ens) ? NaN : mean(ens),
            mean_emergency_mwh=isempty(emerg) ? NaN : mean(emerg),
            joint_violation_pct=isempty(viol) ? NaN : 100mean(viol),
            residual_pct=isempty(residual) ? NaN : 100mean(residual.>1e-5),
            ens_standard_error=isempty(ens) ? NaN : std(ens)/sqrt(N),solve_seconds=sol.solve_time))
        CSV.write(file,rows[end:end,:];append=nrow(rows)>1,writeheader=nrow(rows)==1)
        println(system," controlled context=",context," ",method," ",sol.status,
            " EENS=",rows.expected_ens_mwh[end]," joint%=",rows.joint_violation_pct[end]);flush(stdout)
    end
end
open(joinpath(out,"completed.json"),"w") do io
    JSON.print(io,Dict("planned_dispatches"=>15,"recorded_dispatches"=>nrow(rows),"planned_scenario_checks"=>15000),2)
end
return rows
end

if abspath(PROGRAM_FILE)==@__FILE__
    system=ARGS[1];seed=length(ARGS)>=2 ? parse(Int,ARGS[2]) : 20261021
    study=length(ARGS)>=3 ? ARGS[3] : "controlled_beta"
    run_controlled_beta(system,seed,study)
end
