include("common.jl")
system=ARGS[1]
case,data,capacities,_=load_system(system;capacity_scale=.85)
z=normalized_site_errors(data,capacities)
gmm=DRCCOLS.fit_diag_gmm(z[1:720,:],3;max_iter=100,seed=20261021)
gamma=DRCCOLS.responsibilities(gmm,z[1:1440,:])
cum=vcat(zeros(1,3),cumsum(gamma,dims=1))
targets=gamma[721:1440,:]
ce(pi)=mean(-sum(targets.*log.(max.(pi,1e-12)),dims=2))
brier(pi)=mean(sum((targets.-pi).^2,dims=2))
rows=DataFrame()
static=repeat(gmm.weights',720,1)
push!(rows,(window=0,blend=0.0,kappa=0.0,cross_entropy=ce(static),brier=brier(static),method="static"))
for window in (6,12,24,48,96),blend in (0.,.25,.5,.75,1.),kappa in (0.,5.,10.,25.,50.)
    pi=zeros(720,3)
    for (i,t) in enumerate(721:1440)
        lo=max(1,t-window);hi=t-1
        counts=vec(cum[hi+1,:].-cum[lo,:])
        roll=(counts.+kappa.*gmm.weights)./(hi-lo+1+kappa)
        pi[i,:].=blend.*vec(gamma[t-1,:]).+(1-blend).*roll
    end
    push!(rows,(window=window,blend=blend,kappa=kappa,cross_entropy=ce(pi),brier=brier(pi),method="adaptive"))
end
out=joinpath(WORK,"results","weight_calibration",system);mkpath(out)
sort!(rows,[:cross_entropy,:brier,:window,:kappa,:blend])
CSV.write(joinpath(out,"validation_scores.csv"),rows)
best=first(eachrow(filter(r->r.method=="adaptive",rows)))
open(joinpath(out,"selected_weights.json"),"w") do io
    JSON.print(io,Dict("system"=>system,"stage"=>"validation, days 31-60",
        "criterion"=>"mean cross-entropy to held-out regime responsibilities",
        "window"=>best.window,"blend"=>best.blend,"kappa"=>best.kappa,
        "cross_entropy"=>best.cross_entropy,"brier"=>best.brier,
        "static_cross_entropy"=>ce(static),"static_brier"=>brier(static)),2)
end
println(read(joinpath(out,"selected_weights.json"),String))
