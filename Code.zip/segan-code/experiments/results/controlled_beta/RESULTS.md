# Controlled mechanism experiment: bounded Beta errors and regime switching

This is a simulated mechanism benchmark, separate from the historical-data replays. Three persistent error regimes have Beta means of 0.25, 0.50, 0.75 p.u. and standard deviations of 0.05, 0.07, 0.05 p.u. The latent state persists with probability 0.95; otherwise it is redrawn from (0.3, 0.4, 0.3). The dispatch uses only observed error history. Each of three balanced test contexts uses 1,000 independent draws from the true conditional mixture. All methods share the same training observations and test draws.

Training and validation contain 720 hours each. The validation block selects the online weight parameters. The common nominal wind is half of installed capacity; common demand is 0.85 of original conventional capacity plus 0.25 of installed wind. Local TV radius is 0.01, outer protection is 0.10, and epsilon is 0.05. Neither load level nor test contexts are chosen from method outcomes.

|System|Method|Contexts|Checks|Expected ENS (MWh)|Emergency (MWh)|Joint violation (%)|
|---|---|---:|---:|---:|---:|---:|
|gmlc|empirical_cvar|3/3|3000|212.134|0.250|1.833|
|gmlc|single_tv|3/3|3000|219.950|0.288|1.867|
|gmlc|mixture_static|3/3|3000|216.578|0.211|1.700|
|gmlc|mixture_rolling|3/3|3000|147.592|1.163|1.467|
|gmlc|proposed|3/3|3000|194.032|0.027|0.867|
|rbts|empirical_cvar|3/3|3000|3.238|0.004|0.800|
|rbts|single_tv|3/3|3000|3.417|0.003|0.633|
|rbts|mixture_static|3/3|3000|3.314|0.003|0.700|
|rbts|mixture_rolling|3/3|3000|1.262|0.007|1.067|
|rbts|proposed|3/3|3000|2.121|0.002|0.567|
|rts79|empirical_cvar|3/3|3000|22.234|0.110|2.200|
|rts79|single_tv|3/3|3000|24.700|0.069|1.600|
|rts79|mixture_static|3/3|3000|23.450|0.088|1.800|
|rts79|mixture_rolling|3/3|3000|9.311|0.100|1.633|
|rts79|proposed|3/3|3000|15.437|0.062|1.067|

The expected ENS includes both preventive and corrective energy. Joint violations are evaluated before corrective action; all post-correction residuals are retained. The paired interval in paired_comparisons.csv measures Monte Carlo sampling uncertainty for the fixed training set and three balanced contexts. It does not include variation across independently trained models.

![Controlled mechanism results](controlled_performance.png)
