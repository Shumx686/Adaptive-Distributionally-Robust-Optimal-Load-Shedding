# cross_season_rts79_96h: recorded experiment results

Metrics are evaluated on the fixed calendar. ENS includes preventive and emergency shedding. Pre-correction affine-policy violations and post-correction physical security are separate metrics. Raw and bounded-support studies use different uncertainty inputs and should be interpreted as distinct experiments.

|System|Method|Optimal / planned|Mean ENS (MWh)|Emergency (MWh)|Joint violation (%)|Residual (%)|
|---|---|---:|---:|---:|---:|---:|
|rts79|deterministic_headroom|96/96|35.461|34.647|96.88|0.00|
|rts79|empirical_cvar|96/96|5.881|0.000|0.00|0.00|
|rts79|single_tv|96/96|6.228|0.000|0.00|0.00|
|rts79|mixture_static|96/96|6.085|0.000|0.00|0.00|
|rts79|mixture_rolling|96/96|6.513|0.000|0.00|0.00|
|rts79|proposed|96/96|6.540|0.000|0.00|0.00|

All means use the stated solved-hour denominator. A full-calendar total is emitted only for complete runs. Paired estimates and day-cluster intervals are in paired_comparisons.csv; intervals require at least seven evaluated days. These are study-period operational metrics, with no annualization.

![Energy and security](energy_security.png)
