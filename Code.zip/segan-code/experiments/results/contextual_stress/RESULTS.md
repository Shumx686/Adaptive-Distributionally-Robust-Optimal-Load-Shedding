# Fixed operating contexts: 1,000 held-out error records per context

Each context uses the 1,000 nearest held-out records based only on forecast wind, lagged normalized wind error and its trailing 48-hour mean. Feature scales are fitted on the training interval. The target realized error is not used in matching. All methods share the matched source rows, and fixed dispatches are reused from scenario_stress. This is an empirical approximation to conditional evaluation, preserving cross-farm error vectors.

|System|Method|Solved states|Scenario checks|Preventive (MWh/state)|Joint violations (%)|
|---|---|---:|---:|---:|---:|
|gmlc|deterministic_headroom|4/4|4000|0.000|100.00|
|gmlc|empirical_cvar|3/4|3000|87.190|0.30|
|gmlc|single_tv|3/4|3000|98.383|0.23|
|gmlc|mixture_static|3/4|3000|96.564|0.23|
|gmlc|mixture_rolling|3/4|3000|90.773|0.23|
|gmlc|proposed|3/4|3000|91.727|0.23|
|rbts|deterministic_headroom|4/4|4000|0.000|77.90|
|rbts|empirical_cvar|4/4|4000|0.000|0.03|
|rbts|single_tv|4/4|4000|0.000|0.03|
|rbts|mixture_static|4/4|4000|0.000|0.03|
|rbts|mixture_rolling|4/4|4000|0.000|0.10|
|rbts|proposed|4/4|4000|0.000|0.10|
|rts79|deterministic_headroom|4/4|4000|0.000|100.00|
|rts79|empirical_cvar|4/4|4000|0.144|2.35|
|rts79|single_tv|4/4|4000|1.312|1.57|
|rts79|mixture_static|4/4|4000|0.839|1.93|
|rts79|mixture_rolling|4/4|4000|2.650|2.98|
|rts79|proposed|4/4|4000|2.680|2.93|

The security metric limits scheduled wind spilling to realized wind availability before testing the fixed affine policy. No emergency correction is included in this probability. Source-day paired bootstrap intervals are supplied in paired_security.csv. A parameter point is a trade-off observation; method comparison at a target risk requires validation-calibrated frontiers.
