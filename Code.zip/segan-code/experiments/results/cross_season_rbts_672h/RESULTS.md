# cross_season_rbts_672h: recorded experiment results

Metrics are evaluated on the fixed calendar. ENS includes preventive and emergency shedding. Pre-correction affine-policy violations and post-correction physical security are separate metrics. Raw and bounded-support studies use different uncertainty inputs and should be interpreted as distinct experiments.

|System|Method|Optimal / planned|Mean ENS (MWh)|Emergency (MWh)|Joint violation (%)|Residual (%)|
|---|---|---:|---:|---:|---:|---:|
|rbts|deterministic_headroom|672/672|3.389|3.389|86.46|0.00|
|rbts|empirical_cvar|672/672|0.000|0.000|2.98|0.00|
|rbts|single_tv|672/672|0.000|0.000|2.83|0.00|
|rbts|mixture_static|672/672|0.000|0.000|2.83|0.00|
|rbts|mixture_rolling|672/672|0.000|0.000|1.64|0.00|
|rbts|proposed|672/672|0.000|0.000|1.64|0.00|

All means use the stated solved-hour denominator. A full-calendar total is emitted only for complete runs. Paired estimates and day-cluster intervals are in paired_comparisons.csv; intervals require at least seven evaluated days. These are study-period operational metrics, with no annualization.

![Energy and security](energy_security.png)
