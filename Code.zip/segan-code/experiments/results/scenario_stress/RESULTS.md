# Fixed operating contexts: 1,000 held-out error records per context

Each system uses four predefined seasonal operating contexts. Test errors are sampled without replacement from records outside the training interval, then mapped through the current forecast headroom. All methods share the source row IDs. These are operational stress checks; repeated contexts do not multiply the number of distinct historical error observations.

|System|Method|Solved states|Scenario checks|Preventive (MWh/state)|Joint violations (%)|
|---|---|---:|---:|---:|---:|
|gmlc|deterministic_headroom|4/4|4000|0.000|100.00|
|gmlc|empirical_cvar|3/4|3000|87.190|1.10|
|gmlc|single_tv|3/4|3000|98.383|0.77|
|gmlc|mixture_static|3/4|3000|96.564|0.80|
|gmlc|mixture_rolling|3/4|3000|90.773|1.37|
|gmlc|proposed|3/4|3000|91.727|1.13|
|rbts|deterministic_headroom|4/4|4000|0.000|66.35|
|rbts|empirical_cvar|4/4|4000|0.000|4.30|
|rbts|single_tv|4/4|4000|0.000|4.10|
|rbts|mixture_static|4/4|4000|0.000|4.10|
|rbts|mixture_rolling|4/4|4000|0.000|5.55|
|rbts|proposed|4/4|4000|0.000|5.50|
|rts79|deterministic_headroom|4/4|4000|0.000|100.00|
|rts79|empirical_cvar|4/4|4000|0.144|2.35|
|rts79|single_tv|4/4|4000|1.312|1.60|
|rts79|mixture_static|4/4|4000|0.839|1.85|
|rts79|mixture_rolling|4/4|4000|2.650|2.88|
|rts79|proposed|4/4|4000|2.680|2.80|

The security metric limits scheduled wind spilling to realized wind availability before testing the fixed affine policy. No emergency correction is included in this probability. Source-day paired bootstrap intervals are supplied in paired_security.csv. A parameter point is a trade-off observation; method comparison at a target risk requires validation-calibrated frontiers.
