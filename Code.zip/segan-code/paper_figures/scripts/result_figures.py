"""Current paired effects, split operational figures, and convergence figure.

All estimates, intervals, objectives, and residuals come from frozen records.
This module only draws figures; it never runs optimization or resamples data.
"""
import hashlib
import json
from functools import wraps
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.ticker import FixedLocator, LogFormatterMathtext, NullLocator
import figure_assets as assets

ROOT, RES, WIDTH = assets.ROOT, assets.RES, assets.WIDTH
INK, MUTED, RULE = '#203547', '#687b8b', '#dce4e9'
SYSTEMS = [('rbts', 'RBTS', '#31688e', 'o'),
           ('rts79', 'RTS-79', '#267c70', 's'),
           ('gmlc', 'RTS-GMLC', '#b66b43', '^')]


def style():
    plt.rcParams.update({
        'font.family': 'Arial', 'font.size': 9.2, 'axes.labelsize': 9.2,
        'xtick.labelsize': 8.5, 'ytick.labelsize': 8.5,
        'axes.linewidth': .65, 'axes.edgecolor': '#a5b1ba',
        'axes.spines.top': False, 'axes.spines.right': False,
        'axes.axisbelow': True, 'grid.color': RULE, 'grid.linewidth': .45,
        'text.color': INK, 'axes.labelcolor': INK,
        'xtick.color': MUTED, 'ytick.color': MUTED,
        'pdf.fonttype': 42, 'ps.fonttype': 42,
        'savefig.dpi': 600, 'path.simplify': False})


def styled(function):
    @wraps(function)
    def wrapped(*args, **kwargs):
        with plt.rc_context():
            style()
            return function(*args, **kwargs)
    return wrapped


def repetitions():
    from scientific_panels import repetitions as draw
    return draw()


def _scientific(value):
    assert value > 0
    exponent = int(np.floor(np.log10(value)))
    return rf'${value / 10**exponent:.2f}\times10^{{{exponent}}}$'


def convergence(traces=None, data=None):
    from scientific_panels import convergence as draw
    return draw(traces=traces, data=data)


def chronological():
    from operational_curves import chronological as draw
    return draw()


if __name__ == '__main__':
    from scientific_panels import main
    main()
