"""Publication figures from frozen CSV results; no optimization is rerun.

PDF/EPS are the submission masters. PNG files are 600-dpi previews.
All source-data paths and hashes are recorded for reproducibility.
"""
from pathlib import Path
import hashlib
import os
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, FancyArrowPatch
from matplotlib.colors import Normalize

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT.parent / 'experiments' / 'results'
IMG = Path(os.environ.get('SEGAN_FIGURE_OUTPUT', str(ROOT.parent/'outputs/figures')))
WIDTH = 31 * 12 / 72.27  # unmodified sn-jnl single-column text width
COL = {'empirical_cvar':'#707070', 'single_tv':'#27629a',
       'mixture_static':'#806299', 'mixture_rolling':'#a66b00', 'proposed':'#a02e3c',
       'deterministic_headroom':'#3c3c3c'}
LABEL = {'empirical_cvar':'Empirical CVaR','single_tv':'Single-TV',
         'mixture_static':'Static mixture','mixture_rolling':'Rolling mixture',
         'proposed':'Proposed','deterministic_headroom':'Det. + reserves'}
MARK = {'empirical_cvar':'v','single_tv':'o','mixture_static':'s','mixture_rolling':'^','proposed':'D'}
ORDER = ['empirical_cvar','single_tv','mixture_static','mixture_rolling','proposed']
SOURCES = {}
plt.rcParams.update({'font.family':'Arial','font.size':8.5,'axes.labelsize':8.5,
    'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,
    'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,
    'grid.linewidth':.4,'grid.color':'#d9dce0','axes.axisbelow':True,
    'lines.linewidth':1.15,'pdf.fonttype':42,'ps.fonttype':42,
    'svg.fonttype':'none','savefig.dpi':600,'legend.frameon':False,
    'xtick.direction':'out','ytick.direction':'out'})

def read(name):
    path=RES/name
    SOURCES[str(name)] = hashlib.sha256(path.read_bytes()).hexdigest()
    return pd.read_csv(path)

def save(fig,name):
    IMG.mkdir(parents=True,exist_ok=True)
    for ext in ['pdf','eps','png']:
        fig.savefig(IMG/f'{name}.{ext}',facecolor='white')
    plt.close(fig)
    print('Wrote',name)

def box(ax,x,y,w,h,title,body,fill='#f3f5f7'):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.012,rounding_size=0.012',
        facecolor=fill,edgecolor='#66717c',linewidth=.75))
    ax.text(x+.025,y+h-.035,title,ha='left',va='top',weight='bold',fontsize=8.4)
    ax.text(x+.025,y+h-.105,body,ha='left',va='top',fontsize=8.2,linespacing=1.35)

def arrow(ax,a,b):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=9,
        linewidth=.8,color='#4b5662',shrinkA=0,shrinkB=0))

def workflow():
    fig,ax=plt.subplots(figsize=(WIDTH,2.85))
    fig.subplots_adjust(left=.01,right=.99,bottom=.01,top=.99)
    ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
    box(ax,.02,.78,.96,.19,'Offline: fit recurring error regimes',
        'Past errors → standardized features → GMM partition; retain fixed regime samples')
    box(ax,.02,.43,.445,.26,'Within each regime',
        'Empirical support + local radius $\\rho_k$\nLocal ambiguity set $\\mathcal{P}_k^{\\phi}$')
    box(ax,.535,.43,.445,.26,'Before each dispatch',
        'Recent errors + one-step proxy → $\\pi_t$\nOuter weight set $\\mathcal{W}(\\pi_t)$, radius $\\delta_w$')
    arrow(ax,(.24,.768),(.24,.705));arrow(ax,(.76,.768),(.76,.705))
    arrow(ax,(.24,.418),(.24,.355));arrow(ax,(.76,.418),(.76,.355))
    box(ax,.02,.17,.96,.17,'Dispatch: robust CVaR constraint + network and reserve limits',
        'TV: linear program; modified $\\chi^2$: second-order cone program',fill='#eaf0f5')
    arrow(ax,(.5,.158),(.5,.105))
    ax.text(.5,.05,'After realization: affine response → common physical correction → ENS / joint events',
        ha='center',va='center',fontsize=8.1)
    save(fig,'Fig1_workflow')

def repetitions():
    from result_figures import repetitions as draw
    return draw()


def refresh():
    from scientific_panels import refresh as draw
    return draw()


def survival(values):
    # P(ENS > x); ties and zero hours are included exactly, with no artificial p=1 at x=0.
    v=np.where(np.asarray(values)>1e-5,values,0.)
    x,count=np.unique(v,return_counts=True)
    p=1-np.cumsum(count)/len(v)
    keep=p>0
    return x[keep],p[keep]

def calendar(name,days,methods,output):
    d=read(f'{name}/rts79/hourly.csv')
    winter=d[d.day.between(*days)]
    fig=plt.figure(figsize=(WIDTH,4.25))
    gs=fig.add_gridspec(2,2,height_ratios=[1,1.12],width_ratios=[1.12,1],
        left=.20,right=.97,bottom=.12,top=.88,hspace=.75,wspace=.66)
    ax=fig.add_subplot(gs[0,:])
    matrices=[]
    for m in methods:
        h=winter[winter.method.eq(m)].sort_values(['day','hour'])
        assert len(h)==144
        matrices.append(h.fixed_agc_ens_mwh.clip(lower=0).to_numpy())
    im=ax.imshow(matrices,aspect='auto',cmap='cividis',vmin=0,interpolation='nearest')
    ax.set_yticks(range(len(methods)),[LABEL[m] for m in methods]);ax.tick_params(axis='y',length=0)
    ax.set_xticks(np.arange(6)*24+11.5,[str(t) for t in range(days[0],days[1]+1)])
    ax.set_xlabel('Day of year (24 hourly cells per day)')
    for x in np.arange(1,6)*24-.5: ax.axvline(x,color='white',lw=.6)
    cax=fig.add_axes([.62,.96,.34,.016])
    cb=fig.colorbar(im,cax=cax,orientation='horizontal');cb.ax.tick_params(labelsize=7.5,pad=2)
    fig.text(.20,.965,'Hourly ENS (MWh)',fontsize=8,va='center')
    ax.text(0,1.13,'(a)',transform=ax.transAxes,weight='bold')
    has_emergency=d[d.method.isin(methods)].fixed_agc_emergency_mwh.sum()>1e-5
    ax=fig.add_subplot(gs[1,0] if has_emergency else gs[1,:])
    for m,ls in zip(methods,['-','--',':','-.',(0,(3,1,1,1))]):
        x,p=survival(d[d.method.eq(m)].fixed_agc_ens_mwh.to_numpy())
        ax.step(x,p,where='post',color=COL[m],ls=ls,label=LABEL[m],lw=1.25)
    ax.set_yscale('log');ax.set_ylim(1/576,.2);ax.set_xlabel('Hourly ENS, x (MWh)')
    ax.set_ylabel('P(ENS > x)');ax.grid(axis='y',which='major')
    ax.text(0,1.13,'(b)',transform=ax.transAxes,weight='bold')
    # Short distinct line styles retain method identification in monochrome.
    ax.legend(loc='upper right',fontsize=8,handlelength=1.4,labelspacing=.3)
    if not has_emergency:
        save(fig,output)
        return
    ax=fig.add_subplot(gs[1,1])
    for y,m in enumerate(methods):
        val=d[d.method.eq(m)].fixed_agc_emergency_mwh.sum()
        ax.hlines(y,0,val,color=COL[m],lw=1)
        ax.scatter(val,y,s=25,color=COL[m],marker=MARK[m])
        ax.annotate(f'{val:.2f}',(val,y),xytext=(5,0),textcoords='offset points',va='center',fontsize=8)
    ax.set_yticks(range(len(methods)),[LABEL[m].replace('mixture','mix.') for m in methods])
    ax.tick_params(axis='y',length=0,labelsize=7.8);ax.set_ylim(len(methods)-.4,-.6)
    ax.set_xlim(0,max(30,max(d.groupby('method').fixed_agc_emergency_mwh.sum())*1.35))
    ax.set_xlabel('Emergency ENS (MWh)');ax.grid(axis='x')
    ax.text(0,1.13,'(c)',transform=ax.transAxes,weight='bold')
    save(fig,output)

def capacity():
    d=read('capacity_scan/summary.csv')
    methods=['deterministic_headroom']+ORDER
    caps=[.7,.75,.8,.85,.9,1.]
    fig,axes=plt.subplots(2,1,figsize=(WIDTH,4.25))
    fig.subplots_adjust(left=.24,right=.90,bottom=.09,top=.95,hspace=.43)
    for j,(sys,title) in enumerate([('rbts','RBTS'),('rts79','RTS-79')]):
        mat=d[d.system.eq(sys)].pivot(index='method',columns='capacity_scale',values='mean_ens_mwh').loc[methods,caps].to_numpy()
        ax=axes[j];norm=Normalize(vmin=0,vmax=mat.max())
        im=ax.imshow(mat,aspect='auto',cmap='Blues',norm=norm)
        for row in range(len(methods)):
            for col in range(6):
                val=mat[row,col];label='0' if val<1e-5 else f'{val:.2f}' if val<1 else f'{val:.1f}'
                ax.text(col,row,label,ha='center',va='center',fontsize=8,
                    color='white' if norm(val)>.58 else '#172b3c')
        ax.set_yticks(range(6),[LABEL[m] for m in methods]);ax.set_xticks(range(6),[f'{v:.2f}' for v in caps])
        ax.tick_params(length=0,pad=4);ax.set_xlabel('Conventional capacity multiplier')
        ax.text(0,1.07,f'({chr(97+j)}) {title}',transform=ax.transAxes,weight='bold')
        ax.add_patch(Rectangle((-.5,4.5),6,1,fill=False,edgecolor='#a02e3c',lw=1.25,clip_on=False))
        cb=fig.colorbar(im,ax=ax,fraction=.04,pad=.035);cb.set_label('Mean ENS (MWh)',fontsize=8)
    save(fig,'Fig6_capacity')

