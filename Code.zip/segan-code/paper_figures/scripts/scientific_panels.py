"""Figures 2, 3 and 7 in a conventional journal style, from frozen records.

No optimization, bootstrap resampling, smoothing, or synthetic data is used.
The panel dimensions retain the existing figure heights in the manuscript.
"""
import hashlib
import json
from functools import wraps
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.ticker import MultipleLocator, FixedLocator, LogFormatterMathtext, NullLocator
import figure_assets as assets

ROOT, RES, WIDTH = assets.ROOT, assets.RES, assets.WIDTH
SYSTEMS=[('rbts','RBTS','#222222','o','-'),
         ('rts79','RTS-79','#245d9f','s','--'),
         ('gmlc','RTS-GMLC','#ad3438','^','-.')]
METHODS=['single_tv','mixture_static','mixture_rolling','proposed']
METHOD_LABELS=['Single-TV','Static\nmixture','Rolling\nmixture','Proposed']

def academic(fn):
    @wraps(fn)
    def draw(*args,**kwargs):
        with plt.rc_context({
            'font.family':'Times New Roman','mathtext.fontset':'stix',
            'font.size':10,'axes.labelsize':10,'axes.titlesize':10,
            'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,
            'axes.edgecolor':'black','axes.linewidth':.65,
            'axes.spines.top':True,'axes.spines.right':True,
            'xtick.direction':'in','ytick.direction':'in',
            'xtick.top':True,'ytick.right':True,'axes.axisbelow':True,
            'text.color':'black','axes.labelcolor':'black',
            'xtick.color':'black','ytick.color':'black',
            'grid.color':'#d3d3d3','grid.linewidth':.45,'grid.linestyle':':',
            'pdf.fonttype':42,'ps.fonttype':42,'savefig.dpi':600,
            'path.simplify':False,'hatch.linewidth':.45,
            'legend.fancybox':False,'legend.framealpha':1.0}):
            return fn(*args,**kwargs)
    return draw

def finish(fig,name):
    fig.canvas.draw()
    assets.save(fig,name)

def repetitions():
    from replication_effects import repetitions as draw
    return draw()

@academic
def refresh():
    data=assets.read('support_refresh_rts79_96h/training_comparison.csv')
    initial=data[data.training_protocol.eq('Fixed first-month training')].set_index('method').loc[METHODS]
    recent=data[data.training_protocol.eq('Preceding-month refresh')].set_index('method').loc[METHODS]
    assert initial.hours.eq(96).all() and recent.hours.eq(96).all()
    before,after=initial.total_ens_mwh.to_numpy(),recent.total_ens_mwh.to_numpy()
    events_before,events_after=initial.joint_events.to_numpy(),recent.joint_events.to_numpy()
    change=100*(after/before-1)
    fig,axes=plt.subplots(2,1,figsize=(WIDTH,4.9),gridspec_kw={'height_ratios':[1.45,1]})
    fig.subplots_adjust(left=.145,right=.98,bottom=.115,top=.86,hspace=.72)
    x=np.arange(4);offset=.165;width=.29
    for index,(ax,a,b) in enumerate(zip(axes,[before,events_before],[after,events_after])):
        ax.bar(x-offset,a,width=width,facecolor='white',edgecolor='black',
               linewidth=.7,hatch='///',zorder=3)
        ax.bar(x+offset,b,width=width,facecolor='#bdbdbd',edgecolor='black',linewidth=.7,zorder=3)
        for xx,yy in list(zip(x-offset,a))+list(zip(x+offset,b)):
            ax.text(xx,yy+(4 if index==0 else .12),f'{yy:.1f}' if index==0 else str(int(yy)),
                    ha='center',va='bottom',fontsize=8.7)
        ax.set(xlim=(-.58,3.58),xticks=x,xticklabels=METHOD_LABELS)
        ax.tick_params(length=3,width=.6,pad=4)
        ax.grid(axis='y')
    for xx,initial_value,pct in zip(x,before,change):
        y=initial_value+34
        axes[0].plot([xx-offset,xx-offset,xx+offset,xx+offset],[y-4,y,y,y-4],color='black',lw=.6)
        axes[0].text(xx,y+3,f'{pct:.1f}%',ha='center',va='bottom',fontsize=9)
    axes[0].set(ylim=(0,360),ylabel='Total ENS (MWh)')
    axes[0].yaxis.set_major_locator(MultipleLocator(100))
    axes[0].set_title('(a) Energy not served on the same 96 hours',pad=8)
    axes[1].set(ylim=(0,6),ylabel='Joint-event hours\n(out of 96)')
    axes[1].yaxis.set_major_locator(MultipleLocator(2))
    axes[1].set_title('(b) Pre-correction joint events',pad=8)
    fig.legend(handles=[Patch(facecolor='white',edgecolor='black',hatch='///',label='Initial month'),
                        Patch(facecolor='#bdbdbd',edgecolor='black',label='Preceding month')],
               loc='upper center',bbox_to_anchor=(.56,.985),ncol=2,
               frameon=True,edgecolor='black',borderpad=.4,columnspacing=1.6,handlelength=1.8)
    finish(fig,'Fig3_training_recency')
    return dict(methods=METHODS,initial_ens_mwh=before.tolist(),recent_ens_mwh=after.tolist(),
                relative_change_pct=change.tolist(),initial_events=events_before.tolist(),recent_events=events_after.tolist())

@academic
def convergence(traces=None,data=None):
    fig,axes=plt.subplots(2,1,figsize=(WIDTH,4.10),sharex=True)
    fig.subplots_adjust(left=.155,right=.98,bottom=.13,top=.85,hspace=.43)
    records=[]
    for system,label,color,marker,linestyle in SYSTEMS:
        case=f'{system}_q720_c2'
        trace_path=RES/f'solver_assessment/{case}_trace.csv'
        result_path=RES/f'solver_assessment/{case}.json'
        result=json.loads(result_path.read_text('utf-8'))
        assert result['full']['status']=='OPTIMAL'
        trace=pd.read_csv(trace_path) if traces is None else traces[case]
        ref=result['full']['objective']
        if data is not None:
            assert np.isclose(ref,data.loc[data.case.eq(case),'full_objective'].iloc[0])
        n=len(trace);ratio=trace.objective.to_numpy()/ref
        assert trace.iteration.tolist()==list(range(1,n+1))
        assert np.all(trace.max_separation_mw>0)
        assert np.all((ratio>=0)&(ratio<=1+1e-7))
        mark=list(dict.fromkeys([0,n//2,n-3,n-2,n-1]))
        mark=sorted(v for v in mark if v>=0)
        for ax,values in zip(axes,[ratio,trace.max_separation_mw.to_numpy()]):
            ax.plot(trace.iteration,values,color=color,linestyle=linestyle,lw=1.0,
                    marker=marker,markevery=mark,markersize=3.0,
                    markerfacecolor='white',markeredgewidth=.65,label=f'{label} ({n})',zorder=3)
        final_gap=100*abs(trace.objective.iloc[-1]-ref)/max(1,abs(ref))
        records.append(dict(case=case,iterations=n,final_objective_difference_pct=float(final_gap),
                            final_separation_mw=float(trace.max_separation_mw.iloc[-1]),
                            trace_sha256=hashlib.sha256(trace_path.read_bytes()).hexdigest(),
                            result_sha256=hashlib.sha256(result_path.read_bytes()).hexdigest(),
                            plotted_points=n,smoothing=False,interpolation='Straight segments joining actual recorded rounds'))
    axes[0].axhline(1,color='#777777',linestyle=(0,(3,2)),lw=.65,zorder=1)
    axes[0].set(ylim=(-.06,1.12),yticks=[0,.5,1],ylabel='Objective /\nfull-LP optimum')
    axes[0].set_title('(a) Objective bounds',pad=7)
    axes[1].set_yscale('log');axes[1].set_ylim(1e-14,1e4)
    axes[1].axhline(1e-6,color='#777777',linestyle=(0,(3,2)),lw=.75,zorder=1)
    axes[1].text(50,2e-6,r'Tolerance $10^{-6}$ MW',ha='center',va='bottom',fontsize=8.5,color='#333333')
    axes[1].yaxis.set_major_locator(FixedLocator([1e3,1e-1,1e-6,1e-11]))
    axes[1].yaxis.set_major_formatter(LogFormatterMathtext())
    axes[1].yaxis.set_minor_locator(NullLocator())
    axes[1].set(ylabel='Max. separation\nresidual (MW)',xlabel='Constraint-generation iteration')
    axes[1].set_title('(b) Full-support separation',pad=7)
    for ax in axes:
        ax.set_xlim(0,100);ax.xaxis.set_major_locator(MultipleLocator(20))
        ax.xaxis.set_minor_locator(MultipleLocator(5))
        ax.tick_params(length=3,width=.6,pad=4)
        ax.tick_params(which='minor',length=1.5,width=.45)
        ax.grid(axis='y')
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.565,.985),ncol=3,
               frameon=True,edgecolor='black',borderpad=.4,handlelength=2.2,
               columnspacing=1.15,fontsize=8.7)
    finish(fig,'Fig7_solver_convergence')
    return records

def main():
    report=dict(figure2=repetitions(),figure3=refresh(),figure7=convergence(),
                source_hashes=assets.SOURCES,style='Serif type, black boxed axes, capped confidence intervals, hatched grouped bars, distinguishable raw convergence traces',
                source_data_unchanged=True)
    (ROOT/'audit/scientific_figure_revision.json').write_text(json.dumps(report,indent=2)+'\n','utf-8')
    print(json.dumps(report,indent=2))

if __name__=='__main__':
    main()
