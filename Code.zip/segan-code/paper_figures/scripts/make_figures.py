"""Redesign main-text Figures 1-4 for legibility at the 31-pica print width.

All numbers come from frozen result CSVs. The redesign introduces no new runs.
"""
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle, Patch
from matplotlib.ticker import MultipleLocator, StrMethodFormatter
import figure_assets as assets

ROOT, IMG, WIDTH = assets.ROOT, assets.IMG, assets.WIDTH
COL, LABEL = assets.COL, assets.LABEL
BLUE, TEAL, INK, MUTED = '#245f91', '#176b65', '#172b3c', '#607386'
ORDER = ['single_tv', 'mixture_static', 'mixture_rolling', 'proposed']
SHORT = ['Single-TV', 'Static\nmixture', 'Rolling\nmixture', 'Proposed']

plt.rcParams.update({
    'font.family': 'Arial', 'font.size': 9.5, 'axes.labelsize': 9.5,
    'axes.titlesize': 9.8, 'xtick.labelsize': 9.2, 'ytick.labelsize': 9.2,
    'legend.fontsize': 9.2, 'axes.linewidth': .7, 'lines.linewidth': 1.4,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.axisbelow': True, 'grid.linewidth': .45, 'grid.color': '#dce2e7',
    'pdf.fonttype': 42, 'ps.fonttype': 42, 'savefig.dpi': 600,
})


def arrow(ax, start, end, **kwargs):
    ax.add_patch(FancyArrowPatch(start, end, arrowstyle='-|>', mutation_scale=9,
        linewidth=.9, color=MUTED, shrinkA=0, shrinkB=0, **kwargs))


def rounded(ax, xy, width, height, face, edge=MUTED, lw=.8):
    p = FancyBboxPatch(xy, width, height,
        boxstyle='round,pad=0.009,rounding_size=0.015',
        facecolor=face, edgecolor=edge, linewidth=lw)
    ax.add_patch(p)
    return p


def workflow():
    fig, ax = plt.subplots(figsize=(WIDTH, 4.0))
    fig.subplots_adjust(left=.012, right=.988, bottom=.01, top=.99)
    ax.set(xlim=(0, 1), ylim=(0, 1)); ax.axis('off')

    rounded(ax, (.018, .285), .457, .685, '#f0f5fa', BLUE)
    rounded(ax, (.525, .285), .457, .685, '#f0f7f5', TEAL)
    ax.text(.043, .932, '(a) Offline regime learning', weight='bold', color=BLUE,
        fontsize=10, va='top')
    ax.text(.55, .932, '(b) Online weight update', weight='bold', color=TEAL,
        fontsize=10, va='top')

    ax.text(.247, .824, 'Historical error pool', ha='center', fontsize=10)
    arrow(ax, (.247, .791), (.247, .742))
    rounded(ax, (.059, .652), .375, .077, 'white', BLUE)
    ax.text(.247, .690, 'Gaussian mixture model', ha='center', va='center', fontsize=9.8)

    centers = [.112, .247, .382]
    fills = ['#dce8f3', '#e6e0ee', '#f3e9d6']
    for x, fill, sub in zip(centers, fills, ['1', '2', 'K']):
        arrow(ax, (.247, .639), (x, .589))
        rounded(ax, (x-.052, .510), .104, .067, fill, '#8191a0', .65)
        ax.text(x, .543, rf'$\hat{{P}}_{{{sub}}}$', ha='center', va='center', fontsize=11)
    for x in centers:
        arrow(ax, (x, .498), (x, .452))
    rounded(ax, (.054, .316), .384, .122, 'white', BLUE)
    ax.text(.247, .405, 'Within-regime protection', ha='center', va='center',
        fontsize=9.1, weight='bold', color=BLUE)
    ax.text(.247, .351, r'$D_\phi(P_k\,\Vert\,\hat{P}_k)\leq\rho_k$',
        ha='center', va='center', fontsize=11)

    ax.text(.754, .831, 'Recent observed errors', ha='center', fontsize=9.8)
    ax.text(.754, .779, '+ one-step persistence proxy', ha='center', fontsize=9.2)
    arrow(ax, (.754, .751), (.647, .708))
    arrow(ax, (.754, .751), (.86, .708))
    for x, title, formula in [(.647, 'Rolling', r'$\pi_t^{\rm roll}$'),
                               (.86, 'Predictive', r'$\hat{\gamma}_t$')]:
        rounded(ax, (x-.085, .581), .17, .113, 'white', TEAL)
        ax.text(x, .666, title, ha='center', va='center', fontsize=9.1)
        ax.text(x, .615, formula, ha='center', va='center', fontsize=11)
        arrow(ax, (x, .569), (.754, .523))
    ax.text(.754, .492, r'$\pi_t=\theta\hat{\gamma}_t+(1-\theta)\pi_t^{\rm roll}$',
        ha='center', va='center', fontsize=10.2)
    arrow(ax, (.754, .469), (.754, .443))
    rounded(ax, (.561, .316), .384, .122, 'white', TEAL)
    ax.text(.754, .405, 'Prevalence protection', ha='center', va='center',
        fontsize=9.1, weight='bold', color=TEAL)
    ax.text(.754, .351, r'$\|w-\pi_t\|_1\leq\delta_w$',
        ha='center', va='center', fontsize=11)

    arrow(ax, (.247, .273), (.247, .226))
    arrow(ax, (.754, .273), (.754, .226))
    rounded(ax, (.018, .018), .964, .195, '#e8eef4', BLUE, 1.0)
    ax.text(.5, .176, '(c) Robust CVaR dispatch', ha='center', va='center',
        fontsize=10.2, weight='bold', color=INK)
    ax.text(.5, .115, 'Network limits, reserves, and preventive decisions',
        ha='center', va='center', fontsize=9.6)
    ax.text(.5, .055, r'Total variation: LP    |    Modified $\chi^2$: SOCP',
        ha='center', va='center', fontsize=9.6)
    assets.save(fig, 'Fig1_workflow')


def repetitions():
    from result_figures import repetitions as draw
    return draw()


def refresh():
    from scientific_panels import refresh as draw
    return draw()


def chronological():
    from result_figures import chronological as draw
    return draw()


def main():
    IMG.mkdir(exist_ok=True)
    workflow()
    summary = {'figure2': repetitions(), 'figure3': refresh(), 'figure4': chronological()}
    manifest_path = ROOT/'audit/figure_data_manifest.json'
    manifest = json.loads(manifest_path.read_text('utf-8')) if manifest_path.exists() else {}
    manifest.update(assets.SOURCES)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), 'utf-8')
    (ROOT/'audit/figure_values.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), 'utf-8')
    print('Figures 1-4 redesigned; frozen-data checks passed')


if __name__ == '__main__':
    main()
