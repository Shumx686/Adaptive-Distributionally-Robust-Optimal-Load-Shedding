"""Figures 4 and 5: subdued operational curves from frozen hourly records.

Reference styles: thin marked lines and a pale area for signed method changes.
No bars, synthetic uncertainty intervals, smoothing, or solver reruns are used.
"""
import hashlib
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
import figure_assets as assets
from scientific_panels import academic, finish

ROOT,RES,WIDTH=assets.ROOT,assets.RES,assets.WIDTH
SOURCE='rolling_operational_rts79_576h/rts79/hourly.csv'
METHODS=['single_tv','mixture_rolling','proposed']
STYLE={
    'single_tv':dict(color='#333333',linestyle='-',marker='o',label='Single-TV'),
    'mixture_rolling':dict(color='#667c88',linestyle='--',marker='s',label='Rolling mixture'),
    'proposed':dict(color='#6c685f',linestyle='-.',marker='D',label='Proposed')}
# The change curves use muted teal and plum, with symbols/line types retained.
CHANGE_COLORS={'mixture_rolling':'#806c80','proposed':'#4e7772'}

def samples():
    data=assets.read(SOURCE)
    winter=data[data.day.between(338,343)]
    daily=winter.groupby(['day','method']).fixed_agc_ens_mwh.sum().unstack().loc[range(338,344),METHODS]
    changes=daily[['mixture_rolling','proposed']].subtract(daily.single_tv,axis=0)
    events=data[data.fixed_agc_emergency_mwh.gt(1e-5)]
    assert set(events.day)=={343} and set(events.hour).issubset({21,22,23,24})
    selected=data[data.day.eq(343)&data.hour.between(21,24)]
    emergency=selected.pivot(index='hour',columns='method',values='fixed_agc_emergency_mwh').loc[range(21,25),METHODS]
    assert np.allclose(emergency.sum().to_numpy(),data.groupby('method').fixed_agc_emergency_mwh.sum().loc[METHODS],atol=1e-5)
    return daily,changes,emergency

@academic
def chronological():
    daily,changes,emergency=samples()
    days=daily.index.to_numpy()
    fig,axes=plt.subplots(2,1,figsize=(WIDTH,3.55))
    fig.subplots_adjust(left=.16,right=.98,bottom=.235,top=.89,hspace=.85)
    ax=axes[0]
    values=daily.single_tv.to_numpy()
    ax.plot(days,values,color='#404040',lw=1.0,marker='o',markersize=3.6,
            markerfacecolor='white',markeredgewidth=.7,zorder=3)
    for x,y in zip(days,values):
        ax.annotate(f'{y:.1f}',(x,y),xytext=(0,6),textcoords='offset points',
                    ha='center',va='bottom',fontsize=8.5)
    ax.set(xlim=(337.55,343.45),ylim=(-60,2700),xticks=days,yticks=[0,1000,2000],
           ylabel='Daily ENS (MWh)')
    ax.set_title('(a) Single-TV reference',pad=8)
    ax.grid(axis='y')
    ax=axes[1]
    # A deterministic signed difference, not a confidence or prediction band.
    ax.fill_between(days,0,changes.proposed.to_numpy(),color='#e9f0ee',zorder=1)
    ax.axhline(0,color='#777777',lw=.65,zorder=2)
    for method in ('mixture_rolling','proposed'):
        spec=STYLE[method].copy();spec['color']=CHANGE_COLORS[method]
        ax.plot(days,changes[method].to_numpy(),**spec,lw=1.1,markersize=3.8,
                markerfacecolor='white',markeredgewidth=.7,zorder=3)
    offsets=[(0,8),(0,8),(0,8),(0,-11),(0,8),(0,8)]
    for x,y,offset in zip(days,changes.proposed.to_numpy(),offsets):
        label='0' if abs(y)<1e-4 else f'{y:+.1f}'
        ax.annotate(label,(x,y),xytext=offset,textcoords='offset points',ha='center',
                    va='bottom' if offset[1]>0 else 'top',fontsize=8.6,color='#354f4c')
    ax.set(xlim=(337.55,343.45),ylim=(-65,50),xticks=days,yticks=[-50,-25,0,25],
           ylabel='ENS change from\nSingle-TV (MWh)',xlabel='Day of year')
    ax.set_title('(b) Changes under adaptive methods',pad=8)
    ax.grid(axis='y')
    for ax in axes:
        ax.tick_params(length=3,width=.6,pad=4)
    handles,labels=axes[1].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.57,.015),
               ncol=2,frameon=False,fontsize=9,handlelength=2.4,columnspacing=1.7)
    finish(fig,'Fig4_chronological')

    fig,ax=plt.subplots(figsize=(WIDTH,2.45))
    fig.subplots_adjust(left=.155,right=.98,bottom=.25,top=.79)
    hours=emergency.index.to_numpy()
    for method in METHODS:
        spec=STYLE[method].copy()
        if method!='single_tv':spec['color']=CHANGE_COLORS[method]
        values=emergency[method].to_numpy()
        ax.plot(hours,values,**spec,lw=1.1,markersize=3.8,markerfacecolor='white',
                markeredgewidth=.7,zorder=3)
        for x,y in zip(hours,values):
            # Separate the close rolling/protected values without shifting data.
            below=(method=='proposed') or (method=='single_tv' and y>.01)
            offset=-9 if below else 7
            horizontal=14 if method=='single_tv' and y<.01 else 0
            if horizontal:
                offset=1
            ax.annotate(f'{y:.1f}',(x,y),xytext=(horizontal,offset),textcoords='offset points',
                        ha='center',va='top' if below else 'bottom',fontsize=8.4,
                        color=spec['color'])
    ax.set(xlim=(20.7,24.3),ylim=(-.5,9.15),xticks=hours,yticks=[0,2,4,6,8],
           ylabel='Hourly emergency\nENS (MWh)',xlabel='Hour of day 343')
    ax.xaxis.set_minor_locator(MultipleLocator(.5))
    ax.tick_params(length=3,width=.6,pad=4)
    ax.tick_params(which='minor',length=1.5,width=.45)
    ax.grid(axis='y')
    handles,labels=ax.get_legend_handles_labels()
    fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.565,.995),ncol=3,
               frameon=False,fontsize=8.8,handlelength=2.3,columnspacing=1.2)
    finish(fig,'Fig5_emergency')
    report=dict(daily_totals=daily.to_dict(),daily_differences=changes.to_dict(),
                emergency_totals_mwh=emergency.sum().to_dict(),
                emergency_hours=[21,22,23,24],hourly_emergency_mwh=emergency.to_dict(),
                source=SOURCE,source_sha256=hashlib.sha256((RES/SOURCE).read_bytes()).hexdigest(),
                shading='Signed proposed-model ENS difference from Single-TV, relative to zero',
                original_heights_inches={'figure4':3.55,'figure5':2.45},
                bars=0,smoothing=False,synthetic_intervals=False)
    return report

def main():
    report=chronological()
    (ROOT/'audit/operational_curve_design.json').write_text(json.dumps(report,indent=2)+'\n','utf-8')
    print(json.dumps(report,indent=2))

if __name__=='__main__':
    main()
