"""Individual-history effects; aggregate estimates and CIs remain in Table S2."""
import json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
import figure_assets as assets
from scientific_panels import academic,finish


@academic
def repetitions():
    data=assets.read('controlled_beta_repetitions/replication_means.csv')
    systems=[('rbts','RBTS','#3e3e3e','o'),('rts79','RTS-79','#507c76','s'),
             ('gmlc','RTS-GMLC','#827184','D')]
    fig,axes=plt.subplots(1,2,figsize=(assets.WIDTH,2.65))
    fig.subplots_adjust(left=.125,right=.975,bottom=.235,top=.87,wspace=.57)
    records=[]
    offsets=np.linspace(-.20,.20,10)
    for x,(system,label,color,marker) in enumerate(systems):
        subset=data[data.system.eq(system)]
        a=subset[subset.method.eq('single_tv')].set_index('replication').sort_index()
        b=subset[subset.method.eq('proposed')].set_index('replication').sort_index()
        assert a.index.tolist()==b.index.tolist()==list(range(1,11))
        effect=100*(1-b.eens_mwh.to_numpy()/a.eens_mwh.to_numpy())
        reduction=a.joint_violation_pct.to_numpy()-b.joint_violation_pct.to_numpy()
        assert np.all(effect>0) and np.all(reduction>0)
        for ax,ys in zip(axes,(effect,reduction)):
            ax.plot(np.full(10,x)+offsets,ys,linestyle='none',marker=marker,
                    markersize=4,markerfacecolor='white',markeredgecolor=color,
                    markeredgewidth=.8,zorder=3)
        records.append(dict(system=system,replications=list(range(1,11)),
                            eens_reduction_pct=effect.tolist(),joint_event_reduction_pp=reduction.tolist()))
    for ax,title,ylabel,upper,step in zip(axes,
            ['(a) EENS reduction','(b) Joint-event reduction'],
            ['EENS reduction (%)','Joint-event reduction\n(pp)'],[40,3.2],[10,1]):
        ax.set(xlim=(-.5,2.5),ylim=(0,upper),xticks=[0,1,2],
               xticklabels=['RBTS','RTS-79','RTS-\nGMLC'],ylabel=ylabel)
        ax.yaxis.set_major_locator(MultipleLocator(step))
        ax.set_title(title,pad=7)
        ax.tick_params(length=3,width=.6,pad=4)
        ax.grid(axis='y')
    finish(fig,'Fig2_repeated')
    return records


if __name__=='__main__':
    report=dict(individual_history_effects=repetitions(),source_hashes=assets.SOURCES,
                aggregates_plotted=False,confidence_intervals_plotted=False,
                within_group_horizontal_offsets='Deterministic visual separation only; no additional variable.')
    (assets.ROOT/'audit/replication_effects_design.json').write_text(json.dumps(report,indent=2)+'\n','utf-8')
