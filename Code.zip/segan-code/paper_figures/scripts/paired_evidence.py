"""Paired evidence from frozen histories, with no new optimization runs."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT.parent/'experiments/results/controlled_beta_repetitions'
LABEL={'rbts':'RBTS','rts79':'RTS-79','gmlc':'RTS-GMLC',
       'empirical_cvar':'Empirical CVaR','single_tv':'Single-TV',
       'mixture_static':'Static mixture','mixture_rolling':'Rolling mixture','proposed':'Proposed'}


def generate():
    (ROOT/'audit').mkdir(parents=True,exist_ok=True)
    rep=pd.read_csv(SOURCE/'replication_means.csv')
    draws=pd.read_csv(SOURCE/'all_dispatches.csv')
    frozen=pd.read_csv(SOURCE/'paired_comparisons.csv')
    assert len(draws)==450 and draws.status.eq('OPTIMAL').all() and draws.n_scenarios.eq(1000).all()
    reconstructed=draws.groupby(['system','replication','method']).agg(
        eens_mwh=('expected_ens_mwh','mean'),emergency_mwh=('mean_emergency_mwh','mean'),
        joint_violation_pct=('joint_violation_pct','mean'),contexts=('context','nunique'))
    for row in rep.itertuples():
        actual=reconstructed.loc[(row.system,row.replication,row.method)]
        assert actual.contexts==3
        for metric in ('eens_mwh','emergency_mwh','joint_violation_pct'):
            assert np.isclose(actual[metric],getattr(row,metric),atol=1e-10)
    comparisons=[]
    for system in ('rbts','rts79','gmlc'):
        p=rep[rep.system.eq(system)].pivot(index='replication',columns='method')
        assert len(p)==10
        indices=np.random.default_rng(2026111504).integers(0,10,(10000,10))
        for baseline,candidate in [(m,'proposed') for m in ('empirical_cvar','single_tv','mixture_static','mixture_rolling')]+[('mixture_static','mixture_rolling')]:
            row=dict(system=system,baseline=baseline,candidate=candidate,replications=10)
            for metric,name in [('eens_mwh','eens'),('emergency_mwh','emergency'),('joint_violation_pct','joint')]:
                a=p[metric][baseline].to_numpy();b=p[metric][candidate].to_numpy()
                if name=='joint':
                    estimate=(a-b).mean();boot=(a[indices]-b[indices]).mean(1)
                else:
                    assert a.mean()>0
                    estimate=100*(1-b.mean()/a.mean())
                    boot=100*(1-b[indices].mean(1)/a[indices].mean(1))
                lo,hi=np.quantile(boot,[.025,.975])
                row.update({name+'_reduction':float(estimate),name+'_ci_low':float(lo),name+'_ci_high':float(hi),
                            name+'_improved_replications':int((a>b+1e-10).sum())})
            # Keep the published intervals already plotted in the unchanged figures.
            old=frozen[frozen.system.eq(system)&frozen.baseline.eq(baseline)&frozen.candidate.eq(candidate)]
            if len(old):
                old=old.iloc[0]
                assert np.isclose(row['eens_reduction'],old.eens_reduction_pct)
                row.update(eens_ci_low=float(old.reduction_ci95_low),eens_ci_high=float(old.reduction_ci95_high),
                           joint_ci_low=float(-old.risk_difference_ci95_high),joint_ci_high=float(-old.risk_difference_ci95_low))
            comparisons.append(row)
    result=pd.DataFrame(comparisons)
    result.to_csv(ROOT/'audit/paired_evidence.csv',index=False)
    provenance=dict(bootstrap_resamples=10000,new_interval_seed=2026111504,
                    sampling_unit='complete independent history; three contexts kept together',
                    existing_intervals='Frozen EENS and joint-event intervals retained where available',
                    input_sha256={name:hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()
                        for name in ('replication_means.csv','all_dispatches.csv','paired_comparisons.csv')},
                    optimal_dispatches=len(draws),reconstructed_replication_rows=len(rep),comparisons=len(result))
    (ROOT/'audit/paired_evidence.json').write_text(json.dumps(provenance,indent=2)+'\n','utf-8')
    return result


if __name__ == '__main__':
    result = generate()
    print(result.to_string(index=False))
