"""One process per figure style, avoiding shared matplotlib style changes."""
from pathlib import Path
import hashlib
import json
import os
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
(ROOT/'audit').mkdir(parents=True,exist_ok=True)
job=sys.argv[1];out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True)
os.environ['SEGAN_FIGURE_OUTPUT']=str(out)
import figure_assets as assets

if job=='workflow':
    from make_figures import workflow
    workflow()
elif job=='histories':
    from replication_effects import repetitions
    repetitions()
elif job=='recency':
    from scientific_panels import refresh
    refresh()
elif job=='operational':
    from operational_curves import chronological
    chronological()
elif job=='capacity':
    assets.capacity()
elif job=='convergence':
    from scientific_panels import convergence
    convergence()
elif job=='fixed_calendar':
    assets.calendar('joint_test_rts79_576h',(332,337),assets.ORDER,'FigS1_fixed_training')
else:
    raise ValueError('Unknown figure job: '+job)
(out/(job+'_sources.json')).write_text(json.dumps(assets.SOURCES,indent=2)+'\n','utf-8')
