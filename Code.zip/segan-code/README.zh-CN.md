# 完整研究代码与实验结果

对应当前三系统论文。这里完整保留与研究结果有关的模型、运行和绘图程序、固定配置、逐情景记录、验证候选结果、逐小时回放及求解迭代记录，另保留当前风电误差压力和参数敏感性结果对应的代码与原始运行记录。

论文正文、文献表、投稿信、声明附件、编译文件、缓存和本地排版检查文件不属于代码包。`paper_figures/reference/`只是8幅结果图的PDF/PNG对照文件，不是论文正文。

先阅读 `FILE_GUIDE.md`；`file_inventory.csv`逐个列出文件路径、大小和用途。`docs/RESULTS.md`按实验说明完整结果位置。

```sh
python -m pip install -r requirements.txt
python reproduce.py verify
python reproduce.py figures
python reproduce.py reports
python supplementary_studies/reproduce.py verify
python supplementary_studies/reproduce.py rebuild
```

上述命令从保存的完整记录重建图形和统计，输出进入新建的 `outputs/`，不覆盖分发结果。前三系统独立历史共有450个调度、450000个方法—情景记录；`reports`另外计算当前稿件所用15组成对比较。

Windows建议解压到较短的位置，如 `D:/segan-code`；过深的目录会在创建报告工作区时触发路径长度限制。

重新求解需要 Julia 1.12.1，以及按原始提供方获取的网络、负荷和风电输入。主输入的20项精确文件名、字节数、SHA-256和来源说明保留在 `input_manifest.json` 与 `docs/DATA.md`；第三方原始输入没有混入研究生成的结果文件中。

`supplementary_studies/`中的日期是结果冻结版本：其中风电—容量压力和参数敏感性实验仍对应当前正文与补充材料的相关结果，因此保留完整试验组，包括零值、失败状态及原配置。其原始实验定义与较新的主实验不同，不能混作同一采样协议。详细运行方法见该目录README。
