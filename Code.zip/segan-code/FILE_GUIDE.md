# 文件内容与用途

本包按复现用途保留完整研究材料；`file_inventory.csv`逐个列出所有分发文件及用途。清单自身和根校验表的大小栏留空，以避免循环依赖。

| 路径 | 用途 |
| --- | --- |
| `core/src/DRCCOLS.jl` | 核心电网、误差、混合分布及优化模型 |
| `core/Project.toml`、`core/Manifest.toml` | Julia依赖与精确版本 |
| `experiments/scripts/` | 当前实验运行、校正、选参、合并、统计和数值核验代码 |
| `experiments/config/` | 全部当前冻结配置、评估日历和随机流账本 |
| `experiments/results/` | 主实验完整CSV/JSON结果；各组含协议、索引、选参及完成状态 |
| `paper_figures/scripts/`、`paper_figures/build.py` | 当前图1–7及S1的重绘程序、配对统计程序 |
| `paper_figures/reference/` | 8幅图的PDF/PNG结果对照 |
| `supplementary_studies/` | 当前风电误差压力、线路裕度及敏感性结果对应的完整代码/记录 |
| `input_manifest.json`、`docs/DATA.md` | 外部原始输入的精确文件清单、校验值、来源与安装方式 |
| `checksums.json`、`provenance.json` | 分发文件完整性和来源映射 |

## 结果文件命名

| 文件或模式 | 内容 |
| --- | --- |
| `scenarios_<context>_<method>.csv` | 每个情景的物理校正、缺供、电网事件和残差记录，完整保留 |
| `summary.csv`、`all_dispatches.csv` | 所有方法和运行状态的逐调度记录 |
| `replication_means.csv`、`method_summary.csv`、`paired_comparisons.csv` | 独立历史均值、方法汇总和成对比较 |
| `screen_*`、`confirm_*`、`candidate_grid.json`、`validation_scores.csv` | 参数候选网格、筛选/确认的完整结果及来源索引 |
| `selected_parameters.json`、`selected_weights.json` | 冻结的验证选择，未用测试结果重新选参 |
| `hourly.csv`、`daily_summary.csv`、`seasonal_summary.csv` | 逐小时回放及相应日/季节汇总 |
| `*_input.json`、`*_trace.csv`、求解实例JSON | 求解器共同输入、每轮迭代、状态、时间和残差 |
| `protocol.json`、`support.json`、`config_used.json`、账本JSON | 实际协议、支撑/来源索引、配置和随机流 |
| `completed.json`、`verification.json` | 实验完整性及数值核验记录，属于复现依据 |

图形和统计说明中的上下文定义随各自实验保留。主文排版文件、参考文献库和临时审阅截图不在本包内。
