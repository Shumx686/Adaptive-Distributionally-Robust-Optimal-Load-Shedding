Original third-party inputs are obtained separately. See `../docs/DATA.md` and `../input_manifest.json`. No original input files are embedded in the release.
